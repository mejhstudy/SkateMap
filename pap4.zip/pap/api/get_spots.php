<?php
/**
 * API para buscar spots
 * Retorna spots em formato JSON para o mapa
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../includes/config.php';

try {
    $conn = getConnection();
    
    if (!$conn) {
        throw new Exception('Erro de conexão com a base de dados');
    }
    
    // Query para buscar spots com informações completas
    $query = "
        SELECT 
            s.id,
            s.nome,
            s.descricao,
            s.endereco,
            s.latitude,
            s.longitude,
            s.foto_principal,
            s.data_criacao,
            u.username,
            AVG(a.nota) as rating_medio,
            COUNT(a.id) as total_avaliacoes,
            COUNT(DISTINCT c.id) as total_comentarios
        FROM spots s
        LEFT JOIN utilizadores u ON s.id_usuario = u.id
        LEFT JOIN avaliacoes a ON s.id = a.id_spot
        LEFT JOIN comentarios c ON s.id = c.id_spot
        GROUP BY s.id
        ORDER BY s.data_criacao DESC
    ";
    
    $stmt = $conn->query($query);
    $spots = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Processar dados dos spots
    foreach ($spots as &$spot) {
        // Arredondar rating para 1 casa decimal
        $spot['rating_medio'] = $spot['rating_medio'] ? round(floatval($spot['rating_medio']), 1) : 0;
        
        // Converter para inteiros
        $spot['total_avaliacoes'] = intval($spot['total_avaliacoes']);
        $spot['total_comentarios'] = intval($spot['total_comentarios']);
        
        // Converter coordenadas para float
        $spot['latitude'] = floatval($spot['latitude']);
        $spot['longitude'] = floatval($spot['longitude']);
        
        // Formatar data
        $spot['data_criacao_formatada'] = date('d/m/Y', strtotime($spot['data_criacao']));
    }
    
    // Retornar resposta de sucesso
    echo json_encode([
        'success' => true,
        'spots' => $spots,
        'total' => count($spots),
        'message' => 'Spots carregados com sucesso'
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // Log do erro
    error_log("Erro na API get_spots: " . $e->getMessage());
    
    // Retornar erro
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao carregar spots',
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>