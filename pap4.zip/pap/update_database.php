<?php
/**
 * SkateMap - Script de Atualização da Base de Dados
 * PAP - Prova de Aptidão Profissional
 */

require_once 'includes/config.php';

// Definir as atualizações necessárias
$updates = [
    '2024_10_08_001' => [
        'description' => 'Criar tabela de favoritos',
        'sql' => "
            CREATE TABLE IF NOT EXISTS favoritos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_usuario INT NOT NULL,
                id_spot INT NOT NULL,
                data_favorito TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
                FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
                UNIQUE KEY unique_user_spot_favorite (id_usuario, id_spot),
                INDEX idx_usuario (id_usuario),
                INDEX idx_spot (id_spot),
                INDEX idx_data (data_favorito)
            )
        "
    ],
    '2024_10_08_002' => [
        'description' => 'Adicionar campo comentario na tabela avaliacoes',
        'sql' => "
            ALTER TABLE avaliacoes 
            ADD COLUMN IF NOT EXISTS comentario TEXT DEFAULT NULL 
            AFTER nota
        "
    ],
    '2024_10_08_003' => [
        'description' => 'Adicionar índices para performance',
        'sql' => "
            CREATE INDEX IF NOT EXISTS idx_spots_usuario_data ON spots(id_usuario, data_criacao);
            CREATE INDEX IF NOT EXISTS idx_avaliacoes_nota ON avaliacoes(nota);
            CREATE INDEX IF NOT EXISTS idx_comentarios_data ON comentarios(data_publicacao);
        "
    ],
    '2024_10_08_004' => [
        'description' => 'Criar view para estatísticas de spots',
        'sql' => "
            CREATE OR REPLACE VIEW vw_spots_stats AS
            SELECT 
                s.id,
                s.nome,
                s.descricao,
                s.endereco,
                s.latitude,
                s.longitude,
                s.foto_principal,
                s.data_criacao,
                s.id_usuario,
                u.username as usuario_nome,
                COALESCE(AVG(a.nota), 0) as rating_medio,
                COUNT(DISTINCT a.id) as total_avaliacoes,
                COUNT(DISTINCT f.id) as total_favoritos,
                COUNT(DISTINCT c.id) as total_comentarios,
                COUNT(DISTINCT fs.id) as total_fotos,
                COUNT(DISTINCT vs.id) as total_videos
            FROM spots s
            LEFT JOIN utilizadores u ON s.id_usuario = u.id
            LEFT JOIN avaliacoes a ON s.id = a.id_spot
            LEFT JOIN favoritos f ON s.id = f.id_spot
            LEFT JOIN comentarios c ON s.id = c.id_spot
            LEFT JOIN fotos_spots fs ON s.id = fs.id_spot
            LEFT JOIN videos_spots vs ON s.id = vs.id_spot
            GROUP BY s.id, s.nome, s.descricao, s.endereco, s.latitude, s.longitude, 
                     s.foto_principal, s.data_criacao, s.id_usuario, u.username
        "
    ]
];

// Função para verificar se uma atualização já foi executada
function isUpdateApplied($conn, $updateId) {
    try {
        // Criar tabela de versionamento se não existir
        $conn->exec("
            CREATE TABLE IF NOT EXISTS database_updates (
                id VARCHAR(50) PRIMARY KEY,
                description TEXT,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        $stmt = $conn->prepare("SELECT id FROM database_updates WHERE id = ?");
        $stmt->execute([$updateId]);
        return $stmt->fetch() !== false;
    } catch (Exception $e) {
        return false;
    }
}

// Função para marcar atualização como aplicada
function markUpdateApplied($conn, $updateId, $description) {
    $stmt = $conn->prepare("
        INSERT INTO database_updates (id, description) 
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE applied_at = CURRENT_TIMESTAMP
    ");
    $stmt->execute([$updateId, $description]);
}

// Função para executar atualização
function executeUpdate($conn, $updateId, $update) {
    try {
        // Executar SQL
        $conn->exec($update['sql']);
        
        // Marcar como aplicada
        markUpdateApplied($conn, $updateId, $update['description']);
        
        return ['success' => true, 'message' => $update['description'] . ' - Aplicada com sucesso'];
    } catch (Exception $e) {
        return ['success' => false, 'message' => $update['description'] . ' - Erro: ' . $e->getMessage()];
    }
}

// Interface web simples
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atualização da Base de Dados - SkateMap</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
        }
        .update-item {
            margin: 15px 0;
            padding: 15px;
            border-radius: 5px;
            border-left: 4px solid #95a5a6;
        }
        .success {
            background-color: #d4edda;
            border-left-color: #28a745;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            border-left-color: #dc3545;
            color: #721c24;
        }
        .pending {
            background-color: #fff3cd;
            border-left-color: #ffc107;
            color: #856404;
        }
        .applied {
            background-color: #e2e3e5;
            border-left-color: #6c757d;
            color: #495057;
        }
        .btn {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            margin: 10px 5px;
        }
        .btn:hover {
            background-color: #2980b9;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .status {
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 3px;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🛠️ Atualização da Base de Dados - SkateMap</h1>
        
        <?php
        $conn = null;
        $connectionError = false;
        
        try {
            $conn = getConnection();
            if (!$conn) {
                throw new Exception('Erro ao conectar à base de dados');
            }
        } catch (Exception $e) {
            $connectionError = true;
            echo "<div class='update-item error'>";
            echo "<strong>Erro de Conexão:</strong> " . $e->getMessage();
            echo "</div>";
        }
        
        if (!$connectionError) {
        ?>
        
        <p>Este script irá aplicar as atualizações necessárias na base de dados para suportar as novas funcionalidades do SkateMap.</p>
        
        <h2>📋 Estado das Atualizações</h2>
        
        <?php
        $pendingUpdates = [];
        $appliedCount = 0;
        $totalUpdates = count($updates);
        
        foreach ($updates as $updateId => $update) {
            $isApplied = isUpdateApplied($conn, $updateId);
            
            echo "<div class='update-item " . ($isApplied ? 'applied' : 'pending') . "'>";
            echo "<strong>$updateId:</strong> " . $update['description'];
            
            if ($isApplied) {
                echo " <span class='status' style='background-color: #28a745; color: white;'>✅ Aplicada</span>";
                $appliedCount++;
            } else {
                echo " <span class='status' style='background-color: #ffc107; color: #856404;'>⏳ Pendente</span>";
                $pendingUpdates[] = $updateId;
            }
            
            echo "</div>";
        }
        
        echo "<div style='margin: 20px 0; padding: 15px; background-color: #e9ecef; border-radius: 5px;'>";
        echo "<strong>Progresso:</strong> $appliedCount de $totalUpdates atualizações aplicadas";
        echo "</div>";
        
        // Processar atualizações se requisitado
        if (isset($_POST['run_updates'])) {
            echo "<h2>🔄 Executando Atualizações</h2>";
            
            $results = [];
            foreach ($pendingUpdates as $updateId) {
                $result = executeUpdate($conn, $updateId, $updates[$updateId]);
                $results[] = $result;
                
                echo "<div class='update-item " . ($result['success'] ? 'success' : 'error') . "'>";
                echo ($result['success'] ? '✅' : '❌') . " " . $result['message'];
                echo "</div>";
            }
            
            // Verificar se todas foram aplicadas
            $allSuccess = array_reduce($results, function($carry, $item) {
                return $carry && $item['success'];
            }, true);
            
            if ($allSuccess && count($results) > 0) {
                echo "<div class='update-item success'>";
                echo "<strong>🎉 Todas as atualizações foram aplicadas com sucesso!</strong>";
                echo "<br><a href='update_database.php' class='btn btn-success'>Atualizar Página</a>";
                echo "</div>";
            }
        }
        
        // Mostrar botão para executar atualizações
        if (count($pendingUpdates) > 0) {
            echo "<form method='POST'>";
            echo "<button type='submit' name='run_updates' class='btn btn-success'>";
            echo "🚀 Executar " . count($pendingUpdates) . " Atualização(ões) Pendente(s)";
            echo "</button>";
            echo "</form>";
        } else {
            echo "<div class='update-item success'>";
            echo "<strong>✅ Todas as atualizações estão aplicadas!</strong>";
            echo "<br><a href='" . SITE_URL . "' class='btn'>Voltar ao SkateMap</a>";
            echo "</div>";
        }
        
        } // fim do if (!$connectionError)
        ?>
        
        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #dee2e6; color: #6c757d; font-size: 0.9em;">
            <strong>ℹ️ Notas importantes:</strong>
            <ul>
                <li>Faça sempre backup da base de dados antes de executar atualizações</li>
                <li>As atualizações são aplicadas apenas uma vez e ficam registadas</li>
                <li>Em caso de erro, verifique os logs do servidor e as permissões da base de dados</li>
            </ul>
        </div>
    </div>
</body>
</html>