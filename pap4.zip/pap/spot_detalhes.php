<?php
/**
 * SkateMap - Detalhes do Spot
 * PAP - Prova de Aptidão Profissional
 */

require_once 'includes/config.php';

// Verificar se o ID do spot foi fornecido
$spot_id = intval($_GET['id'] ?? 0);

if (!$spot_id) {
    $_SESSION['error_message'] = 'Spot não encontrado.';
    redirect(SITE_URL);
}

// Buscar dados do spot
try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com a base de dados');
    }
    
    // Buscar spot com informações do utilizador e estatísticas
    $stmt = $conn->prepare("
        SELECT 
            s.*,
            u.username as autor,
            AVG(a.nota) as rating_medio,
            COUNT(DISTINCT a.id) as total_avaliacoes,
            COUNT(DISTINCT c.id) as total_comentarios
        FROM spots s
        LEFT JOIN utilizadores u ON s.id_usuario = u.id
        LEFT JOIN avaliacoes a ON s.id = a.id_spot
        LEFT JOIN comentarios c ON s.id = c.id_spot
        WHERE s.id = ?
        GROUP BY s.id
    ");
    
    $stmt->execute([$spot_id]);
    $spot = $stmt->fetch();
    
    if (!$spot) {
        $_SESSION['error_message'] = 'Spot não encontrado.';
        redirect(SITE_URL);
    }
    
    // Buscar fotos adicionais
    $stmt = $conn->prepare("SELECT * FROM fotos_spots WHERE id_spot = ? ORDER BY data_envio DESC");
    $stmt->execute([$spot_id]);
    $fotos_adicionais = $stmt->fetchAll();
    
    // Buscar vídeos
    $stmt = $conn->prepare("SELECT * FROM videos_spots WHERE id_spot = ? ORDER BY data_envio DESC");
    $stmt->execute([$spot_id]);
    $videos = $stmt->fetchAll();
    
    // Buscar comentários com informações do utilizador
    $stmt = $conn->prepare("
        SELECT c.*, u.username, u.is_admin
        FROM comentarios c
        LEFT JOIN utilizadores u ON c.id_usuario = u.id
        WHERE c.id_spot = ?
        ORDER BY c.data_publicacao DESC
    ");
    $stmt->execute([$spot_id]);
    $comentarios = $stmt->fetchAll();
    
    // Verificar se o utilizador já avaliou este spot
    $user_rating = null;
    $is_favorited = false;
    if (isLoggedIn()) {
        $stmt = $conn->prepare("SELECT nota FROM avaliacoes WHERE id_spot = ? AND id_usuario = ?");
        $stmt->execute([$spot_id, $_SESSION['user_id']]);
        $rating_row = $stmt->fetch();
        $user_rating = $rating_row ? $rating_row['nota'] : null;
        
        // Verificar se o spot está nos favoritos
        try {
            $stmt = $conn->prepare("SHOW TABLES LIKE 'favoritos'");
            $stmt->execute();
            if ($stmt->fetch()) {
                $stmt = $conn->prepare("SELECT COUNT(*) as total FROM favoritos WHERE id_spot = ? AND id_usuario = ?");
                $stmt->execute([$spot_id, $_SESSION['user_id']]);
                $is_favorited = $stmt->fetch()['total'] > 0;
            }
        } catch (Exception $e) {
            $is_favorited = false;
        }
    }
    
} catch (Exception $e) {
    error_log("Erro ao carregar detalhes do spot: " . $e->getMessage());
    $_SESSION['error_message'] = 'Erro ao carregar informações do spot.';
    redirect(SITE_URL);
}

$page_title = $spot['nome'];
$include_maps_js = true;

require_once 'includes/header.php';

// Processar formulários (comentário, avaliação, upload)
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isLoggedIn()) {
        $error_message = 'Precisa de fazer login para interagir com spots.';
    } else {
        $action = $_POST['action'] ?? '';
        
        try {
            switch ($action) {
                case 'add_comment':
                    $comentario = sanitize($_POST['comentario'] ?? '');
                    if (empty($comentario)) {
                        $error_message = 'O comentário não pode estar vazio.';
                    } else {
                        $stmt = $conn->prepare("
                            INSERT INTO comentarios (id_spot, id_usuario, texto) 
                            VALUES (?, ?, ?)
                        ");
                        if ($stmt->execute([$spot_id, $_SESSION['user_id'], $comentario])) {
                            $success_message = 'Comentário adicionado com sucesso!';
                        } else {
                            $error_message = 'Erro ao adicionar comentário.';
                        }
                    }
                    break;
                    
                case 'add_rating':
                    $nota = intval($_POST['rating'] ?? 0);
                    if ($nota < 1 || $nota > 5) {
                        $error_message = 'A avaliação deve ser entre 1 e 5 estrelas.';
                    } else {
                        // Verificar se já avaliou
                        $stmt = $conn->prepare("SELECT id FROM avaliacoes WHERE id_spot = ? AND id_usuario = ?");
                        $stmt->execute([$spot_id, $_SESSION['user_id']]);
                        
                        if ($stmt->fetch()) {
                            // Atualizar avaliação existente
                            $stmt = $conn->prepare("
                                UPDATE avaliacoes SET nota = ?, data_avaliacao = NOW() 
                                WHERE id_spot = ? AND id_usuario = ?
                            ");
                            if ($stmt->execute([$nota, $spot_id, $_SESSION['user_id']])) {
                                $success_message = 'Avaliação atualizada com sucesso!';
                                $user_rating = $nota;
                            } else {
                                $error_message = 'Erro ao atualizar avaliação.';
                            }
                        } else {
                            // Nova avaliação
                            $stmt = $conn->prepare("
                                INSERT INTO avaliacoes (id_spot, id_usuario, nota) 
                                VALUES (?, ?, ?)
                            ");
                            if ($stmt->execute([$spot_id, $_SESSION['user_id'], $nota])) {
                                $success_message = 'Avaliação adicionada com sucesso!';
                                $user_rating = $nota;
                            } else {
                                $error_message = 'Erro ao adicionar avaliação.';
                            }
                        }
                    }
                    break;
                    
                case 'upload_photo':
                    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                        $foto_nome = uploadFile($_FILES['photo'], 'uploads/spots/');
                        if ($foto_nome) {
                            $stmt = $conn->prepare("
                                INSERT INTO fotos_spots (id_spot, caminho_foto) 
                                VALUES (?, ?)
                            ");
                            if ($stmt->execute([$spot_id, $foto_nome])) {
                                $success_message = 'Foto adicionada com sucesso!';
                            } else {
                                unlink('uploads/spots/' . $foto_nome);
                                $error_message = 'Erro ao adicionar foto.';
                            }
                        } else {
                            $error_message = 'Erro no upload da foto.';
                        }
                    } else {
                        $error_message = 'Por favor, selecione uma foto válida.';
                    }
                    break;
            }
            
            // Recarregar página para mostrar mudanças
            if ($success_message) {
                $_SESSION['success_message'] = $success_message;
                redirect($_SERVER['REQUEST_URI']);
            }
            
        } catch (Exception $e) {
            error_log("Erro ao processar ação: " . $e->getMessage());
            $error_message = 'Erro interno. Tente novamente.';
        }
    }
}
?>

<div class="spot-details-container">
    <div class="container">
        
        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <!-- Cabeçalho do Spot -->
        <div class="spot-header">
            <div class="spot-header-content">
                <div class="spot-title-section">
                    <h1 class="spot-title">
                        <?php echo sanitize($spot['nome']); ?>
                    </h1>
                    
                    <div class="spot-meta">
                        <div class="spot-rating-display">
                            <div class="stars-large">
                                <?php 
                                $rating = $spot['rating_medio'] ?: 0;
                                for ($i = 1; $i <= 5; $i++): 
                                    if ($i <= floor($rating)): ?>
                                        <i class="fas fa-star"></i>
                                    <?php elseif ($i == floor($rating) + 1 && $rating - floor($rating) >= 0.5): ?>
                                        <i class="fas fa-star-half-alt"></i>
                                    <?php else: ?>
                                        <i class="far fa-star"></i>
                                    <?php endif; 
                                endfor; ?>
                            </div>
                            <span class="rating-info">
                                <?php echo number_format($rating, 1); ?> 
                                (<?php echo $spot['total_avaliacoes']; ?> avaliações)
                            </span>
                        </div>
                        
                        <div class="spot-author">
                            <i class="fas fa-user"></i>
                            Por <?php echo sanitize($spot['autor']); ?>
                        </div>
                        
                        <div class="spot-date">
                            <i class="fas fa-calendar"></i>
                            <?php echo date('d/m/Y', strtotime($spot['data_criacao'])); ?>
                        </div>
                    </div>
                </div>
                
                <div class="spot-actions">
                    <button 
                        class="btn btn-primary" 
                        onclick="openDirections(<?php echo $spot['latitude']; ?>, <?php echo $spot['longitude']; ?>)"
                    >
                        <i class="fas fa-directions"></i>
                        Ver Trajeto
                    </button>
                    
                    <button class="btn btn-outline" onclick="shareSpot()">
                        <i class="fas fa-share"></i>
                        Partilhar
                    </button>
                    
                    <?php if (isLoggedIn()): ?>
                        <button class="btn <?php echo $is_favorited ? 'btn-primary' : 'btn-outline'; ?>" 
                                id="favorite-btn" 
                                onclick="toggleFavorite(<?php echo $spot['id']; ?>)"
                                title="<?php echo $is_favorited ? 'Remover dos favoritos' : 'Adicionar aos favoritos'; ?>">
                            <i class="<?php echo $is_favorited ? 'fas' : 'far'; ?> fa-heart"></i>
                            <?php echo $is_favorited ? 'Favoritado' : 'Favorito'; ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Conteúdo Principal -->
        <div class="spot-content">
            <!-- Galeria de Fotos -->
            <div class="spot-gallery">
                <div class="main-photo">
                    <?php 
                    $main_photo = !empty($spot['foto_principal']) ? 
                        "uploads/spots/" . $spot['foto_principal'] : 
                        "assets/images/default-spot.jpg";
                    ?>
                    <img 
                        src="<?php echo $main_photo; ?>" 
                        alt="<?php echo sanitize($spot['nome']); ?>"
                        class="main-photo-img"
                        onerror="this.src='assets/images/default-spot.jpg'"
                    >
                </div>
                
                <?php if (!empty($fotos_adicionais)): ?>
                    <div class="additional-photos">
                        <?php foreach (array_slice($fotos_adicionais, 0, 6) as $foto): ?>
                            <div class="photo-thumb">
                                <img 
                                    src="uploads/spots/<?php echo $foto['caminho_foto']; ?>" 
                                    alt="Foto adicional"
                                    onclick="openLightbox('uploads/spots/<?php echo $foto['caminho_foto']; ?>')"
                                >
                            </div>
                        <?php endforeach; ?>
                        
                        <?php if (count($fotos_adicionais) > 6): ?>
                            <div class="photo-thumb more-photos">
                                <span>+<?php echo count($fotos_adicionais) - 6; ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Informações e Mapa -->
            <div class="spot-info-section">
                <!-- Descrição -->
                <div class="spot-description-card">
                    <h2>
                        <i class="fas fa-info-circle"></i>
                        Sobre este Spot
                    </h2>
                    <p class="spot-description">
                        <?php echo nl2br(sanitize($spot['descricao'])); ?>
                    </p>
                    
                    <div class="spot-location-info">
                        <h3>
                            <i class="fas fa-map-marker-alt"></i>
                            Localização
                        </h3>
                        <p><?php echo sanitize($spot['endereco']); ?></p>
                        <p class="coordinates">
                            <small>
                                Lat: <?php echo $spot['latitude']; ?>, 
                                Lng: <?php echo $spot['longitude']; ?>
                            </small>
                        </p>
                    </div>
                </div>

                <!-- Mapa -->
                <div class="spot-map-card">
                    <h3>
                        <i class="fas fa-map"></i>
                        Localização no Mapa
                    </h3>
                    <div class="map-container">
                        <div id="map"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Avaliações e Interações -->
        <?php if (isLoggedIn()): ?>
        <div class="spot-interactions">
            <div class="interaction-section">
                <!-- Avaliar Spot -->
                <div class="rating-section">
                    <h3>
                        <i class="fas fa-star"></i>
                        <?php echo $user_rating ? 'Sua Avaliação' : 'Avaliar Spot'; ?>
                    </h3>
                    <form method="POST" class="rating-form">
                        <input type="hidden" name="action" value="add_rating">
                        <div class="star-rating" id="starRating">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="star <?php echo $i <= ($user_rating ?: 0) ? 'fas' : 'far'; ?> fa-star" 
                                   data-rating="<?php echo $i; ?>"></i>
                            <?php endfor; ?>
                        </div>
                        <input type="hidden" name="rating" id="ratingValue" value="<?php echo $user_rating ?: 0; ?>">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fas fa-check"></i>
                            <?php echo $user_rating ? 'Atualizar' : 'Avaliar'; ?>
                        </button>
                    </form>
                </div>
                
                <!-- Upload de Foto -->
                <div class="upload-section">
                    <h3>
                        <i class="fas fa-camera"></i>
                        Adicionar Foto
                    </h3>
                    <form method="POST" enctype="multipart/form-data" class="upload-form">
                        <input type="hidden" name="action" value="upload_photo">
                        <div class="file-input-group">
                            <input type="file" name="photo" accept="image/*" class="form-control" required>
                            <button type="submit" class="btn btn-outline btn-sm">
                                <i class="fas fa-upload"></i>
                                Enviar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Comentários -->
        <div class="comments-section">
            <h2 class="section-title">
                <i class="fas fa-comments"></i>
                Comentários (<?php echo count($comentarios); ?>)
            </h2>
            
            <!-- Adicionar Comentário -->
            <?php if (isLoggedIn()): ?>
                <div class="add-comment-section">
                    <form method="POST" class="comment-form">
                        <input type="hidden" name="action" value="add_comment">
                        <div class="form-group">
                            <textarea 
                                name="comentario" 
                                class="form-control" 
                                placeholder="Partilhe a sua experiência neste spot..."
                                rows="3"
                                required
                            ></textarea>
                        </div>
                        <div class="comment-actions">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-paper-plane"></i>
                                Publicar Comentário
                            </button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <div class="login-prompt">
                    <p>
                        <a href="login.php?redirect=<?php echo urlencode($_SERVER['REQUEST_URI']); ?>">
                            Faça login
                        </a> para comentar neste spot.
                    </p>
                </div>
            <?php endif; ?>

            <!-- Lista de Comentários -->
            <div class="comments-list">
                <?php if (empty($comentarios)): ?>
                    <div class="no-comments">
                        <i class="fas fa-comments"></i>
                        <p>Ainda não há comentários. Seja o primeiro a partilhar a sua experiência!</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($comentarios as $comentario): ?>
                        <div class="comment-item">
                            <div class="comment-header">
                                <div class="comment-author">
                                    <i class="fas fa-user-circle"></i>
                                    <strong>
                                        <?php echo sanitize($comentario['username']); ?>
                                        <?php if ($comentario['is_admin']): ?>
                                            <span class="admin-badge">
                                                <i class="fas fa-shield-alt"></i> Admin
                                            </span>
                                        <?php endif; ?>
                                    </strong>
                                </div>
                                <div class="comment-date">
                                    <i class="fas fa-clock"></i>
                                    <?php echo date('d/m/Y H:i', strtotime($comentario['data_publicacao'])); ?>
                                </div>
                            </div>
                            <div class="comment-content">
                                <?php echo nl2br(sanitize($comentario['texto'])); ?>
                            </div>
                            
                            <?php if (isLoggedIn() && ($_SESSION['user_id'] == $comentario['id_usuario'] || isAdmin())): ?>
                                <div class="comment-actions">
                                    <button class="btn-link text-danger" onclick="deleteComment(<?php echo $comentario['id']; ?>)">
                                        <i class="fas fa-trash"></i> Eliminar
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Lightbox para fotos -->
<div class="lightbox" id="lightbox" onclick="closeLightbox()">
    <div class="lightbox-content">
        <img id="lightboxImage" src="" alt="">
        <button class="lightbox-close" onclick="closeLightbox()">
            <i class="fas fa-times"></i>
        </button>
    </div>
</div>

<style>
/* Estilos específicos da página de detalhes do spot */
.spot-details-container {
    padding: 2rem 0;
}

.spot-header {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    margin-bottom: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.spot-header-content {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 2rem;
}

.spot-title {
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
}

.spot-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 2rem;
    color: var(--text-secondary);
}

.spot-rating-display {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.stars-large {
    color: #FFD700;
    font-size: 1.25rem;
}

.rating-info {
    font-weight: 500;
}

.spot-author, .spot-date {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.spot-actions {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.spot-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 2rem;
    margin-bottom: 3rem;
}

.spot-gallery {
    background: var(--surface-color);
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.main-photo-img {
    width: 100%;
    height: 400px;
    object-fit: cover;
}

.additional-photos {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: 0.5rem;
    padding: 1rem;
}

.photo-thumb {
    aspect-ratio: 1;
    border-radius: 8px;
    overflow: hidden;
    cursor: pointer;
    transition: transform 0.3s ease;
    position: relative;
}

.photo-thumb:hover {
    transform: scale(1.05);
}

.photo-thumb img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.photo-thumb.more-photos {
    background: var(--primary-color);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

.spot-info-section {
    display: flex;
    flex-direction: column;
    gap: 2rem;
}

.spot-description-card,
.spot-map-card {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.spot-description-card h2,
.spot-map-card h3 {
    color: var(--primary-color);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.spot-description {
    color: var(--text-primary);
    line-height: 1.6;
    margin-bottom: 2rem;
}

.spot-location-info h3 {
    color: var(--text-primary);
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
}

.coordinates {
    color: var(--text-secondary);
    font-family: monospace;
}

.map-container {
    height: 300px;
    border-radius: 10px;
    overflow: hidden;
}

.spot-interactions {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    margin-bottom: 3rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.interaction-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2rem;
}

.rating-section,
.upload-section {
    padding: 1.5rem;
    background: var(--background-color);
    border-radius: 10px;
    border: 1px solid var(--border-color);
}

.rating-section h3,
.upload-section h3 {
    color: var(--primary-color);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.star-rating {
    display: flex;
    gap: 0.25rem;
    font-size: 2rem;
    margin-bottom: 1rem;
}

.star-rating .star {
    cursor: pointer;
    color: #ddd;
    transition: color 0.3s ease;
}

.star-rating .star.fas {
    color: #FFD700;
}

.star-rating .star:hover {
    color: #FFD700;
}

.file-input-group {
    display: flex;
    gap: 1rem;
    align-items: end;
}

.comments-section {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.section-title {
    color: var(--primary-color);
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    font-size: 1.75rem;
}

.add-comment-section {
    margin-bottom: 2rem;
    padding: 1.5rem;
    background: var(--background-color);
    border-radius: 10px;
    border: 1px solid var(--border-color);
}

.comment-actions {
    display: flex;
    justify-content: flex-end;
    margin-top: 1rem;
}

.login-prompt {
    text-align: center;
    padding: 2rem;
    color: var(--text-secondary);
}

.login-prompt a {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 500;
}

.no-comments {
    text-align: center;
    padding: 3rem;
    color: var(--text-secondary);
}

.no-comments i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.comment-item {
    padding: 1.5rem;
    border-bottom: 1px solid var(--border-color);
    background: var(--background-color);
    border-radius: 10px;
    margin-bottom: 1rem;
}

.comment-item:last-child {
    border-bottom: none;
    margin-bottom: 0;
}

.comment-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.comment-author {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-primary);
}

.admin-badge {
    color: var(--primary-color);
    font-size: 0.875rem;
}

.comment-date {
    color: var(--text-secondary);
    font-size: 0.875rem;
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.comment-content {
    color: var(--text-primary);
    line-height: 1.6;
    margin-bottom: 1rem;
}

.comment-actions {
    display: flex;
    gap: 1rem;
}

.btn-link {
    background: none;
    border: none;
    color: var(--text-secondary);
    text-decoration: none;
    cursor: pointer;
    padding: 0.25rem 0.5rem;
    border-radius: 3px;
    transition: color 0.3s ease;
    font-size: 0.875rem;
}

.btn-link:hover {
    color: var(--text-primary);
}

.btn-link.text-danger {
    color: var(--error-color);
}

.btn-link.text-danger:hover {
    color: #c62828;
}

/* Lightbox */
.lightbox {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.lightbox.active {
    opacity: 1;
    visibility: visible;
}

.lightbox-content {
    position: relative;
    max-width: 90vw;
    max-height: 90vh;
}

.lightbox-content img {
    max-width: 100%;
    max-height: 100%;
    border-radius: 10px;
}

.lightbox-close {
    position: absolute;
    top: -50px;
    right: 0;
    background: rgba(255, 255, 255, 0.2);
    color: white;
    border: none;
    padding: 0.5rem;
    border-radius: 50%;
    cursor: pointer;
    font-size: 1.25rem;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Responsive */
@media (max-width: 1024px) {
    .spot-content {
        grid-template-columns: 1fr;
    }
    
    .interaction-section {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 768px) {
    .spot-header-content {
        flex-direction: column;
        align-items: stretch;
    }
    
    .spot-title {
        font-size: 2rem;
    }
    
    .spot-meta {
        flex-direction: column;
        gap: 1rem;
    }
    
    .spot-actions {
        justify-content: stretch;
    }
    
    .spot-actions .btn {
        flex: 1;
    }
    
    .additional-photos {
        grid-template-columns: repeat(3, 1fr);
    }
    
    .file-input-group {
        flex-direction: column;
        align-items: stretch;
    }
}
</style>

<script>
// JavaScript específico para detalhes do spot
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar mapa centrado no spot
    setTimeout(() => {
        if (window.map) {
            const spotLocation = {
                lat: <?php echo $spot['latitude']; ?>,
                lng: <?php echo $spot['longitude']; ?>
            };
            
            map.setCenter(spotLocation);
            map.setZoom(16);
            
            // Adicionar marcador do spot
            const marker = new google.maps.Marker({
                position: spotLocation,
                map: map,
                title: "<?php echo addslashes($spot['nome']); ?>",
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    fillColor: '#2196F3',
                    fillOpacity: 1,
                    strokeColor: '#1976D2',
                    strokeWeight: 2,
                    scale: 12
                }
            });
        }
    }, 1000);
    
    // Sistema de avaliação por estrelas
    initStarRating();
});

// Sistema de avaliação
function initStarRating() {
    const stars = document.querySelectorAll('.star-rating .star');
    const ratingInput = document.getElementById('ratingValue');
    
    stars.forEach((star, index) => {
        star.addEventListener('click', () => {
            const rating = index + 1;
            ratingInput.value = rating;
            
            // Atualizar estrelas visualmente
            stars.forEach((s, i) => {
                if (i < rating) {
                    s.className = 'star fas fa-star';
                } else {
                    s.className = 'star far fa-star';
                }
            });
        });
        
        star.addEventListener('mouseenter', () => {
            const rating = index + 1;
            
            stars.forEach((s, i) => {
                if (i < rating) {
                    s.style.color = '#FFD700';
                } else {
                    s.style.color = '#ddd';
                }
            });
        });
    });
    
    // Restaurar estado ao sair do mouse
    document.querySelector('.star-rating').addEventListener('mouseleave', () => {
        const currentRating = parseInt(ratingInput.value) || 0;
        
        stars.forEach((star, i) => {
            if (i < currentRating) {
                star.className = 'star fas fa-star';
                star.style.color = '#FFD700';
            } else {
                star.className = 'star far fa-star';
                star.style.color = '#ddd';
            }
        });
    });
}

// Lightbox para fotos
function openLightbox(imageSrc) {
    const lightbox = document.getElementById('lightbox');
    const lightboxImage = document.getElementById('lightboxImage');
    
    lightboxImage.src = imageSrc;
    lightbox.classList.add('active');
    
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.classList.remove('active');
    
    document.body.style.overflow = '';
}

// Partilhar spot
function shareSpot() {
    const url = window.location.href;
    const title = "<?php echo addslashes($spot['nome']); ?>";
    const text = "Confira este spot de skate no SkateMap!";
    
    if (navigator.share) {
        navigator.share({
            title: title,
            text: text,
            url: url
        });
    } else {
        SkateMap.copyToClipboard(url);
        SkateMap.showAlert('Link copiado para a área de transferência!', 'success');
    }
}

// Alternar favorito
function toggleFavorite(spotId) {
    const favoriteBtn = document.getElementById('favorite-btn');
    if (!favoriteBtn || favoriteBtn.classList.contains('loading')) {
        return; // Previne cliques múltiplos
    }
    
    // Adicionar estado de loading
    favoriteBtn.classList.add('loading');
    favoriteBtn.disabled = true;
    const originalContent = favoriteBtn.innerHTML;
    favoriteBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
    
    // Fazer requisição AJAX
    fetch('<?php echo SITE_URL; ?>/api/favorites.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            spot_id: spotId
        })
    })
    .then(response => response.json())
    .then(data => {
        favoriteBtn.classList.remove('loading');
        favoriteBtn.disabled = false;
        
        if (data.success) {
            // Atualizar estado visual do botão
            const icon = favoriteBtn.querySelector('i');
            
            if (data.is_favorite) {
                favoriteBtn.className = 'btn btn-primary';
                icon.className = 'fas fa-heart';
                favoriteBtn.innerHTML = '<i class="fas fa-heart"></i> Favoritado';
                favoriteBtn.title = 'Remover dos favoritos';
            } else {
                favoriteBtn.className = 'btn btn-outline';
                icon.className = 'far fa-heart';
                favoriteBtn.innerHTML = '<i class="far fa-heart"></i> Favorito';
                favoriteBtn.title = 'Adicionar aos favoritos';
            }
            
            // Mostrar feedback visual com animação
            favoriteBtn.style.transform = 'scale(1.1)';
            setTimeout(() => {
                favoriteBtn.style.transform = '';
            }, 200);
            
            // Mostrar toast notification
            showToast(data.message, 'success');
            
        } else {
            favoriteBtn.innerHTML = originalContent;
            const errorMsg = data.message || 'Erro ao alterar favorito';
            showToast(errorMsg, 'error');
            
            // Se for erro de base de dados, mostrar link para correção
            if (errorMsg.includes('favoritos não está disponível')) {
                setTimeout(() => {
                    showToast('Clique <a href="fix_database.php" style="color: white; text-decoration: underline;">aqui</a> para corrigir a base de dados', 'info');
                }, 1000);
            }
        }
    })
    .catch(error => {
        favoriteBtn.classList.remove('loading');
        favoriteBtn.disabled = false;
        favoriteBtn.innerHTML = originalContent;
        console.error('Erro ao alterar favorito:', error);
        
        let errorMessage = 'Erro ao conectar ao servidor. ';
        if (error.message && error.message.includes('Failed to fetch')) {
            errorMessage += 'Verifique se o servidor está a funcionar.';
        } else {
            errorMessage += 'Tente novamente.';
        }
        
        showToast(errorMessage, 'error');
        
        // Sugerir correção da base de dados
        setTimeout(() => {
            showToast('Se o problema persistir, <a href="fix_database.php" style="color: white; text-decoration: underline;">clique aqui</a> para verificar a base de dados', 'info');
        }, 2000);
    });
}

// Função para mostrar toast notifications
function showToast(message, type = 'info') {
    // Remover toasts existentes
    const existingToasts = document.querySelectorAll('.toast');
    existingToasts.forEach(toast => toast.remove());
    
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Adicionar estilos se não existirem
    if (!document.querySelector('#toast-styles')) {
        const styles = document.createElement('style');
        styles.id = 'toast-styles';
        styles.textContent = `
            .toast {
                position: fixed;
                top: 80px;
                right: 20px;
                padding: 15px 20px;
                border-radius: 10px;
                color: white;
                font-weight: 500;
                font-size: 0.95rem;
                z-index: 9999;
                opacity: 0;
                transform: translateX(100px);
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
                max-width: 350px;
                backdrop-filter: blur(10px);
            }
            .toast-success { 
                background: linear-gradient(135deg, #10b981, #059669); 
                border: 1px solid rgba(16, 185, 129, 0.3);
            }
            .toast-error { 
                background: linear-gradient(135deg, #ef4444, #dc2626); 
                border: 1px solid rgba(239, 68, 68, 0.3);
            }
            .toast-info { 
                background: linear-gradient(135deg, #3b82f6, #2563eb); 
                border: 1px solid rgba(59, 130, 246, 0.3);
            }
            .toast-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .toast-content i {
                font-size: 1.1rem;
                flex-shrink: 0;
            }
            .toast.show {
                opacity: 1;
                transform: translateX(0);
            }
            .loading {
                pointer-events: none;
                opacity: 0.7;
            }
            .btn.loading {
                cursor: not-allowed;
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(toast);
    
    // Mostrar toast com delay para animação
    setTimeout(() => toast.classList.add('show'), 100);
    
    // Remover toast após 4 segundos
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            if (document.body.contains(toast)) {
                document.body.removeChild(toast);
            }
        }, 400);
    }, 4000);
}

// Eliminar comentário
function deleteComment(commentId) {
    if (confirm('Tem certeza que deseja eliminar este comentário?')) {
        // Implementar AJAX para eliminar comentário
        SkateMap.showAlert('Funcionalidade de eliminar comentário em desenvolvimento', 'warning');
    }
}
</script>

<style>
/* Estilos específicos para botão de favoritos */
#favorite-btn {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
}

#favorite-btn:not(.loading):hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

#favorite-btn.btn-primary {
    background: linear-gradient(135deg, #ef4444, #dc2626);
    border-color: #dc2626;
    color: white;
}

#favorite-btn.btn-primary:hover {
    background: linear-gradient(135deg, #dc2626, #b91c1c);
    border-color: #b91c1c;
}

#favorite-btn.btn-outline {
    border-color: #ef4444;
    color: #ef4444;
}

#favorite-btn.btn-outline:hover {
    background: #ef4444;
    border-color: #ef4444;
    color: white;
}

#favorite-btn.loading {
    cursor: not-allowed;
    pointer-events: none;
}

#favorite-btn i {
    transition: transform 0.2s ease;
}

#favorite-btn:hover i {
    transform: scale(1.1);
}

/* Animação de pulse no coração quando favoritado */
#favorite-btn.btn-primary i.fa-heart {
    animation: heartPulse 2s ease-in-out infinite;
}

@keyframes heartPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* Melhorar os toasts para esta página */
.toast {
    font-family: inherit;
    line-height: 1.4;
}

.toast-content {
    align-items: flex-start;
}

            .toast-content span {
                flex: 1;
            }
            
            .toast a {
                color: inherit;
                text-decoration: underline;
                font-weight: bold;
            }
            
            .toast a:hover {
                text-decoration: none;
                opacity: 0.8;
            }/* Responsivo para botões de ação */
@media (max-width: 768px) {
    .spot-actions {
        flex-direction: column;
        gap: 0.8rem;
    }
    
    .spot-actions .btn {
        width: 100%;
        justify-content: center;
    }
    
    .toast {
        right: 10px;
        left: 10px;
        max-width: none;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>