/**
 * SkateMap - Funcionalidades do Google Maps
 * PAP - Prova de Aptidão Profissional
 * 
 * Funcionalidades:
 * - Inicialização do mapa
 * - Marcadores de spots
 * - InfoWindows
 * - Geolocalização
 * - Pesquisa de locais
 */

let map;
let markers = [];
let infoWindow;
let userLocation = null;

/**
 * Inicializar o Google Maps
 * Esta função é chamada automaticamente quando a API carrega
 */
function initMap() {
    // Coordenadas de Portugal (centro aproximado)
    const portugalCenter = { lat: 39.5, lng: -8.0 };
    
    // Configurações do mapa
    const mapOptions = {
        zoom: 7,
        center: portugalCenter,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        styles: getMapStyles(),
        controls: {
            fullscreenControl: true,
            mapTypeControl: true,
            streetViewControl: true,
            zoomControl: true
        }
    };
    
    // Criar o mapa
    const mapElement = document.getElementById('map');
    if (mapElement) {
        map = new google.maps.Map(mapElement, mapOptions);
        
        // Inicializar InfoWindow
        infoWindow = new google.maps.InfoWindow();
        
        // Carregar spots existentes
        loadSpots();
        
        // Configurar geolocalização
        setupGeolocation();
        
        // Configurar pesquisa de locais (se existe input de pesquisa)
        setupPlacesSearch();
        
        // Event listeners
        setupMapEventListeners();
        
        console.log('Google Maps inicializado com sucesso!');
    }
}

/**
 * Estilos personalizados do mapa baseados no tema
 */
function getMapStyles() {
    const isDarkTheme = document.body.classList.contains('dark-theme');
    
    if (isDarkTheme) {
        // Estilo escuro
        return [
            { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
            { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
            {
                featureType: "administrative.locality",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "poi",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "poi.park",
                elementType: "geometry",
                stylers: [{ color: "#263c3f" }],
            },
            {
                featureType: "poi.park",
                elementType: "labels.text.fill",
                stylers: [{ color: "#6b9a76" }],
            },
            {
                featureType: "road",
                elementType: "geometry",
                stylers: [{ color: "#38414e" }],
            },
            {
                featureType: "road",
                elementType: "geometry.stroke",
                stylers: [{ color: "#212a37" }],
            },
            {
                featureType: "road",
                elementType: "labels.text.fill",
                stylers: [{ color: "#9ca5b3" }],
            },
            {
                featureType: "road.highway",
                elementType: "geometry",
                stylers: [{ color: "#746855" }],
            },
            {
                featureType: "road.highway",
                elementType: "geometry.stroke",
                stylers: [{ color: "#1f2835" }],
            },
            {
                featureType: "road.highway",
                elementType: "labels.text.fill",
                stylers: [{ color: "#f3d19c" }],
            },
            {
                featureType: "transit",
                elementType: "geometry",
                stylers: [{ color: "#2f3948" }],
            },
            {
                featureType: "transit.station",
                elementType: "labels.text.fill",
                stylers: [{ color: "#d59563" }],
            },
            {
                featureType: "water",
                elementType: "geometry",
                stylers: [{ color: "#17263c" }],
            },
            {
                featureType: "water",
                elementType: "labels.text.fill",
                stylers: [{ color: "#515c6d" }],
            },
            {
                featureType: "water",
                elementType: "labels.text.stroke",
                stylers: [{ color: "#17263c" }],
            },
        ];
    } else {
        // Estilo claro com tons azuis
        return [
            {
                featureType: "water",
                elementType: "geometry",
                stylers: [{ color: "#e9f7fd" }]
            },
            {
                featureType: "landscape",
                elementType: "geometry",
                stylers: [{ color: "#f5f5f5" }]
            },
            {
                featureType: "road",
                elementType: "geometry",
                stylers: [{ color: "#ffffff" }]
            },
            {
                featureType: "poi.park",
                elementType: "geometry",
                stylers: [{ color: "#c8e6c9" }]
            }
        ];
    }
}

/**
 * Carregar spots da base de dados
 */
async function loadSpots() {
    try {
        SkateMap.showLoading('Carregando spots...');
        
        const response = await fetch('api/get_spots.php');
        const data = await response.json();
        
        if (data.success) {
            displaySpots(data.spots);
        } else {
            console.error('Erro ao carregar spots:', data.message);
        }
    } catch (error) {
        console.error('Erro ao carregar spots:', error);
    } finally {
        SkateMap.hideLoading();
    }
}

/**
 * Exibir spots no mapa
 */
function displaySpots(spots) {
    // Limpar marcadores existentes
    clearMarkers();
    
    spots.forEach(spot => {
        addSpotMarker(spot);
    });
    
    console.log(`${spots.length} spots carregados no mapa`);
}

/**
 * Adicionar marcador de spot
 */
function addSpotMarker(spot) {
    const position = {
        lat: parseFloat(spot.latitude),
        lng: parseFloat(spot.longitude)
    };
    
    // Ícone personalizado para spots
    const icon = {
        url: 'assets/images/skate-marker.png', // Criar este ícone
        scaledSize: new google.maps.Size(40, 40),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(20, 40)
    };
    
    // Usar ícone padrão se o personalizado não existir
    const markerOptions = {
        position: position,
        map: map,
        title: spot.nome,
        animation: google.maps.Animation.DROP
    };
    
    // Tentar usar ícone personalizado
    try {
        markerOptions.icon = icon;
    } catch (e) {
        // Usar ícone padrão
        markerOptions.icon = {
            path: google.maps.SymbolPath.CIRCLE,
            fillColor: '#2196F3',
            fillOpacity: 1,
            strokeColor: '#1976D2',
            strokeWeight: 2,
            scale: 10
        };
    }
    
    const marker = new google.maps.Marker(markerOptions);
    
    // Conteúdo do InfoWindow
    const infoContent = createInfoWindowContent(spot);
    
    // Event listener para abrir InfoWindow
    marker.addListener('click', () => {
        infoWindow.setContent(infoContent);
        infoWindow.open(map, marker);
    });
    
    // Adicionar à lista de marcadores
    markers.push(marker);
    
    return marker;
}

/**
 * Criar conteúdo do InfoWindow
 */
function createInfoWindowContent(spot) {
    const photoUrl = spot.foto_principal ? 
        `uploads/spots/${spot.foto_principal}` : 
        'assets/images/default-spot.jpg';
    
    return `
        <div class="spot-info-window">
            <div class="spot-info-header">
                <img src="${photoUrl}" alt="${spot.nome}" class="spot-info-image">
            </div>
            <div class="spot-info-content">
                <h3 class="spot-info-title">${spot.nome}</h3>
                <p class="spot-info-description">${spot.descricao || 'Sem descrição disponível'}</p>
                <div class="spot-info-meta">
                    <div class="spot-rating">
                        ${generateStarsHTML(spot.rating_medio || 0)}
                        <span>(${spot.total_avaliacoes || 0})</span>
                    </div>
                    <div class="spot-date">
                        <i class="fas fa-calendar"></i>
                        ${formatDate(spot.data_criacao)}
                    </div>
                </div>
                <div class="spot-info-actions">
                    <a href="spot_detalhes.php?id=${spot.id}" class="btn btn-primary btn-sm">
                        <i class="fas fa-eye"></i> Ver Detalhes
                    </a>
                    <button onclick="openDirections(${spot.latitude}, ${spot.longitude})" class="btn btn-outline btn-sm">
                        <i class="fas fa-directions"></i> Trajeto
                    </button>
                </div>
            </div>
        </div>
    `;
}

/**
 * Gerar HTML das estrelas para avaliação
 */
function generateStarsHTML(rating) {
    let starsHTML = '<div class="stars">';
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    
    for (let i = 1; i <= 5; i++) {
        if (i <= fullStars) {
            starsHTML += '<i class="fas fa-star"></i>';
        } else if (i === fullStars + 1 && hasHalfStar) {
            starsHTML += '<i class="fas fa-star-half-alt"></i>';
        } else {
            starsHTML += '<i class="far fa-star"></i>';
        }
    }
    
    starsHTML += '</div>';
    return starsHTML;
}

/**
 * Formatar data
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-PT');
}

/**
 * Limpar todos os marcadores
 */
function clearMarkers() {
    markers.forEach(marker => {
        marker.setMap(null);
    });
    markers = [];
}

/**
 * Configurar geolocalização do utilizador
 */
function setupGeolocation() {
    if (navigator.geolocation) {
        const geoButton = createGeolocationButton();
        map.controls[google.maps.ControlPosition.RIGHT_BOTTOM].push(geoButton);
    }
}

/**
 * Criar botão de geolocalização
 */
function createGeolocationButton() {
    const geoButton = document.createElement('button');
    geoButton.textContent = '📍';
    geoButton.title = 'Ir para a minha localização';
    geoButton.className = 'custom-map-control-button';
    geoButton.style.cssText = `
        background: var(--surface-color);
        border: 2px solid var(--border-color);
        border-radius: 3px;
        cursor: pointer;
        font-size: 16px;
        margin: 10px;
        padding: 8px;
        text-align: center;
        width: 40px;
        height: 40px;
        box-shadow: 0 2px 6px var(--shadow-color);
    `;
    
    geoButton.addEventListener('click', () => {
        getCurrentLocation();
    });
    
    return geoButton;
}

/**
 * Obter localização atual do utilizador
 */
function getCurrentLocation() {
    if (!navigator.geolocation) {
        SkateMap.showAlert('Geolocalização não é suportada neste navegador', 'error');
        return;
    }
    
    SkateMap.showLoading('Obtendo localização...');
    
    navigator.geolocation.getCurrentPosition(
        position => {
            const pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            
            userLocation = pos;
            
            // Centrar mapa na localização
            map.setCenter(pos);
            map.setZoom(15);
            
            // Adicionar marcador da localização do utilizador
            addUserLocationMarker(pos);
            
            SkateMap.hideLoading();
            SkateMap.showAlert('Localização obtida com sucesso!', 'success');
        },
        error => {
            SkateMap.hideLoading();
            let errorMessage = 'Erro ao obter localização';
            
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage = 'Permissão de localização negada';
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage = 'Localização não disponível';
                    break;
                case error.TIMEOUT:
                    errorMessage = 'Timeout ao obter localização';
                    break;
            }
            
            SkateMap.showAlert(errorMessage, 'error');
        }
    );
}

/**
 * Adicionar marcador da localização do utilizador
 */
function addUserLocationMarker(position) {
    // Remover marcador anterior se existir
    if (window.userLocationMarker) {
        window.userLocationMarker.setMap(null);
    }
    
    window.userLocationMarker = new google.maps.Marker({
        position: position,
        map: map,
        title: 'A sua localização',
        icon: {
            path: google.maps.SymbolPath.CIRCLE,
            fillColor: '#4285F4',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2,
            scale: 8
        }
    });
}

/**
 * Configurar pesquisa de locais
 */
function setupPlacesSearch() {
    const searchInput = document.getElementById('location-search');
    if (searchInput && google.maps.places) {
        const autocomplete = new google.maps.places.Autocomplete(searchInput, {
            componentRestrictions: { country: 'pt' },
            fields: ['place_id', 'geometry', 'name', 'formatted_address']
        });
        
        autocomplete.addListener('place_changed', () => {
            const place = autocomplete.getPlace();
            
            if (!place.geometry) {
                SkateMap.showAlert('Local não encontrado', 'error');
                return;
            }
            
            // Centrar mapa no local selecionado
            if (place.geometry.viewport) {
                map.fitBounds(place.geometry.viewport);
            } else {
                map.setCenter(place.geometry.location);
                map.setZoom(17);
            }
            
            // Preencher campos de latitude/longitude se existirem
            const latInput = document.getElementById('latitude');
            const lngInput = document.getElementById('longitude');
            const addressInput = document.getElementById('endereco');
            
            if (latInput) latInput.value = place.geometry.location.lat();
            if (lngInput) lngInput.value = place.geometry.location.lng();
            if (addressInput) addressInput.value = place.formatted_address;
        });
    }
}

/**
 * Configurar event listeners do mapa
 */
function setupMapEventListeners() {
    // Clique no mapa (para adicionar spot)
    if (window.location.pathname.includes('add_spot.php')) {
        map.addListener('click', (e) => {
            const lat = e.latLng.lat();
            const lng = e.latLng.lng();
            
            // Preencher campos
            const latInput = document.getElementById('latitude');
            const lngInput = document.getElementById('longitude');
            
            if (latInput) latInput.value = lat;
            if (lngInput) lngInput.value = lng;
            
            // Adicionar marcador temporário
            if (window.tempMarker) {
                window.tempMarker.setMap(null);
            }
            
            window.tempMarker = new google.maps.Marker({
                position: { lat, lng },
                map: map,
                draggable: true,
                title: 'Localização do novo spot'
            });
            
            // Atualizar coordenadas quando arrastar
            window.tempMarker.addListener('dragend', (e) => {
                if (latInput) latInput.value = e.latLng.lat();
                if (lngInput) lngInput.value = e.latLng.lng();
            });
            
            // Obter endereço via geocoding reverso
            reverseGeocode(lat, lng);
        });
    }
    
    // Atualizar estilos quando o tema mudar
    document.addEventListener('themeChanged', () => {
        map.setOptions({ styles: getMapStyles() });
    });
}

/**
 * Geocoding reverso para obter endereço
 */
function reverseGeocode(lat, lng) {
    const geocoder = new google.maps.Geocoder();
    const latlng = { lat, lng };
    
    geocoder.geocode({ location: latlng }, (results, status) => {
        if (status === 'OK' && results[0]) {
            const addressInput = document.getElementById('endereco');
            if (addressInput) {
                addressInput.value = results[0].formatted_address;
            }
        }
    });
}

/**
 * Abrir direções no Google Maps
 */
function openDirections(lat, lng) {
    if (!lat || !lng) {
        console.error('Coordenadas inválidas:', lat, lng);
        if (typeof SkateMap !== 'undefined' && SkateMap.showAlert) {
            SkateMap.showAlert('Coordenadas do spot não disponíveis', 'error');
        }
        return;
    }
    
    // URL do Google Maps com direções e modo de transporte
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=driving`;
    
    try {
        const newWindow = window.open(url, '_blank');
        if (newWindow) {
            newWindow.focus();
            if (typeof SkateMap !== 'undefined' && SkateMap.showAlert) {
                SkateMap.showAlert('Abrindo Google Maps...', 'success');
            }
        } else {
            // Fallback se popup for bloqueado
            if (confirm('Popup bloqueado. Deseja abrir o Google Maps na mesma aba?')) {
                window.location.href = url;
            }
        }
    } catch (error) {
        console.error('Erro ao abrir Google Maps:', error);
        if (typeof SkateMap !== 'undefined' && SkateMap.showAlert) {
            SkateMap.showAlert('Erro ao abrir Google Maps', 'error');
        }
    }
}

/**
 * Centrar mapa num spot específico
 */
function focusSpot(spotId) {
    const marker = markers.find(m => m.spotId === spotId);
    if (marker) {
        map.setCenter(marker.getPosition());
        map.setZoom(17);
        google.maps.event.trigger(marker, 'click');
    }
}

/**
 * Filtrar spots por categoria (funcionalidade futura)
 */
function filterSpotsByCategory(category) {
    // Implementar filtro por categoria
    // Por agora, recarregar todos os spots
    loadSpots();
}

/**
 * Pesquisar spots próximos
 */
function findNearbySpots(radius = 5000) { // 5km por padrão
    if (!userLocation) {
        getCurrentLocation();
        return;
    }
    
    // Filtrar marcadores por distância
    const nearbyMarkers = markers.filter(marker => {
        const distance = calculateDistance(
            userLocation.lat, userLocation.lng,
            marker.getPosition().lat(), marker.getPosition().lng()
        );
        return distance <= radius;
    });
    
    // Mostrar apenas spots próximos
    clearMarkers();
    nearbyMarkers.forEach(marker => {
        marker.setMap(map);
    });
    
    SkateMap.showAlert(`Encontrados ${nearbyMarkers.length} spots num raio de ${radius/1000}km`, 'success');
}

/**
 * Calcular distância entre dois pontos (fórmula de Haversine)
 */
function calculateDistance(lat1, lng1, lat2, lng2) {
    const R = 6371e3; // Raio da Terra em metros
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lng2-lng1) * Math.PI/180;
    
    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    
    return R * c; // Distância em metros
}

// Expor funções necessárias globalmente
window.initMap = initMap;
window.focusSpot = focusSpot;
window.openDirections = openDirections;
window.findNearbySpots = findNearbySpots;