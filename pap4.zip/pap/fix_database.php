<?php
/**
 * Script rápido para criar a tabela de favoritos
 */

require_once 'includes/config.php';

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão');
    }
    
    // Verificar se tabela favoritos já existe
    $stmt = $conn->prepare("SHOW TABLES LIKE 'favoritos'");
    $stmt->execute();
    
    if ($stmt->fetch()) {
        echo "✅ Tabela 'favoritos' já existe!<br>";
    } else {
        echo "❌ Tabela 'favoritos' não existe. Criando...<br>";
        
        // Criar tabela favoritos
        $sql = "
            CREATE TABLE favoritos (
                id INT AUTO_INCREMENT PRIMARY KEY,
                id_usuario INT NOT NULL,
                id_spot INT NOT NULL,
                data_favorito TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
                FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
                UNIQUE KEY unique_user_spot_favorite (id_usuario, id_spot),
                INDEX idx_usuario (id_usuario),
                INDEX idx_spot (id_spot),
                INDEX idx_data (data_favorito)
            )
        ";
        
        $conn->exec($sql);
        echo "✅ Tabela 'favoritos' criada com sucesso!<br>";
    }
    
    // Verificar se campo comentario existe na tabela avaliacoes
    $stmt = $conn->prepare("SHOW COLUMNS FROM avaliacoes LIKE 'comentario'");
    $stmt->execute();
    
    if ($stmt->fetch()) {
        echo "✅ Campo 'comentario' já existe na tabela avaliacoes!<br>";
    } else {
        echo "❌ Campo 'comentario' não existe. Adicionando...<br>";
        
        $sql = "ALTER TABLE avaliacoes ADD COLUMN comentario TEXT DEFAULT NULL AFTER nota";
        $conn->exec($sql);
        echo "✅ Campo 'comentario' adicionado com sucesso!<br>";
    }
    
    echo "<br><strong>🎉 Base de dados atualizada!</strong><br>";
    echo "<a href='spot_detalhes.php?id=1'>Testar favoritos</a> | ";
    echo "<a href='index.php'>Voltar ao início</a>";
    
} catch (Exception $e) {
    echo "❌ Erro: " . $e->getMessage();
}
?>