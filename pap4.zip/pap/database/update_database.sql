-- SkateMap Database Update Script
-- PAP - Prova de Aptidão Profissional
-- Script para atualizar a base de dados com novas funcionalidades

USE skatemap;

-- =========================================
-- 1. TABELA DE FAVORITOS
-- =========================================

-- Criar tabela de favoritos para spots
CREATE TABLE IF NOT EXISTS favoritos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_spot INT NOT NULL,
    data_favorito TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
    FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_spot_favorite (id_usuario, id_spot),
    INDEX idx_usuario (id_usuario),
    INDEX idx_spot (id_spot),
    INDEX idx_data (data_favorito)
);

-- =========================================
-- 2. MELHORAR TABELA DE AVALIAÇÕES
-- =========================================

-- Adicionar campo comentario na tabela avaliacoes (se não existir)
ALTER TABLE avaliacoes 
ADD COLUMN IF NOT EXISTS comentario TEXT DEFAULT NULL 
AFTER nota;

-- Atualizar a constraint para incluir comentários
ALTER TABLE avaliacoes 
DROP INDEX IF EXISTS unique_user_spot,
ADD UNIQUE KEY unique_user_spot (id_spot, id_usuario);

-- =========================================
-- 3. ADICIONAR ÍNDICES PARA PERFORMANCE
-- =========================================

-- Índices adicionais para otimizar consultas de favoritos
CREATE INDEX IF NOT EXISTS idx_spots_usuario_data ON spots(id_usuario, data_criacao);
CREATE INDEX IF NOT EXISTS idx_avaliacoes_nota ON avaliacoes(nota);
CREATE INDEX IF NOT EXISTS idx_comentarios_data ON comentarios(data_publicacao);

-- =========================================
-- 4. VIEWS PARA OTIMIZAR CONSULTAS
-- =========================================

-- View para estatísticas de spots (incluindo favoritos)
CREATE OR REPLACE VIEW vw_spots_stats AS
SELECT 
    s.id,
    s.nome,
    s.descricao,
    s.endereco,
    s.latitude,
    s.longitude,
    s.foto_principal,
    s.data_criacao,
    s.id_usuario,
    u.username as usuario_nome,
    COALESCE(AVG(a.nota), 0) as rating_medio,
    COUNT(DISTINCT a.id) as total_avaliacoes,
    COUNT(DISTINCT f.id) as total_favoritos,
    COUNT(DISTINCT c.id) as total_comentarios,
    COUNT(DISTINCT fs.id) as total_fotos,
    COUNT(DISTINCT vs.id) as total_videos
FROM spots s
LEFT JOIN utilizadores u ON s.id_usuario = u.id
LEFT JOIN avaliacoes a ON s.id = a.id_spot
LEFT JOIN favoritos f ON s.id = f.id_spot
LEFT JOIN comentarios c ON s.id = c.id_spot
LEFT JOIN fotos_spots fs ON s.id = fs.id_spot
LEFT JOIN videos_spots vs ON s.id = vs.id_spot
GROUP BY s.id, s.nome, s.descricao, s.endereco, s.latitude, s.longitude, 
         s.foto_principal, s.data_criacao, s.id_usuario, u.username;

-- View para estatísticas de utilizadores
CREATE OR REPLACE VIEW vw_user_stats AS
SELECT 
    u.id,
    u.username,
    u.email,
    u.is_admin,
    u.data_criacao,
    COUNT(DISTINCT s.id) as total_spots,
    COUNT(DISTINCT a.id) as total_avaliacoes,
    COALESCE(AVG(a.nota), 0) as media_avaliacoes,
    COUNT(DISTINCT f.id) as total_favoritos,
    COUNT(DISTINCT c.id) as total_comentarios
FROM utilizadores u
LEFT JOIN spots s ON u.id = s.id_usuario
LEFT JOIN avaliacoes a ON u.id = a.id_usuario
LEFT JOIN favoritos f ON u.id = f.id_usuario
LEFT JOIN comentarios c ON u.id = c.id_usuario
GROUP BY u.id, u.username, u.email, u.is_admin, u.data_criacao;

-- =========================================
-- 5. STORED PROCEDURES ÚTEIS
-- =========================================

-- Procedure para adicionar/remover favorito
DELIMITER //
CREATE OR REPLACE PROCEDURE sp_toggle_favorite(
    IN p_user_id INT,
    IN p_spot_id INT,
    OUT p_is_favorite BOOLEAN
)
BEGIN
    DECLARE favorite_exists INT DEFAULT 0;
    
    -- Verificar se já existe
    SELECT COUNT(*) INTO favorite_exists 
    FROM favoritos 
    WHERE id_usuario = p_user_id AND id_spot = p_spot_id;
    
    IF favorite_exists > 0 THEN
        -- Remover favorito
        DELETE FROM favoritos 
        WHERE id_usuario = p_user_id AND id_spot = p_spot_id;
        SET p_is_favorite = FALSE;
    ELSE
        -- Adicionar favorito
        INSERT INTO favoritos (id_usuario, id_spot) 
        VALUES (p_user_id, p_spot_id);
        SET p_is_favorite = TRUE;
    END IF;
END //
DELIMITER ;

-- =========================================
-- 6. TRIGGER PARA MANTER CACHE DE ESTATÍSTICAS
-- =========================================

-- Trigger para atualizar estatísticas quando favorito é adicionado
DELIMITER //
CREATE OR REPLACE TRIGGER tr_favoritos_stats_insert
AFTER INSERT ON favoritos
FOR EACH ROW
BEGIN
    -- Pode ser usado para cache de estatísticas se necessário
    -- Por agora deixamos as consultas diretas para simplicidade
    NULL;
END //

CREATE OR REPLACE TRIGGER tr_favoritos_stats_delete
AFTER DELETE ON favoritos
FOR EACH ROW
BEGIN
    -- Pode ser usado para cache de estatísticas se necessário
    -- Por agora deixamos as consultas diretas para simplicidade
    NULL;
END //
DELIMITER ;

-- =========================================
-- 7. DADOS DE EXEMPLO PARA TESTE
-- =========================================

-- Adicionar algumas avaliações com comentários de exemplo
INSERT IGNORE INTO avaliacoes (id_spot, id_usuario, nota, comentario) VALUES
(1, 1, 5, 'Excelente spot para iniciantes e avançados! Muito bem conservado.'),
(2, 1, 4, 'Boa localização no centro da cidade, mas pode ficar muito movimentado.');

-- Adicionar alguns favoritos de exemplo
INSERT IGNORE INTO favoritos (id_usuario, id_spot) VALUES
(1, 1),
(1, 2);

-- =========================================
-- VERIFICAÇÃO DO UPDATE
-- =========================================

-- Mostrar estatísticas após update
SELECT 'Tabelas criadas/atualizadas com sucesso!' as Status;

SELECT 
    TABLE_NAME as 'Tabela',
    TABLE_ROWS as 'Registos',
    CREATE_TIME as 'Criada em'
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'skatemap' 
AND TABLE_NAME IN ('favoritos', 'avaliacoes', 'spots', 'utilizadores')
ORDER BY TABLE_NAME;