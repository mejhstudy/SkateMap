<?php
/**
 * Teste de conexão com a base de dados
 */

require_once 'includes/config.php';

echo "<h1>Teste de Conexão SkateMap</h1>";

// Testar conexão básica
try {
    $dsn = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    echo "<p style='color: green;'>✅ Conexão com MySQL estabelecida!</p>";
    
    // Verificar se a base de dados existe
    $stmt = $pdo->query("SHOW DATABASES LIKE 'skatemap'");
    if ($stmt->rowCount() > 0) {
        echo "<p style='color: green;'>✅ Base de dados 'skatemap' existe!</p>";
        
        // Conectar à base de dados específica
        $conn = getConnection();
        if ($conn) {
            echo "<p style='color: green;'>✅ Conexão com a base de dados skatemap estabelecida!</p>";
            
            // Verificar tabelas
            $tables = ['utilizadores', 'spots', 'fotos_spots', 'videos_spots', 'comentarios', 'avaliacoes'];
            foreach ($tables as $table) {
                $stmt = $conn->query("SHOW TABLES LIKE '$table'");
                if ($stmt->rowCount() > 0) {
                    echo "<p style='color: green;'>✅ Tabela '$table' existe!</p>";
                } else {
                    echo "<p style='color: red;'>❌ Tabela '$table' NÃO existe!</p>";
                }
            }
            
            // Verificar se há utilizadores
            $stmt = $conn->query("SELECT COUNT(*) as total FROM utilizadores");
            $result = $stmt->fetch();
            echo "<p style='color: blue;'>ℹ️ Total de utilizadores: " . $result['total'] . "</p>";
            
        } else {
            echo "<p style='color: red;'>❌ Erro ao conectar com a base de dados skatemap!</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Base de dados 'skatemap' NÃO existe!</p>";
        echo "<p style='color: orange;'>⚠️ Precisa de importar o arquivo skatemap.sql</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Erro de conexão: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h2>Instruções:</h2>";
echo "<ol>";
echo "<li>Certifique-se de que o WampServer está a correr</li>";
echo "<li>Aceda ao phpMyAdmin: <a href='http://localhost/phpmyadmin' target='_blank'>http://localhost/phpmyadmin</a></li>";
echo "<li>Importe o arquivo 'database/skatemap.sql'</li>";
echo "<li>Ou execute o SQL directamente no phpMyAdmin</li>";
echo "</ol>";
?>