# SkateMap - Mapa Colaborativo de Skate Spots em Portugal

## 📋 Sobre o Projeto

O **SkateMap** é um projeto desenvolvido para a PAP (Prova de Aptidão Profissional) que consiste num mapa colaborativo de spots de skate em Portugal. O projeto permite aos utilizadores descobrir, adicionar e avaliar spots de skate em todo o país.

### 🎯 Funcionalidades Principais

- **Sistema de Autenticação**: Registo e login de utilizadores
- **Mapa Interativo**: Visualização de spots no Google Maps
- **Gestão de Spots**: Adicionar, visualizar e avaliar spots
- **Sistema de Comentários**: Partilhar experiências e dicas
- **Upload de Media**: Fotos e vídeos dos spots
- **Painel Administrativo**: Gestão completa do sistema
- **Tema Dark/Light**: Alternância entre temas claro e escuro
- **Design Responsivo**: Funciona em todos os dispositivos

## 🛠️ Tecnologias Utilizadas

- **Backend**: PHP 7.4+ com PDO/MySQL
- **Frontend**: HTML5, CSS3, JavaScript ES6
- **Base de Dados**: MySQL 5.7+
- **APIs**: Google Maps JavaScript API
- **Design**: CSS Grid, Flexbox, Font Awesome

## 📦 Estrutura do Projeto

```
skatemap/
├── admin/                  # Painel administrativo
│   ├── index.php          # Dashboard do admin
│   ├── spots.php          # Gestão de spots
│   ├── users.php          # Gestão de utilizadores
│   └── comments.php       # Gestão de comentários
├── api/                   # APIs para comunicação AJAX
│   └── get_spots.php      # API para buscar spots
├── assets/                # Recursos estáticos
│   ├── css/
│   │   └── style.css      # Estilos principais
│   ├── js/
│   │   ├── main.js        # JavaScript principal
│   │   └── maps.js        # Funcionalidades do Google Maps
│   └── images/            # Imagens do sistema
├── database/              # Scripts da base de dados
│   └── skatemap.sql       # Estrutura e dados iniciais
├── includes/              # Arquivos incluídos
│   ├── config.php         # Configurações e conexão BD
│   ├── header.php         # Cabeçalho comum
│   └── footer.php         # Rodapé comum
├── uploads/               # Arquivos enviados pelos utilizadores
│   ├── spots/             # Fotos dos spots
│   └── videos/            # Vídeos dos spots
├── index.php              # Página principal
├── login.php              # Página de login
├── register.php           # Página de registo
├── add_spot.php           # Adicionar novo spot
├── spot_detalhes.php      # Detalhes do spot
├── logout.php             # Logout
└── README.md              # Este arquivo
```

## ⚙️ Requisitos do Sistema

### Servidor Web
- **Apache** 2.4+ ou **Nginx** 1.18+
- **PHP** 7.4+ com extensões:
  - PDO
  - PDO_MySQL
  - GD ou Imagick (para processamento de imagens)
  - mbstring
  - fileinfo

### Base de Dados
- **MySQL** 5.7+ ou **MariaDB** 10.3+

### APIs Externas
- **Google Maps JavaScript API** (chave necessária)

## 🚀 Instalação

### 1. Clonar/Descarregar o Projeto

```bash
# Se usando Git
git clone [URL_DO_REPOSITORIO]

# Ou descarregue e extraia o arquivo ZIP
```

### 2. Configurar o Servidor Web

#### Apache (.htaccess já incluído)
```apache
# Certifique-se de que mod_rewrite está ativado
a2enmod rewrite
systemctl restart apache2
```

#### Nginx
```nginx
server {
    listen 80;
    server_name localhost;
    root /caminho/para/skatemap;
    
    index index.php index.html;
    
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }
    
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

### 3. Configurar a Base de Dados

1. **Criar a base de dados**:
```sql
CREATE DATABASE skatemap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

2. **Importar a estrutura**:
```bash
mysql -u root -p skatemap < database/skatemap.sql
```

3. **Ou usando phpMyAdmin**:
   - Aceder ao phpMyAdmin
   - Criar nova base de dados "skatemap"
   - Importar o arquivo `database/skatemap.sql`

### 4. Configurar as Definições

Editar o arquivo `includes/config.php`:

```php
// Configurações da base de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'skatemap');
define('DB_USER', 'seu_usuario');     // Alterar
define('DB_PASS', 'sua_password');    // Alterar

// URL do site
define('SITE_URL', 'http://localhost/skatemap'); // Alterar para seu domínio

// Chave da API do Google Maps
define('GOOGLE_MAPS_API_KEY', 'SUA_CHAVE_AQUI'); // Obter em console.cloud.google.com
```

### 5. Configurar Permissões

```bash
# Dar permissões de escrita nas pastas de upload
chmod 755 uploads/
chmod 755 uploads/spots/
chmod 755 uploads/videos/

# No Linux/Mac, pode ser necessário:
chown -R www-data:www-data uploads/
```

### 6. Obter Chave da API do Google Maps

1. Aceder a [Google Cloud Console](https://console.cloud.google.com/)
2. Criar um novo projeto ou selecionar um existente
3. Ativar as APIs:
   - Maps JavaScript API
   - Places API
   - Geocoding API
4. Criar credenciais (API Key)
5. Configurar restrições de domínio
6. Copiar a chave para `includes/config.php`

## 👤 Utilizadores Padrão

Após a instalação, estarão disponíveis:

### Administrador
- **Username**: `admin`
- **Email**: `admin@skatemap.pt`
- **Password**: `admin123`

> ⚠️ **Importante**: Altere a password do administrador após a primeira utilização!

## 🔧 Configuração Adicional

### Configurar Email (Opcional)
Para funcionalidades futuras de recuperação de password:

```php
// Em includes/config.php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'seu@email.com');
define('SMTP_PASSWORD', 'sua_password');
```

### Configurar SSL (Recomendado)
```bash
# Com Certbot (Let's Encrypt)
sudo certbot --apache -d seudominio.com
```

### Otimizações de Performance

1. **Ativar compressão Gzip**:
```apache
# No .htaccess
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>
```

2. **Cache de navegador**:
```apache
# No .htaccess
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 month"
    ExpiresByType image/jpeg "access plus 1 month"
    ExpiresByType image/gif "access plus 1 month"
    ExpiresByType image/png "access plus 1 month"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/pdf "access plus 1 month"
    ExpiresByType text/javascript "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

## 🐛 Resolução de Problemas

### Erro de Conexão com a Base de Dados
```
Erro: SQLSTATE[HY000] [1045] Access denied
```
**Solução**: Verificar credenciais em `includes/config.php`

### Erro de Upload de Ficheiros
```
Erro: Failed to move uploaded file
```
**Solução**: Verificar permissões da pasta `uploads/`

### Google Maps não Carrega
```
Erro: Google Maps API key error
```
**Solução**: 
1. Verificar se a chave API está correta
2. Confirmar se as APIs necessárias estão ativadas
3. Verificar restrições de domínio

### Tema Não Funciona
**Solução**: Verificar se JavaScript está ativado no navegador

## 📱 Funcionalidades

### Para Utilizadores
- ✅ Registo e login
- ✅ Visualizar spots no mapa
- ✅ Adicionar novos spots
- ✅ Comentar e avaliar spots
- ✅ Upload de fotos
- ✅ Tema dark/light
- ✅ Design responsivo

### Para Administradores
- ✅ Dashboard com estatísticas
- ✅ Gestão de spots
- ✅ Gestão de utilizadores
- ✅ Gestão de comentários
- ✅ Moderação de conteúdo

## 🔮 Funcionalidades Futuras

- [ ] Sistema de notificações
- [ ] Chat entre utilizadores
- [ ] Spots favoritos
- [ ] Filtros avançados no mapa
- [ ] API REST completa
- [ ] App móvel
- [ ] Sistema de badges/conquistas
- [ ] Integração com redes sociais

## 🤝 Contribuição

Este é um projeto académico (PAP), mas sugestões são bem-vindas:

1. Criar um Issue para reportar bugs
2. Sugerir melhorias
3. Contribuir com código (Pull Requests)

## 📄 Licença

Este projeto foi desenvolvido para fins académicos (PAP - Prova de Aptidão Profissional).

## 📞 Suporte

Para questões relacionadas com o projeto:

- **Email**: [seu-email@dominio.com]
- **GitHub**: [seu-usuario-github]

## 🙏 Agradecimentos

- **Google Maps API** pela plataforma de mapas
- **Font Awesome** pelos ícones
- **Comunidade de skate portuguesa** pela inspiração

---

**Desenvolvido com ❤️ para a comunidade de skate portuguesa**

*SkateMap - PAP 2024*