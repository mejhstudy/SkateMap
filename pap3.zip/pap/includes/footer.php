    </main>
    <!-- Main Content End -->
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3><i class="fas fa-map-marked-alt"></i> SkateMap</h3>
                    <p>O mapa colaborativo de skate spots em Portugal. Descobre, adiciona e avalia os melhores spots de skate do país.</p>
                    <div class="social-links">
                        <a href="#" title="Facebook"><i class="fab fa-facebook"></i></a>
                        <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" title="YouTube"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
                
                <div class="footer-section">
                    <h4>Links Rápidos</h4>
                    <ul>
                        <li><a href="<?php echo SITE_URL; ?>">Início</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="<?php echo SITE_URL; ?>/add_spot.php">Adicionar Spot</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo SITE_URL; ?>/login.php">Entrar</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/register.php">Registar</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Suporte</h4>
                    <ul>
                        <li><a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Ajuda</a></li>
                        <li><a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Contacto</a></li>
                        <li><a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Termos de Uso</a></li>
                        <li><a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Privacidade</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h4>Estatísticas</h4>
                    <div class="stats">
                        <?php
                        try {
                            $conn = getConnection();
                            if ($conn) {
                                // Contar spots totais
                                $stmt = $conn->query("SELECT COUNT(*) as total FROM spots");
                                $totalSpots = $stmt->fetch()['total'];
                                
                                // Contar utilizadores
                                $stmt = $conn->query("SELECT COUNT(*) as total FROM utilizadores WHERE is_admin = 0");
                                $totalUsers = $stmt->fetch()['total'];
                                
                                // Contar comentários
                                $stmt = $conn->query("SELECT COUNT(*) as total FROM comentarios");
                                $totalComments = $stmt->fetch()['total'];
                                
                                echo "<p><i class='fas fa-map-pin'></i> {$totalSpots} Spots</p>";
                                echo "<p><i class='fas fa-users'></i> {$totalUsers} Utilizadores</p>";
                                echo "<p><i class='fas fa-comments'></i> {$totalComments} Comentários</p>";
                            }
                        } catch (Exception $e) {
                            echo "<p><i class='fas fa-map-pin'></i> -- Spots</p>";
                            echo "<p><i class='fas fa-users'></i> -- Utilizadores</p>";
                            echo "<p><i class='fas fa-comments'></i> -- Comentários</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="footer-bottom-content">
                    <p>&copy; <?php echo date('Y'); ?> SkateMap - PAP (Prova de Aptidão Profissional). Todos os direitos reservados.</p>
                    <p>Desenvolvido com <i class="fas fa-heart text-red"></i> para a comunidade de skate portuguesa.</p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Scripts JavaScript -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
    
    <!-- Script específico para mapas (se necessário) -->
    <?php if (isset($load_maps_js) && $load_maps_js): ?>
        <script src="<?php echo SITE_URL; ?>/assets/js/maps.js"></script>
    <?php endif; ?>
    
    <!-- Scripts adicionais da página -->
    <?php if (isset($additional_scripts)): ?>
        <?php foreach ($additional_scripts as $script): ?>
            <script src="<?php echo $script; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Loading overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner">
            <i class="fas fa-spinner fa-spin"></i>
            <p>Carregando...</p>
        </div>
    </div>
    
</body>
</html>