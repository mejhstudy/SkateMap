/**
 * SkateMap - JavaScript Principal
 * PAP - Prova de Aptidão Profissional
 * 
 * Funcionalidades:
 * - Sistema de temas (Dark/Light Mode)
 * - Menu móvel
 * - Interações gerais da UI
 * - Validações de formulários
 */

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar todas as funcionalidades
    initThemeSystem();
    initMobileMenu();
    initAlerts();
    initFormValidations();
    initImagePreview();
    initLoadingOverlay();
    
    console.log('SkateMap JavaScript carregado com sucesso!');
});

/**
 * Sistema de Temas (Dark Mode / Light Mode)
 */
function initThemeSystem() {
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = document.getElementById('themeIcon');
    const body = document.body;
    
    if (!themeToggle) return;
    
    // Verificar tema salvo no localStorage
    const savedTheme = localStorage.getItem('theme') || 'light-theme';
    body.className = savedTheme;
    updateThemeIcon(savedTheme);
    
    // Event listener para alternar tema
    themeToggle.addEventListener('click', function() {
        const currentTheme = body.className;
        const newTheme = currentTheme === 'light-theme' ? 'dark-theme' : 'light-theme';
        
        body.className = newTheme;
        localStorage.setItem('theme', newTheme);
        updateThemeIcon(newTheme);
        
        // Salvar também num cookie para o PHP
        document.cookie = `theme=${newTheme}; path=/; max-age=31536000`; // 1 ano
        
        // Animação suave
        body.style.transition = 'all 0.3s ease';
        setTimeout(() => {
            body.style.transition = '';
        }, 300);
    });
}

/**
 * Atualizar ícone do tema
 */
function updateThemeIcon(theme) {
    const themeIcon = document.getElementById('themeIcon');
    if (!themeIcon) return;
    
    if (theme === 'dark-theme') {
        themeIcon.className = 'fas fa-sun';
        themeIcon.parentElement.title = 'Alternar para tema claro';
    } else {
        themeIcon.className = 'fas fa-moon';
        themeIcon.parentElement.title = 'Alternar para tema escuro';
    }
}

/**
 * Menu Móvel
 */
function initMobileMenu() {
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const mobileMenuOverlay = document.getElementById('mobileMenuOverlay');
    
    if (!mobileMenuToggle || !mobileMenuOverlay) return;
    
    // Abrir menu
    mobileMenuToggle.addEventListener('click', function() {
        mobileMenuOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Animação do botão hamburger
        const spans = mobileMenuToggle.querySelectorAll('span');
        spans[0].style.transform = 'rotate(45deg) translate(6px, 6px)';
        spans[1].style.opacity = '0';
        spans[2].style.transform = 'rotate(-45deg) translate(6px, -6px)';
    });
    
    // Fechar menu
    mobileMenuOverlay.addEventListener('click', function(e) {
        if (e.target === mobileMenuOverlay) {
            closeMobileMenu();
        }
    });
    
    // Fechar menu ao clicar em link
    const mobileNavLinks = document.querySelectorAll('.mobile-nav-links a');
    mobileNavLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });
}

/**
 * Fechar menu móvel
 */
function closeMobileMenu() {
    const mobileMenuOverlay = document.getElementById('mobileMenuOverlay');
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    
    if (!mobileMenuOverlay || !mobileMenuToggle) return;
    
    mobileMenuOverlay.classList.remove('active');
    document.body.style.overflow = '';
    
    // Restaurar botão hamburger
    const spans = mobileMenuToggle.querySelectorAll('span');
    spans[0].style.transform = '';
    spans[1].style.opacity = '';
    spans[2].style.transform = '';
}

/**
 * Sistema de Alertas
 */
function initAlerts() {
    const alerts = document.querySelectorAll('.alert');
    
    alerts.forEach(alert => {
        // Auto-close após 5 segundos
        setTimeout(() => {
            hideAlert(alert);
        }, 5000);
        
        // Adicionar botão de fechar se não existir
        if (!alert.querySelector('.alert-close')) {
            const closeBtn = document.createElement('button');
            closeBtn.className = 'alert-close';
            closeBtn.innerHTML = '<i class="fas fa-times"></i>';
            closeBtn.style.cssText = `
                background: none;
                border: none;
                color: inherit;
                cursor: pointer;
                margin-left: auto;
                padding: 0.25rem;
                border-radius: 3px;
                opacity: 0.7;
                transition: opacity 0.3s ease;
            `;
            
            closeBtn.addEventListener('click', () => hideAlert(alert));
            closeBtn.addEventListener('mouseenter', () => closeBtn.style.opacity = '1');
            closeBtn.addEventListener('mouseleave', () => closeBtn.style.opacity = '0.7');
            
            alert.appendChild(closeBtn);
        }
    });
}

/**
 * Esconder alerta com animação
 */
function hideAlert(alert) {
    alert.style.transform = 'translateX(100%)';
    alert.style.opacity = '0';
    
    setTimeout(() => {
        alert.remove();
    }, 300);
}

/**
 * Mostrar alerta
 */
function showAlert(message, type = 'success') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type}`;
    alertContainer.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    
    // Inserir no topo da main-content
    const mainContent = document.querySelector('.main-content');
    if (mainContent) {
        mainContent.insertBefore(alertContainer, mainContent.firstChild);
        initAlerts(); // Reinicializar para o novo alerta
    }
}

/**
 * Validações de Formulários
 */
function initFormValidations() {
    const forms = document.querySelectorAll('form[data-validate="true"]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(form)) {
                e.preventDefault();
                return false;
            }
        });
        
        // Validação em tempo real
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', () => validateField(input));
            input.addEventListener('input', () => clearFieldError(input));
        });
    });
}

/**
 * Validar formulário completo
 */
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!validateField(input)) {
            isValid = false;
        }
    });
    
    return isValid;
}

/**
 * Validar campo individual
 */
function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    // Limpar erros anteriores
    clearFieldError(field);
    
    // Verificar se é obrigatório
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'Este campo é obrigatório';
    }
    
    // Validações específicas por tipo
    if (value && field.type === 'email') {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            isValid = false;
            errorMessage = 'Por favor, insira um email válido';
        }
    }
    
    if (value && field.type === 'password') {
        if (value.length < 6) {
            isValid = false;
            errorMessage = 'A password deve ter pelo menos 6 caracteres';
        }
    }
    
    if (value && field.name === 'confirm_password') {
        const passwordField = document.querySelector('input[name="password"]');
        if (passwordField && value !== passwordField.value) {
            isValid = false;
            errorMessage = 'As passwords não coincidem';
        }
    }
    
    // Mostrar erro se houver
    if (!isValid) {
        showFieldError(field, errorMessage);
    }
    
    return isValid;
}

/**
 * Mostrar erro no campo
 */
function showFieldError(field, message) {
    field.style.borderColor = 'var(--error-color)';
    
    let errorDiv = field.parentElement.querySelector('.field-error');
    if (!errorDiv) {
        errorDiv = document.createElement('div');
        errorDiv.className = 'field-error';
        errorDiv.style.cssText = `
            color: var(--error-color);
            font-size: 0.875rem;
            margin-top: 0.25rem;
            display: flex;
            align-items: center;
            gap: 0.25rem;
        `;
        field.parentElement.appendChild(errorDiv);
    }
    
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${message}`;
}

/**
 * Limpar erro do campo
 */
function clearFieldError(field) {
    field.style.borderColor = '';
    
    const errorDiv = field.parentElement.querySelector('.field-error');
    if (errorDiv) {
        errorDiv.remove();
    }
}

/**
 * Preview de Imagens
 */
function initImagePreview() {
    const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]');
    
    imageInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            // Verificar se é imagem
            if (!file.type.startsWith('image/')) {
                showAlert('Por favor, selecione apenas ficheiros de imagem', 'error');
                input.value = '';
                return;
            }
            
            // Verificar tamanho (5MB máximo)
            if (file.size > 5 * 1024 * 1024) {
                showAlert('A imagem deve ter no máximo 5MB', 'error');
                input.value = '';
                return;
            }
            
            // Mostrar preview
            const reader = new FileReader();
            reader.onload = function(e) {
                let preview = input.parentElement.querySelector('.image-preview');
                if (!preview) {
                    preview = document.createElement('div');
                    preview.className = 'image-preview';
                    preview.style.cssText = `
                        margin-top: 1rem;
                        border-radius: 10px;
                        overflow: hidden;
                        box-shadow: 0 3px 10px var(--shadow-color);
                    `;
                    input.parentElement.appendChild(preview);
                }
                
                preview.innerHTML = `
                    <img src="${e.target.result}" alt="Preview" style="
                        width: 100%;
                        max-width: 300px;
                        height: 200px;
                        object-fit: cover;
                    ">
                    <p style="
                        padding: 0.5rem;
                        text-align: center;
                        background: var(--surface-color);
                        color: var(--text-secondary);
                        font-size: 0.875rem;
                        margin: 0;
                    ">${file.name} (${formatFileSize(file.size)})</p>
                `;
            };
            reader.readAsDataURL(file);
        });
    });
}

/**
 * Formatar tamanho do ficheiro
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Sistema de Loading Overlay
 */
function initLoadingOverlay() {
    // Mostrar loading em formulários
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            // Verificar se não é validação que falhou
            setTimeout(() => {
                if (!form.querySelector('.field-error')) {
                    showLoading();
                }
            }, 100);
        });
    });
}

/**
 * Mostrar loading
 */
function showLoading(message = 'Carregando...') {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.querySelector('p').textContent = message;
        overlay.classList.add('active');
    }
}

/**
 * Esconder loading
 */
function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.remove('active');
    }
}

/**
 * Utilitários gerais
 */

// Smooth scroll para links âncora
document.addEventListener('click', function(e) {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const target = document.querySelector(e.target.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    }
});

// Lazy loading para imagens
function initLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src;
                    img.classList.remove('lazy');
                    imageObserver.unobserve(img);
                }
            });
        });
        
        images.forEach(img => imageObserver.observe(img));
    } else {
        // Fallback para navegadores antigos
        images.forEach(img => {
            img.src = img.dataset.src;
        });
    }
}

// Inicializar lazy loading se houver imagens
if (document.querySelectorAll('img[data-src]').length > 0) {
    initLazyLoading();
}

// Função para copiar texto para clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Texto copiado para a área de transferência!', 'success');
    }).catch(() => {
        showAlert('Erro ao copiar texto', 'error');
    });
}

// Função para partilhar (Web Share API se disponível)
function shareContent(title, text, url) {
    if (navigator.share) {
        navigator.share({
            title: title,
            text: text,
            url: url
        }).catch(() => {
            // Fallback para copiar link
            copyToClipboard(url);
        });
    } else {
        // Fallback para copiar link
        copyToClipboard(url);
    }
}

// Expor funções globais necessárias
window.SkateMap = {
    showAlert,
    hideAlert,
    showLoading,
    hideLoading,
    copyToClipboard,
    shareContent,
    validateForm,
    validateField
};