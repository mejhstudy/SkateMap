<?php
/**
 * SkateMap - Perfil do Utilizador
 * PAP - Prova de Aptidão Profissional
 */

$page_title = 'Meu Perfil';

require_once 'includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    $_SESSION['error_message'] = 'Precisa de fazer login para ver o perfil.';
    redirect(SITE_URL . '/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
}

// Verificar se é o próprio perfil ou o de outro utilizador
$user_id = $_GET['id'] ?? $_SESSION['user_id'];
$is_own_profile = ($user_id == $_SESSION['user_id']);

$error_message = '';
$success_message = '';

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com a base de dados.');
    }
    
    // Obter dados do utilizador
    $stmt = $conn->prepare("
        SELECT id, username, email, data_criacao, is_admin,
               (SELECT COUNT(*) FROM spots WHERE id_usuario = u.id) as total_spots,
               (SELECT COUNT(*) FROM avaliacoes WHERE id_usuario = u.id) as total_avaliacoes,
               (SELECT AVG(nota) FROM avaliacoes WHERE id_usuario = u.id) as media_avaliacoes,
               0 as total_favoritos
        FROM utilizadores u 
        WHERE u.id = ?
    ");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        throw new Exception('Utilizador não encontrado.');
    }
    
    // Obter spots publicados pelo utilizador
    $stmt = $conn->prepare("
        SELECT s.*, 
               COALESCE(AVG(a.nota), 0) as rating_medio,
               COUNT(a.id) as total_avaliacoes
        FROM spots s
        LEFT JOIN avaliacoes a ON s.id = a.id_spot
        WHERE s.id_usuario = ?
        GROUP BY s.id
        ORDER BY s.data_criacao DESC
        LIMIT 20
    ");
    $stmt->execute([$user_id]);
    $user_spots = $stmt->fetchAll();
    
    // Obter spots favoritos (funcionalidade ainda não implementada)
    $favorite_spots = [];
    // Nota: Tabela de favoritos não existe ainda na base de dados
    
    // Obter avaliações feitas pelo utilizador
    $stmt = $conn->prepare("
        SELECT a.*, s.nome as spot_nome, s.foto_principal
        FROM avaliacoes a
        JOIN spots s ON a.id_spot = s.id
        WHERE a.id_usuario = ?
        ORDER BY a.data_avaliacao DESC
        LIMIT 20
    ");
    $stmt->execute([$user_id]);
    $user_ratings = $stmt->fetchAll();
    
    // Obter comentários feitos pelo utilizador (se existir tabela de comentários)
    $user_comments = [];
    try {
        $stmt = $conn->prepare("
            SELECT c.*, s.nome as spot_nome, s.foto_principal
            FROM comentarios c
            JOIN spots s ON c.id_spot = s.id
            WHERE c.id_usuario = ?
            ORDER BY c.data_publicacao DESC
            LIMIT 20
        ");
        $stmt->execute([$user_id]);
        $user_comments = $stmt->fetchAll();
    } catch (Exception $e) {
        // Tabela de comentários pode não existir ainda
    }
    
} catch (Exception $e) {
    error_log("Erro no perfil: " . $e->getMessage());
    $error_message = 'Erro ao carregar dados do perfil.';
}

require_once 'includes/header.php';
?>

<div class="profile-container">
    <div class="container">
        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error_message; ?>
            </div>
        <?php else: ?>
            
        <!-- Cabeçalho do Perfil -->
        <div class="profile-header">
            <div class="profile-info">
                <div class="profile-avatar">
                    <i class="fas fa-user-circle"></i>
                </div>
                <div class="profile-details">
                    <h1 class="profile-name">
                        <?php echo htmlspecialchars($user['username']); ?>
                        <?php if ($user['is_admin']): ?>
                            <span class="admin-badge">
                                <i class="fas fa-crown"></i>
                                Admin
                            </span>
                        <?php endif; ?>
                    </h1>
                    <p class="profile-email">
                        <i class="fas fa-envelope"></i>
                        <?php echo $is_own_profile ? htmlspecialchars($user['email']) : 'Email privado'; ?>
                    </p>
                    <p class="profile-since">
                        <i class="fas fa-calendar-alt"></i>
                        Membro desde <?php echo date('F Y', strtotime($user['data_criacao'])); ?>
                    </p>
                </div>
                <?php if ($is_own_profile): ?>
                <div class="profile-actions">
                    <button class="btn btn-outline" onclick="editProfile()">
                        <i class="fas fa-edit"></i>
                        Editar Perfil
                    </button>
                    <a href="logout.php" class="btn btn-text">
                        <i class="fas fa-sign-out-alt"></i>
                        Logout
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Estatísticas -->
        <div class="profile-stats">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo number_format($user['total_spots']); ?></div>
                    <div class="stat-label">Spots Publicados</div>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo number_format($user['total_avaliacoes']); ?></div>
                    <div class="stat-label">Avaliações Feitas</div>
                </div>
            </div>
            
            <?php if ($is_own_profile): ?>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-heart"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo number_format($user['total_favoritos']); ?></div>
                    <div class="stat-label">Spots Favoritos</div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if ($user['media_avaliacoes'] > 0): ?>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-award"></i>
                </div>
                <div class="stat-info">
                    <div class="stat-number"><?php echo number_format($user['media_avaliacoes'], 1); ?></div>
                    <div class="stat-label">Média de Avaliações</div>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Navegação por Tabs -->
        <div class="profile-tabs">
            <div class="tab-nav">
                <button class="tab-button active" data-tab="spots">
                    <i class="fas fa-map-marker-alt"></i>
                    Meus Spots (<?php echo count($user_spots); ?>)
                </button>
                
                <?php if ($is_own_profile): ?>
                <button class="tab-button" data-tab="favorites">
                    <i class="fas fa-heart"></i>
                    Favoritos (<?php echo count($favorite_spots); ?>)
                </button>
                <?php endif; ?>
                
                <button class="tab-button" data-tab="ratings">
                    <i class="fas fa-star"></i>
                    Avaliações (<?php echo count($user_ratings); ?>)
                </button>
                
                <?php if (!empty($user_comments)): ?>
                <button class="tab-button" data-tab="comments">
                    <i class="fas fa-comment"></i>
                    Comentários (<?php echo count($user_comments); ?>)
                </button>
                <?php endif; ?>
            </div>

            <!-- Conteúdo das Tabs -->
            
            <!-- Tab: Meus Spots -->
            <div class="tab-content active" id="spots-tab">
                <div class="tab-header">
                    <h2>
                        <i class="fas fa-map-marker-alt"></i>
                        <?php echo $is_own_profile ? 'Meus Spots' : 'Spots de ' . htmlspecialchars($user['username']); ?>
                    </h2>
                    <?php if ($is_own_profile): ?>
                    <a href="add_spot.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Adicionar Spot
                    </a>
                    <?php endif; ?>
                </div>
                
                <?php if (empty($user_spots)): ?>
                <div class="empty-state">
                    <i class="fas fa-map-marker-alt"></i>
                    <h3><?php echo $is_own_profile ? 'Ainda não publicou nenhum spot' : 'Este utilizador ainda não publicou spots'; ?></h3>
                    <?php if ($is_own_profile): ?>
                    <p>Comece a partilhar os seus spots favoritos com a comunidade!</p>
                    <a href="add_spot.php" class="btn btn-primary">
                        <i class="fas fa-plus"></i>
                        Adicionar Primeiro Spot
                    </a>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="spots-grid">
                    <?php foreach ($user_spots as $spot): ?>
                    <div class="spot-card">
                        <div class="spot-image">
                            <img src="uploads/spots/<?php echo htmlspecialchars($spot['foto_principal']); ?>" 
                                 alt="<?php echo htmlspecialchars($spot['nome']); ?>"
                                 onerror="this.src='assets/images/default-spot.jpg'">
                            <div class="spot-badges">
                                <?php if ($spot['rating_medio'] > 0): ?>
                                <span class="rating-badge">
                                    <i class="fas fa-star"></i>
                                    <?php echo number_format($spot['rating_medio'], 1); ?>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="spot-info">
                            <h3 class="spot-title"><?php echo htmlspecialchars($spot['nome']); ?></h3>
                            <p class="spot-description"><?php echo mb_substr(htmlspecialchars($spot['descricao']), 0, 100); ?>...</p>
                            <div class="spot-meta">
                                <span class="spot-date">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo date('d/m/Y', strtotime($spot['data_criacao'])); ?>
                                </span>
                                <span class="spot-stats">
                                    <i class="fas fa-star"></i> <?php echo $spot['total_avaliacoes']; ?>
                                    <i class="fas fa-heart"></i> <?php echo $spot['total_favoritos']; ?>
                                </span>
                            </div>
                            <div class="spot-actions">
                                <a href="spot_detalhes.php?id=<?php echo $spot['id']; ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-eye"></i>
                                    Ver Detalhes
                                </a>
                                <?php if ($is_own_profile): ?>
                                <button class="btn btn-outline btn-sm" onclick="editSpot(<?php echo $spot['id']; ?>)">
                                    <i class="fas fa-edit"></i>
                                    Editar
                                </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Tab: Favoritos -->
            <?php if ($is_own_profile): ?>
            <div class="tab-content" id="favorites-tab">
                <div class="tab-header">
                    <h2>
                        <i class="fas fa-heart"></i>
                        Spots Favoritos
                    </h2>
                </div>
                
                <?php if (empty($favorite_spots)): ?>
                <div class="empty-state">
                    <i class="fas fa-heart"></i>
                    <h3>Ainda não tem spots favoritos</h3>
                    <p>Explore o mapa e marque os spots que mais gosta!</p>
                    <a href="<?php echo SITE_URL; ?>" class="btn btn-primary">
                        <i class="fas fa-map"></i>
                        Explorar Spots
                    </a>
                </div>
                <?php else: ?>
                <div class="spots-grid">
                    <?php foreach ($favorite_spots as $spot): ?>
                    <div class="spot-card">
                        <div class="spot-image">
                            <img src="uploads/spots/<?php echo htmlspecialchars($spot['foto_principal']); ?>" 
                                 alt="<?php echo htmlspecialchars($spot['nome']); ?>"
                                 onerror="this.src='assets/images/default-spot.jpg'">
                            <div class="spot-badges">
                                <?php if ($spot['rating_medio'] > 0): ?>
                                <span class="rating-badge">
                                    <i class="fas fa-star"></i>
                                    <?php echo number_format($spot['rating_medio'], 1); ?>
                                </span>
                                <?php endif; ?>
                                <button class="favorite-btn active" onclick="toggleFavorite(<?php echo $spot['id']; ?>)" title="Remover dos favoritos">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                        </div>
                        <div class="spot-info">
                            <h3 class="spot-title"><?php echo htmlspecialchars($spot['nome']); ?></h3>
                            <p class="spot-description"><?php echo mb_substr(htmlspecialchars($spot['descricao']), 0, 100); ?>...</p>
                            <div class="spot-meta">
                                <span class="spot-date">
                                    <i class="fas fa-heart"></i>
                                    Favoritado em <?php echo date('d/m/Y', strtotime($spot['data_favorito'])); ?>
                                </span>
                                <span class="spot-stats">
                                    <i class="fas fa-star"></i> <?php echo $spot['total_avaliacoes']; ?>
                                </span>
                            </div>
                            <div class="spot-actions">
                                <a href="spot_detalhes.php?id=<?php echo $spot['id']; ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-eye"></i>
                                    Ver Detalhes
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Tab: Avaliações -->
            <div class="tab-content" id="ratings-tab">
                <div class="tab-header">
                    <h2>
                        <i class="fas fa-star"></i>
                        <?php echo $is_own_profile ? 'Minhas Avaliações' : 'Avaliações de ' . htmlspecialchars($user['username']); ?>
                    </h2>
                </div>
                
                <?php if (empty($user_ratings)): ?>
                <div class="empty-state">
                    <i class="fas fa-star"></i>
                    <h3><?php echo $is_own_profile ? 'Ainda não fez nenhuma avaliação' : 'Este utilizador ainda não fez avaliações'; ?></h3>
                    <?php if ($is_own_profile): ?>
                    <p>Avalie os spots que visitou para ajudar outros skaters!</p>
                    <a href="<?php echo SITE_URL; ?>" class="btn btn-primary">
                        <i class="fas fa-map"></i>
                        Explorar Spots
                    </a>
                    <?php endif; ?>
                </div>
                <?php else: ?>
                <div class="ratings-list">
                    <?php foreach ($user_ratings as $rating): ?>
                    <div class="rating-item">
                        <div class="rating-spot">
                            <img src="uploads/spots/<?php echo htmlspecialchars($rating['foto_principal']); ?>" 
                                 alt="<?php echo htmlspecialchars($rating['spot_nome']); ?>"
                                 onerror="this.src='assets/images/default-spot.jpg'">
                        </div>
                        <div class="rating-content">
                            <div class="rating-header">
                                <h4 class="spot-name">
                                    <a href="spot_detalhes.php?id=<?php echo $rating['id_spot']; ?>">
                                        <?php echo htmlspecialchars($rating['spot_nome']); ?>
                                    </a>
                                </h4>
                                <div class="rating-stars">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star <?php echo $i <= $rating['nota'] ? 'active' : 'inactive'; ?>"></i>
                                    <?php endfor; ?>
                                    <span class="rating-value"><?php echo $rating['nota']; ?>/5</span>
                                </div>
                            </div>
                            <?php if (!empty($rating['comentario'])): ?>
                            <p class="rating-comment"><?php echo htmlspecialchars($rating['comentario']); ?></p>
                            <?php endif; ?>
                            <div class="rating-date">
                                <i class="fas fa-calendar"></i>
                                <?php echo date('d/m/Y H:i', strtotime($rating['data_avaliacao'])); ?>
                            </div>
                        </div>
                        <?php if ($is_own_profile): ?>
                        <div class="rating-actions">
                            <button class="btn btn-outline btn-sm" onclick="editRating(<?php echo $rating['id']; ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-outline btn-sm btn-danger" onclick="deleteRating(<?php echo $rating['id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Tab: Comentários -->
            <?php if (!empty($user_comments)): ?>
            <div class="tab-content" id="comments-tab">
                <div class="tab-header">
                    <h2>
                        <i class="fas fa-comment"></i>
                        <?php echo $is_own_profile ? 'Meus Comentários' : 'Comentários de ' . htmlspecialchars($user['username']); ?>
                    </h2>
                </div>
                
                <div class="comments-list">
                    <?php foreach ($user_comments as $comment): ?>
                    <div class="comment-item">
                        <div class="comment-spot">
                            <img src="uploads/spots/<?php echo htmlspecialchars($comment['foto_principal']); ?>" 
                                 alt="<?php echo htmlspecialchars($comment['spot_nome']); ?>"
                                 onerror="this.src='assets/images/default-spot.jpg'">
                        </div>
                        <div class="comment-content">
                            <div class="comment-header">
                                <h4 class="spot-name">
                                    <a href="spot_detalhes.php?id=<?php echo $comment['id_spot']; ?>">
                                        <?php echo htmlspecialchars($comment['spot_nome']); ?>
                                    </a>
                                </h4>
                                <div class="comment-date">
                                    <i class="fas fa-calendar"></i>
                                    <?php echo date('d/m/Y H:i', strtotime($comment['data_publicacao'])); ?>
                                </div>
                            </div>
                            <p class="comment-text"><?php echo htmlspecialchars($comment['comentario']); ?></p>
                        </div>
                        <?php if ($is_own_profile): ?>
                        <div class="comment-actions">
                            <button class="btn btn-outline btn-sm" onclick="editComment(<?php echo $comment['id']; ?>)">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-outline btn-sm btn-danger" onclick="deleteComment(<?php echo $comment['id']; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
        
        <?php endif; ?>
    </div>
</div>

<style>
/* ===== PERFIL DO UTILIZADOR ===== */
.profile-container {
    min-height: calc(100vh - 160px);
    padding: 2rem 0;
    background: linear-gradient(135deg, var(--background-color) 0%, var(--surface-color) 100%);
}

/* ===== CABEÇALHO DO PERFIL ===== */
.profile-header {
    background: var(--surface-color);
    border-radius: 20px;
    padding: 2.5rem;
    margin-bottom: 2rem;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
}

.profile-info {
    display: flex;
    align-items: center;
    gap: 2rem;
}

.profile-avatar {
    flex-shrink: 0;
}

.profile-avatar i {
    font-size: 5rem;
    color: var(--primary-color);
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.profile-details {
    flex: 1;
}

.profile-name {
    font-size: 2.2rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.admin-badge {
    background: linear-gradient(135deg, #fbbf24, #f59e0b);
    color: white;
    padding: 0.3rem 0.8rem;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.3rem;
}

.profile-email,
.profile-since {
    color: var(--text-secondary);
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.profile-actions {
    display: flex;
    gap: 1rem;
    align-items: center;
}

/* ===== ESTATÍSTICAS ===== */
.profile-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.3rem;
}

.stat-number {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--text-primary);
    line-height: 1;
}

.stat-label {
    color: var(--text-secondary);
    font-size: 0.9rem;
    font-weight: 500;
}

/* ===== SISTEMA DE TABS ===== */
.profile-tabs {
    background: var(--surface-color);
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
    overflow: hidden;
}

.tab-nav {
    display: flex;
    background: var(--background-color);
    border-bottom: 1px solid var(--border-color);
}

.tab-button {
    flex: 1;
    padding: 1.2rem 1.5rem;
    border: none;
    background: none;
    color: var(--text-secondary);
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    border-bottom: 3px solid transparent;
}

.tab-button:hover {
    background: rgba(var(--primary-rgb), 0.1);
    color: var(--primary-color);
}

.tab-button.active {
    background: var(--primary-color);
    color: white;
    border-bottom-color: var(--secondary-color);
}

.tab-content {
    display: none;
    padding: 2rem;
}

.tab-content.active {
    display: block;
}

.tab-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid var(--border-color);
}

.tab-header h2 {
    color: var(--text-primary);
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin: 0;
}

/* ===== ESTADOS VAZIOS ===== */
.empty-state {
    text-align: center;
    padding: 3rem;
    color: var(--text-secondary);
}

.empty-state i {
    font-size: 4rem;
    color: var(--border-color);
    margin-bottom: 1rem;
}

.empty-state h3 {
    color: var(--text-primary);
    margin-bottom: 1rem;
}

/* ===== GRID DE SPOTS ===== */
.spots-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 1.5rem;
}

.spot-card {
    background: var(--background-color);
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
}

.spot-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
}

.spot-image {
    position: relative;
    height: 200px;
    overflow: hidden;
}

.spot-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.spot-card:hover .spot-image img {
    transform: scale(1.05);
}

.spot-badges {
    position: absolute;
    top: 0.75rem;
    right: 0.75rem;
    display: flex;
    gap: 0.5rem;
}

.rating-badge {
    background: rgba(0, 0, 0, 0.7);
    color: white;
    padding: 0.3rem 0.6rem;
    border-radius: 15px;
    font-size: 0.8rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 0.3rem;
}

.favorite-btn {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    border: none;
    background: rgba(0, 0, 0, 0.7);
    color: white;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.favorite-btn.active {
    background: var(--error-color);
    color: white;
}

.spot-info {
    padding: 1.2rem;
}

.spot-title {
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--text-primary);
    margin-bottom: 0.5rem;
    line-height: 1.3;
}

.spot-description {
    color: var(--text-secondary);
    line-height: 1.5;
    margin-bottom: 1rem;
}

.spot-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    font-size: 0.85rem;
    color: var(--text-secondary);
}

.spot-stats {
    display: flex;
    gap: 1rem;
    align-items: center;
}

.spot-actions {
    display: flex;
    gap: 0.75rem;
}

/* ===== LISTAS DE AVALIAÇÕES E COMENTÁRIOS ===== */
.ratings-list,
.comments-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.rating-item,
.comment-item {
    background: var(--background-color);
    border-radius: 12px;
    padding: 1.5rem;
    border: 1px solid var(--border-color);
    display: flex;
    gap: 1rem;
    align-items: flex-start;
    transition: all 0.3s ease;
}

.rating-item:hover,
.comment-item:hover {
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    transform: translateY(-2px);
}

.rating-spot,
.comment-spot {
    flex-shrink: 0;
    width: 60px;
    height: 60px;
    border-radius: 8px;
    overflow: hidden;
}

.rating-spot img,
.comment-spot img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.rating-content,
.comment-content {
    flex: 1;
}

.rating-header,
.comment-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 0.75rem;
}

.spot-name a {
    color: var(--text-primary);
    text-decoration: none;
    font-weight: 600;
    transition: color 0.3s ease;
}

.spot-name a:hover {
    color: var(--primary-color);
}

.rating-stars {
    display: flex;
    gap: 0.2rem;
    align-items: center;
}

.rating-stars .fa-star.active {
    color: #fbbf24;
}

.rating-stars .fa-star.inactive {
    color: #e5e7eb;
}

.rating-value {
    margin-left: 0.5rem;
    font-weight: 600;
    color: var(--text-secondary);
}

.rating-comment,
.comment-text {
    color: var(--text-secondary);
    line-height: 1.5;
    margin-bottom: 0.75rem;
}

.rating-date,
.comment-date {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.85rem;
}

.rating-actions,
.comment-actions {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

/* ===== BOTÕES ===== */
.btn {
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    font-weight: 500;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 1px solid transparent;
    font-size: 0.9rem;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    border: none;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(var(--primary-rgb), 0.4);
}

.btn-outline {
    background: transparent;
    color: var(--text-primary);
    border-color: var(--border-color);
}

.btn-outline:hover {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
}

.btn-text {
    background: none;
    color: var(--text-secondary);
}

.btn-text:hover {
    color: var(--primary-color);
    background: rgba(var(--primary-rgb), 0.1);
}

.btn-sm {
    padding: 0.5rem 1rem;
    font-size: 0.8rem;
}

.btn-danger:hover {
    background: var(--error-color);
    color: white;
    border-color: var(--error-color);
}

/* ===== RESPONSIVE ===== */
@media (max-width: 768px) {
    .profile-info {
        flex-direction: column;
        text-align: center;
        gap: 1.5rem;
    }
    
    .profile-actions {
        justify-content: center;
    }
    
    .profile-stats {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .tab-nav {
        flex-direction: column;
    }
    
    .spots-grid {
        grid-template-columns: 1fr;
    }
    
    .tab-header {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
    
    .rating-item,
    .comment-item {
        flex-direction: column;
    }
    
    .rating-actions,
    .comment-actions {
        flex-direction: row;
        justify-content: flex-end;
    }
}

@media (max-width: 480px) {
    .profile-container {
        padding: 1rem 0;
    }
    
    .profile-header {
        padding: 1.5rem;
    }
    
    .tab-content {
        padding: 1rem;
    }
    
    .profile-stats {
        grid-template-columns: 1fr;
    }
    
    .spot-actions {
        flex-direction: column;
    }
}
</style>

<script>
// ===== SISTEMA DE TABS =====
document.addEventListener('DOMContentLoaded', function() {
    setupTabs();
});

function setupTabs() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-tab');
            
            // Remover active de todos os botões e conteúdos
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Ativar o botão e conteúdo selecionado
            button.classList.add('active');
            const targetContent = document.getElementById(targetTab + '-tab');
            if (targetContent) {
                targetContent.classList.add('active');
            }
        });
    });
}

// ===== FUNÇÕES DE AÇÕES =====

function editProfile() {
    // Implementar edição de perfil
    SkateMap.showAlert('Funcionalidade de edição em desenvolvimento', 'info');
}

function editSpot(spotId) {
    // Implementar edição de spot
    SkateMap.showAlert('Funcionalidade de edição em desenvolvimento', 'info');
}

function toggleFavorite(spotId) {
    // Implementar toggle de favorito
    SkateMap.showAlert('Funcionalidade de favoritos em desenvolvimento', 'info');
}

function editRating(ratingId) {
    // Implementar edição de avaliação
    SkateMap.showAlert('Funcionalidade de edição em desenvolvimento', 'info');
}

function deleteRating(ratingId) {
    if (confirm('Tem certeza que deseja eliminar esta avaliação?')) {
        // Implementar eliminação de avaliação
        SkateMap.showAlert('Funcionalidade de eliminação em desenvolvimento', 'info');
    }
}

function editComment(commentId) {
    // Implementar edição de comentário
    SkateMap.showAlert('Funcionalidade de edição em desenvolvimento', 'info');
}

function deleteComment(commentId) {
    if (confirm('Tem certeza que deseja eliminar este comentário?')) {
        // Implementar eliminação de comentário
        SkateMap.showAlert('Funcionalidade de eliminação em desenvolvimento', 'info');
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>