# 🛠️ **GUIA COMPLETO - CONFIGURAÇÃO SKATEMAP**

## ✅ **Para que a criação de contas funcione, siga estes passos:**

### **1. CONFIGURAR A BASE DE DADOS**

**Opção A - Automática (RECOMENDADA):**
1. Acesse: `http://localhost/pap/install.php`
2. O script vai criar automaticamente:
   - Base de dados `skatemap`
   - Todas as tabelas necessárias
   - Utilizador admin padrão
   - Spots de exemplo
   - Pastas de upload

**Opção B - Manual:**
1. Abra phpMyAdmin: `http://localhost/phpmyadmin`
2. Crie uma nova base de dados chamada `skatemap`
3. Importe o arquivo `database/skatemap.sql`

### **2. VERIFICAR CONFIGURAÇÕES**

**Teste a conexão:**
- Acesse: `http://localhost/pap/test_db.php`
- Deve mostrar todas as verificações em verde ✅

**Verificar configurações em `includes/config.php`:**
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'skatemap');
define('DB_USER', 'root');
define('DB_PASS', '');        // Deixe vazio se não tem password
define('SITE_URL', 'http://localhost/pap');
```

### **3. CRIAR IMAGEM PADRÃO**

Execute uma vez: `http://localhost/pap/create_default_image.php`
- Isso cria a imagem padrão para os spots

### **4. TESTAR O SISTEMA**

**Criar nova conta:**
1. Acesse: `http://localhost/pap/register.php`
2. Preencha todos os campos
3. Aceite os termos
4. Clique em "Criar Conta"

**Login como administrador:**
- Email: `admin@skatemap.pt`
- Password: `admin123`

### **5. ESTRUTURA DE PASTAS NECESSÁRIA**

```
d:\wamp64\www\pap\
├── database/
│   └── skatemap.sql
├── includes/
│   └── config.php
├── uploads/
│   ├── spots/
│   │   └── default_spot.jpg
│   └── videos/
├── assets/
│   ├── css/
│   └── js/
├── admin/
├── api/
├── index.php
├── login.php
├── register.php
├── install.php (temporário)
└── test_db.php (temporário)
```

### **6. POSSÍVEIS PROBLEMAS E SOLUÇÕES**

**❌ "Connection refused"**
- WampServer não está a correr
- Verifique se o ícone está verde

**❌ "Access denied for user 'root'"**
- Verifique username/password no config.php
- No Wamp, por padrão é user='root' e password=''

**❌ "Database 'skatemap' doesn't exist"**
- Execute o install.php
- Ou importe o skatemap.sql manualmente

**❌ "Table doesn't exist"**
- Execute o install.php novamente
- Ou importe o SQL completo

**❌ Erro 404 nas páginas**
- Verifique se o SITE_URL está correto
- Deve ser: `http://localhost/pap`

### **7. FUNCIONALIDADES IMPLEMENTADAS**

✅ **Registo de utilizadores**
✅ **Login/Logout**
✅ **Validação de dados**
✅ **Hash de passwords seguro**  
✅ **Verificação de email/username únicos**
✅ **Sessões de utilizador**
✅ **Estrutura da base de dados completa**
✅ **Sistema de upload de ficheiros**
✅ **Páginas responsivas**

### **8. PRÓXIMOS PASSOS APÓS CONFIGURAÇÃO**

1. **Teste criação de conta**
2. **Teste login/logout**
3. **Desenvolva funcionalidades de spots**
4. **Implemente sistema de comentários**
5. **Adicione Google Maps**

---

## 🚀 **COMANDOS RÁPIDOS**

```bash
# 1. Instalar sistema (execute uma vez)
http://localhost/pap/install.php

# 2. Testar conexão
http://localhost/pap/test_db.php

# 3. Criar imagem padrão
http://localhost/pap/create_default_image.php

# 4. Acessar o site
http://localhost/pap/

# 5. Área de registo
http://localhost/pap/register.php

# 6. Login
http://localhost/pap/login.php
```

---

**⚠️ IMPORTANTE:** Depois de configurar tudo, pode eliminar os arquivos temporários:
- `install.php`
- `test_db.php` 
- `create_default_image.php`