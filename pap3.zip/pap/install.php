<?php
/**
 * Instalador automático da base de dados SkateMap
 * Execute este arquivo uma vez para configurar a base de dados
 */

require_once 'includes/config.php';

echo "<h1>Instalador SkateMap</h1>";
echo "<p>Este script vai criar a base de dados e tabelas necessárias.</p>";

$errors = [];
$success = [];

try {
    // Conectar ao MySQL (sem especificar base de dados)
    $dsn = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $success[] = "✅ Conexão com MySQL estabelecida";
    
    // Criar base de dados
    $pdo->exec("CREATE DATABASE IF NOT EXISTS skatemap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $success[] = "✅ Base de dados 'skatemap' criada/verificada";
    
    // Usar a base de dados
    $pdo->exec("USE skatemap");
    
    // Criar tabela de utilizadores
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS utilizadores (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            is_admin BOOLEAN DEFAULT FALSE,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_username (username),
            INDEX idx_email (email)
        )
    ");
    $success[] = "✅ Tabela 'utilizadores' criada";
    
    // Criar tabela de spots
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS spots (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_usuario INT NOT NULL,
            nome VARCHAR(100) NOT NULL,
            descricao TEXT,
            endereco VARCHAR(255),
            latitude DECIMAL(10, 8) NOT NULL,
            longitude DECIMAL(11, 8) NOT NULL,
            foto_principal VARCHAR(255) NOT NULL,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
            INDEX idx_coordenadas (latitude, longitude),
            INDEX idx_usuario (id_usuario)
        )
    ");
    $success[] = "✅ Tabela 'spots' criada";
    
    // Criar tabela de fotos
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS fotos_spots (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_spot INT NOT NULL,
            caminho_foto VARCHAR(255) NOT NULL,
            data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
            INDEX idx_spot (id_spot)
        )
    ");
    $success[] = "✅ Tabela 'fotos_spots' criada";
    
    // Criar tabela de vídeos
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS videos_spots (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_spot INT NOT NULL,
            caminho_video VARCHAR(255) NOT NULL,
            data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
            INDEX idx_spot (id_spot)
        )
    ");
    $success[] = "✅ Tabela 'videos_spots' criada";
    
    // Criar tabela de comentários
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS comentarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_spot INT NOT NULL,
            id_usuario INT NOT NULL,
            texto TEXT NOT NULL,
            data_publicacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
            FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
            INDEX idx_spot (id_spot),
            INDEX idx_usuario (id_usuario)
        )
    ");
    $success[] = "✅ Tabela 'comentarios' criada";
    
    // Criar tabela de avaliações
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS avaliacoes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            id_spot INT NOT NULL,
            id_usuario INT NOT NULL,
            nota INT NOT NULL CHECK (nota >= 1 AND nota <= 5),
            data_avaliacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
            FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
            UNIQUE KEY unique_user_spot (id_spot, id_usuario),
            INDEX idx_spot (id_spot),
            INDEX idx_usuario (id_usuario)
        )
    ");
    $success[] = "✅ Tabela 'avaliacoes' criada";
    
    // Verificar se já existe utilizador admin
    $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE username = 'admin'");
    $stmt->execute();
    
    if ($stmt->rowCount() == 0) {
        // Criar utilizador admin padrão
        $adminPassword = hashPassword('admin123');
        $stmt = $pdo->prepare("
            INSERT INTO utilizadores (username, email, password, is_admin) 
            VALUES ('admin', 'admin@skatemap.pt', ?, TRUE)
        ");
        $stmt->execute([$adminPassword]);
        $success[] = "✅ Utilizador admin criado (email: admin@skatemap.pt, password: admin123)";
    } else {
        $success[] = "ℹ️ Utilizador admin já existe";
    }
    
    // Verificar se já existem spots de exemplo
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM spots");
    $result = $stmt->fetch();
    
    if ($result['total'] == 0) {
        // Inserir spots de exemplo
        $spots = [
            [
                'nome' => 'Skate Park do Porto',
                'descricao' => 'Excelente skate park com várias rampas e obstáculos',
                'endereco' => 'Porto, Portugal',
                'latitude' => 41.1579,
                'longitude' => -8.6291
            ],
            [
                'nome' => 'Praça do Comércio',
                'descricao' => 'Spot clássico no centro de Lisboa com escadarias',
                'endereco' => 'Praça do Comércio, Lisboa',
                'latitude' => 38.7077,
                'longitude' => -9.1365
            ],
            [
                'nome' => 'Cais do Sodré',
                'descricao' => 'Área urbana com vários obstáculos naturais',
                'endereco' => 'Cais do Sodré, Lisboa',
                'latitude' => 38.7054,
                'longitude' => -9.1452
            ]
        ];
        
        $adminId = $pdo->query("SELECT id FROM utilizadores WHERE username = 'admin'")->fetch()['id'];
        
        foreach ($spots as $spot) {
            $stmt = $pdo->prepare("
                INSERT INTO spots (id_usuario, nome, descricao, endereco, latitude, longitude, foto_principal) 
                VALUES (?, ?, ?, ?, ?, ?, 'default_spot.jpg')
            ");
            $stmt->execute([
                $adminId,
                $spot['nome'],
                $spot['descricao'],
                $spot['endereco'],
                $spot['latitude'],
                $spot['longitude']
            ]);
        }
        $success[] = "✅ Spots de exemplo criados";
    } else {
        $success[] = "ℹ️ Já existem " . $result['total'] . " spots na base de dados";
    }
    
    // Criar pastas de upload se não existirem
    $uploadDirs = ['uploads', 'uploads/spots', 'uploads/videos'];
    foreach ($uploadDirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
            $success[] = "✅ Pasta '$dir' criada";
        } else {
            $success[] = "ℹ️ Pasta '$dir' já existe";
        }
    }
    
} catch (PDOException $e) {
    $errors[] = "❌ Erro: " . $e->getMessage();
} catch (Exception $e) {
    $errors[] = "❌ Erro geral: " . $e->getMessage();
}

// Mostrar resultados
echo "<div style='background: #d4edda; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h2>✅ Instalação Concluída!</h2>";
foreach ($success as $msg) {
    echo "<p style='color: green; margin: 5px 0;'>$msg</p>";
}
echo "</div>";

if (!empty($errors)) {
    echo "<div style='background: #f8d7da; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
    echo "<h2>❌ Erros Encontrados:</h2>";
    foreach ($errors as $error) {
        echo "<p style='color: red; margin: 5px 0;'>$error</p>";
    }
    echo "</div>";
}

echo "<div style='background: #cce5ff; padding: 20px; border-radius: 5px; margin: 20px 0;'>";
echo "<h2>🎯 Próximos Passos:</h2>";
echo "<ol>";
echo "<li><strong>Acesse o site:</strong> <a href='http://localhost/pap/'>http://localhost/pap/</a></li>";
echo "<li><strong>Faça login como admin:</strong> email=admin@skatemap.pt, password=admin123</li>";
echo "<li><strong>Ou crie uma nova conta:</strong> <a href='http://localhost/pap/register.php'>Registar</a></li>";
echo "<li><strong>Teste o sistema:</strong> Adicione spots, comente, avalie</li>";
echo "</ol>";
echo "</div>";

echo "<hr>";
echo "<p><a href='index.php'>← Voltar ao início</a> | <a href='test_db.php'>Testar conexão</a></p>";
?>