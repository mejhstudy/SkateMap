<?php
require_once 'includes/config.php';

header('Content-Type: text/plain; charset=utf-8');

echo "Testando conexão à base de dados...\n";
$conn = getConnection();
if (!$conn) {
    echo "Falha: getConnection() retornou null. Verifique credenciais e se o servidor MySQL está a correr.\n";
    exit(1);
}

echo "Sucesso: Conectado ao MySQL.\n";

try {
    $stmt = $conn->query("SHOW TABLES LIKE 'utilizadores'");
    $exists = $stmt->fetch();
    if (!$exists) {
        echo "Tabela 'utilizadores' não encontrada.\n";
        // Listar tabelas disponíveis para ajudar
        echo "Tabelas na base de dados:\n";
        $tables = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $t) {
            echo " - $t\n";
        }
        exit(2);
    }

    echo "Tabela 'utilizadores' existe. Tentando ler 1 registo...\n";
    $row = $conn->query("SELECT id, email, username FROM utilizadores LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        echo "Exemplo de utilizador: " . print_r($row, true) . "\n";
    } else {
        echo "A tabela 'utilizadores' está vazia.\n";
    }
} catch (Exception $e) {
    echo "Erro ao consultar tabela 'utilizadores': " . $e->getMessage() . "\n";
    exit(3);
}

echo "Teste concluído.\n";
