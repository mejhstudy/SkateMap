<?php
/**
 * SkateMap - Logout
 * PAP - Prova de Aptidão Profissional
 */

require_once 'includes/config.php';

startSession();

// Destruir sessão
session_destroy();

// Limpar cookies se houver
if (isset($_COOKIE['remember_me'])) {
    setcookie('remember_me', '', time() - 3600, '/');
}

// Redirecionar para página inicial com mensagem
redirect(SITE_URL . '?logout=success');
?>