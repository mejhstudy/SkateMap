<?php
/**
 * SkateMap - Adicionar Novo Spot
 * PAP - Prova de Aptidão Profissional
 */

$page_title = 'Adicionar Spot';
$load_maps_js = true;

require_once 'includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    $_SESSION['error_message'] = 'Precisa de fazer login para adicionar spots.';
    redirect(SITE_URL . '/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
}

require_once 'includes/header.php';

$error_message = '';
$success_message = '';
$form_data = [];

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = sanitize($_POST['nome'] ?? '');
    $descricao = sanitize($_POST['descricao'] ?? '');
    $endereco = sanitize($_POST['endereco'] ?? '');
    $latitude = floatval($_POST['latitude'] ?? 0);
    $longitude = floatval($_POST['longitude'] ?? 0);
    
    // Guardar dados do formulário
    $form_data = compact('nome', 'descricao', 'endereco', 'latitude', 'longitude');
    
    // Validações
    if (empty($nome)) {
        $error_message = 'O nome do spot é obrigatório.';
    } elseif (strlen($nome) > 100) {
        $error_message = 'O nome do spot não pode ter mais de 100 caracteres.';
    } elseif (empty($descricao)) {
        $error_message = 'A descrição do spot é obrigatória.';
    } elseif ($latitude === 0 || $longitude === 0) {
        $error_message = 'Por favor, selecione a localização no mapa ou preencha as coordenadas.';
    } elseif (!isset($_FILES['foto_principal']) || $_FILES['foto_principal']['error'] !== UPLOAD_ERR_OK) {
        $error_message = 'É obrigatório enviar uma foto principal do spot.';
    } else {
        try {
            $conn = getConnection();
            if ($conn) {
                // Upload da foto principal
                $foto_nome = uploadFile($_FILES['foto_principal'], 'uploads/spots/');
                
                if ($foto_nome) {
                    // Inserir spot na base de dados
                    $stmt = $conn->prepare("
                        INSERT INTO spots (id_usuario, nome, descricao, endereco, latitude, longitude, foto_principal)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    ");
                    
                    $result = $stmt->execute([
                        $_SESSION['user_id'],
                        $nome,
                        $descricao,
                        $endereco,
                        $latitude,
                        $longitude,
                        $foto_nome
                    ]);
                    
                    if ($result) {
                        $spot_id = $conn->lastInsertId();
                        
                        // Upload de fotos adicionais se houver
                        if (isset($_FILES['fotos_adicionais'])) {
                            $fotos_adicionais = $_FILES['fotos_adicionais'];
                            
                            for ($i = 0; $i < count($fotos_adicionais['name']); $i++) {
                                if ($fotos_adicionais['error'][$i] === UPLOAD_ERR_OK) {
                                    $foto_adicional = [
                                        'name' => $fotos_adicionais['name'][$i],
                                        'type' => $fotos_adicionais['type'][$i],
                                        'tmp_name' => $fotos_adicionais['tmp_name'][$i],
                                        'error' => $fotos_adicionais['error'][$i],
                                        'size' => $fotos_adicionais['size'][$i]
                                    ];
                                    
                                    $nome_foto_adicional = uploadFile($foto_adicional, 'uploads/spots/');
                                    
                                    if ($nome_foto_adicional) {
                                        $stmt = $conn->prepare("
                                            INSERT INTO fotos_spots (id_spot, caminho_foto) 
                                            VALUES (?, ?)
                                        ");
                                        $stmt->execute([$spot_id, $nome_foto_adicional]);
                                    }
                                }
                            }
                        }
                        
                        $_SESSION['success_message'] = 'Spot adicionado com sucesso!';
                        redirect(SITE_URL . "/spot_detalhes.php?id={$spot_id}");
                    } else {
                        // Eliminar foto se falhou inserir na base de dados
                        unlink('uploads/spots/' . $foto_nome);
                        $error_message = 'Erro ao adicionar o spot. Tente novamente.';
                    }
                } else {
                    $error_message = 'Erro no upload da foto. Verifique se é uma imagem válida (JPG, PNG, GIF) e menor que 5MB.';
                }
            } else {
                $error_message = 'Erro de conexão com a base de dados.';
            }
        } catch (Exception $e) {
            error_log("Erro ao adicionar spot: " . $e->getMessage());
            $error_message = 'Erro interno. Tente novamente.';
        }
    }
}
?>

<div class="add-spot-container">
    <div class="container">
        <div class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle"></i>
                    Adicionar Novo Spot
                </h1>
                <p class="page-description">
                    Partilhe um novo spot de skate com a comunidade. Preencha todas as informações necessárias.
                </p>
            </div>
        </div>

        <div class="add-spot-content">
            <!-- Formulário -->
            <div class="spot-form-section">
                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data" class="spot-form" data-validate="true">
                    <!-- Informações Básicas -->
                    <div class="form-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-info-circle"></i>
                            Informações Básicas
                        </h2>

                        <div class="form-group">
                            <label for="nome">
                                <i class="fas fa-tag"></i>
                                Nome do Spot *
                            </label>
                            <input
                                type="text"
                                id="nome"
                                name="nome"
                                class="form-control"
                                placeholder="Ex: Skate Park do Porto, Escadarias do Rossio..."
                                value="<?php echo htmlspecialchars($form_data['nome'] ?? ''); ?>"
                                required
                                maxlength="100"
                            >
                        </div>

                        <div class="form-group">
                            <label for="descricao">
                                <i class="fas fa-align-left"></i>
                                Descrição *
                            </label>
                            <textarea
                                id="descricao"
                                name="descricao"
                                class="form-control"
                                placeholder="Descreva o spot: que tipo de obstáculos tem, qual o nível de dificuldade, horários recomendados, etc."
                                required
                                rows="4"
                            ><?php echo htmlspecialchars($form_data['descricao'] ?? ''); ?></textarea>
                            <small class="form-help">
                                Seja detalhado para ajudar outros skaters a saberem o que esperar.
                            </small>
                        </div>
                    </div>

                    <!-- Localização -->
                    <div class="form-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-map-marker-alt"></i>
                            Localização
                        </h2>

                        <div class="form-group">
                            <label for="location-search">
                                <i class="fas fa-search"></i>
                                Pesquisar Localização
                            </label>
                            <input
                                type="text"
                                id="location-search"
                                class="form-control"
                                placeholder="Digite o endereço ou nome do local..."
                            >
                            <small class="form-help">
                                Use a pesquisa ou clique no mapa para definir a localização.
                            </small>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="latitude">
                                    <i class="fas fa-crosshairs"></i>
                                    Latitude *
                                </label>
                                <input
                                    type="number"
                                    id="latitude"
                                    name="latitude"
                                    class="form-control"
                                    step="any"
                                    readonly
                                    value="<?php echo $form_data['latitude'] ?? ''; ?>"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="longitude">
                                    <i class="fas fa-crosshairs"></i>
                                    Longitude *
                                </label>
                                <input
                                    type="number"
                                    id="longitude"
                                    name="longitude"
                                    class="form-control"
                                    step="any"
                                    readonly
                                    value="<?php echo $form_data['longitude'] ?? ''; ?>"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="endereco">
                                <i class="fas fa-map-pin"></i>
                                Endereço
                            </label>
                            <input
                                type="text"
                                id="endereco"
                                name="endereco"
                                class="form-control"
                                placeholder="Endereço será preenchido automaticamente..."
                                value="<?php echo htmlspecialchars($form_data['endereco'] ?? ''); ?>"
                                readonly
                            >
                        </div>

                        <!-- Mapa Interativo -->
                        <div class="map-section">
                            <h3>Clique no mapa para definir a localização exata:</h3>
                            <div class="map-container">
                                <div id="map"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Fotos -->
                    <div class="form-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-camera"></i>
                            Fotos
                        </h2>

                        <div class="form-group">
                            <label for="foto_principal">
                                <i class="fas fa-image"></i>
                                Foto Principal *
                            </label>
                            <input
                                type="file"
                                id="foto_principal"
                                name="foto_principal"
                                class="form-control"
                                accept="image/*"
                                required
                            >
                            <small class="form-help">
                                Esta será a foto principal que aparece no mapa e listagens. Máximo 5MB.
                            </small>
                        </div>

                        <div class="form-group">
                            <label for="fotos_adicionais">
                                <i class="fas fa-images"></i>
                                Fotos Adicionais (Opcional)
                            </label>
                            <input
                                type="file"
                                id="fotos_adicionais"
                                name="fotos_adicionais[]"
                                class="form-control"
                                accept="image/*"
                                multiple
                            >
                            <small class="form-help">
                                Pode adicionar até 10 fotos adicionais para mostrar diferentes ângulos do spot.
                            </small>
                        </div>
                    </div>

                    <!-- Botões de Ação -->
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-plus-circle"></i>
                            Adicionar Spot
                        </button>

                        <a href="<?php echo SITE_URL; ?>" class="btn btn-outline btn-lg">
                            <i class="fas fa-times"></i>
                            Cancelar
                        </a>
                    </div>
                </form>
            </div>

            <!-- Dicas para Adicionar Spots -->
            <div class="tips-section">
                <div class="tips-card">
                    <h3>
                        <i class="fas fa-lightbulb"></i>
                        Dicas para um Bom Spot
                    </h3>
                    
                    <div class="tip-item">
                        <i class="fas fa-camera"></i>
                        <div>
                            <strong>Fotos de Qualidade:</strong>
                            Tire fotos nítidas e bem iluminadas que mostrem claramente os obstáculos e o ambiente.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Localização Precisa:</strong>
                            Certifique-se de que as coordenadas estão corretas para outros skaters encontrarem facilmente.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-info-circle"></i>
                        <div>
                            <strong>Descrição Completa:</strong>
                            Mencione tipo de obstáculos, nível de dificuldade, horários recomendados e qualquer informação útil.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <strong>Respeite a Propriedade:</strong>
                            Apenas adicione spots em locais públicos ou onde o skate é permitido.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-shield-alt"></i>
                        <div>
                            <strong>Segurança Primeiro:</strong>
                            Mencione eventuais riscos ou cuidados especiais necessários no local.
                        </div>
                    </div>
                </div>

                <div class="community-guidelines">
                    <h4>
                        <i class="fas fa-heart"></i>
                        Diretrizes da Comunidade
                    </h4>
                    <ul>
                        <li>Seja respeitoso e construtivo</li>
                        <li>Apenas spots reais e acessíveis</li>
                        <li>Fotos próprias ou com permissão</li>
                        <li>Informações precisas e úteis</li>
                        <li>Respeite propriedade privada</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Estilos específicos da página de adicionar spot */
.add-spot-container {
    min-height: calc(100vh - 160px);
    padding: 2rem 0;
}

.page-header {
    text-align: center;
    margin-bottom: 3rem;
}

.page-title {
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
}

.page-description {
    font-size: 1.125rem;
    color: var(--text-secondary);
    max-width: 600px;
    margin: 0 auto;
}

.add-spot-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 3rem;
    align-items: start;
}

.spot-form-section {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.form-section {
    margin-bottom: 3rem;
}

.form-section:last-child {
    margin-bottom: 2rem;
}

.form-section-title {
    font-size: 1.5rem;
    color: var(--primary-color);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid var(--border-color);
}

.map-section h3 {
    color: var(--text-primary);
    margin-bottom: 1rem;
    font-size: 1.125rem;
}

.form-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    padding-top: 2rem;
    border-top: 1px solid var(--border-color);
}

.tips-section {
    position: sticky;
    top: 100px;
}

.tips-card {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
    margin-bottom: 2rem;
}

.tips-card h3 {
    color: var(--primary-color);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.tip-item {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
    padding: 1rem;
    background: var(--background-color);
    border-radius: 10px;
    border-left: 4px solid var(--primary-color);
}

.tip-item i {
    color: var(--primary-color);
    font-size: 1.25rem;
    margin-top: 0.25rem;
    min-width: 20px;
}

.tip-item strong {
    color: var(--text-primary);
    display: block;
    margin-bottom: 0.25rem;
}

.tip-item div {
    color: var(--text-secondary);
    line-height: 1.5;
}

.community-guidelines {
    background: var(--background-color);
    border-radius: 15px;
    padding: 2rem;
    border: 1px solid var(--border-color);
}

.community-guidelines h4 {
    color: var(--primary-color);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.community-guidelines ul {
    list-style: none;
    padding: 0;
}

.community-guidelines li {
    padding: 0.5rem 0;
    color: var(--text-secondary);
    position: relative;
    padding-left: 1.5rem;
}

.community-guidelines li::before {
    content: '✓';
    position: absolute;
    left: 0;
    color: var(--success-color);
    font-weight: bold;
}

/* Responsive */
@media (max-width: 1024px) {
    .add-spot-content {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .tips-section {
        position: static;
    }
}

@media (max-width: 768px) {
    .page-title {
        font-size: 2rem;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .spot-form-section {
        padding: 1.5rem;
    }
    
    .tips-card {
        padding: 1.5rem;
    }
    
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tip-item {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .tip-item i {
        align-self: flex-start;
    }
}

@media (max-width: 480px) {
    .add-spot-container {
        padding: 1rem 0;
    }
    
    .spot-form-section {
        padding: 1rem;
    }
    
    .tips-card {
        padding: 1rem;
    }
}
</style>

<script>
// JavaScript específico para adicionar spots
document.addEventListener('DOMContentLoaded', function() {
    // Limitar número de fotos adicionais
    const fotosAdicionaisInput = document.getElementById('fotos_adicionais');
    if (fotosAdicionaisInput) {
        fotosAdicionaisInput.addEventListener('change', function() {
            if (this.files.length > 10) {
                SkateMap.showAlert('Máximo 10 fotos adicionais permitidas', 'warning');
                this.value = '';
            }
        });
    }
    
    // Validação personalizada do formulário
    const form = document.querySelector('.spot-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const latitude = document.getElementById('latitude').value;
            const longitude = document.getElementById('longitude').value;
            
            if (!latitude || !longitude || latitude == 0 || longitude == 0) {
                e.preventDefault();
                SkateMap.showAlert('Por favor, selecione a localização no mapa', 'error');
                return false;
            }
        });
    }
});

// Função para limpar formulário
function clearForm() {
    if (confirm('Tem certeza que deseja limpar todos os campos?')) {
        document.querySelector('.spot-form').reset();
        
        // Limpar previews de imagem
        const previews = document.querySelectorAll('.image-preview');
        previews.forEach(preview => preview.remove());
        
        // Limpar marcador temporário do mapa
        if (window.tempMarker) {
            window.tempMarker.setMap(null);
            window.tempMarker = null;
        }
        
        SkateMap.showAlert('Formulário limpo', 'success');
    }
}
</script>

<?php require_once 'includes/footer.php'; ?>