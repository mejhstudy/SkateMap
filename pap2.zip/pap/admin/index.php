<?php
/**
 * SkateMap - Painel Administrativo
 * PAP - Prova de Aptidão Profissional
 */

$page_title = 'Painel Administrativo';

require_once '../includes/config.php';

// Verificar se é administrador
if (!isLoggedIn() || !isAdmin()) {
    $_SESSION['error_message'] = 'Acesso negado. Apenas administradores podem aceder a esta área.';
    redirect(SITE_URL . '/login.php');
}

// Buscar estatísticas
try {
    $conn = getConnection();
    $stats = [];
    
    if ($conn) {
        // Total de spots
        $stmt = $conn->query("SELECT COUNT(*) as total FROM spots");
        $stats['total_spots'] = $stmt->fetch()['total'];
        
        // Total de utilizadores
        $stmt = $conn->query("SELECT COUNT(*) as total FROM utilizadores WHERE is_admin = 0");
        $stats['total_users'] = $stmt->fetch()['total'];
        
        // Total de comentários
        $stmt = $conn->query("SELECT COUNT(*) as total FROM comentarios");
        $stats['total_comments'] = $stmt->fetch()['total'];
        
        // Total de avaliações
        $stmt = $conn->query("SELECT COUNT(*) as total FROM avaliacoes");
        $stats['total_ratings'] = $stmt->fetch()['total'];
        
        // Spots recentes (últimos 5)
        $stmt = $conn->query("
            SELECT s.*, u.username 
            FROM spots s 
            LEFT JOIN utilizadores u ON s.id_usuario = u.id 
            ORDER BY s.data_criacao DESC 
            LIMIT 5
        ");
        $recent_spots = $stmt->fetchAll();
        
        // Utilizadores recentes (últimos 5)
        $stmt = $conn->query("
            SELECT * FROM utilizadores 
            WHERE is_admin = 0 
            ORDER BY data_criacao DESC 
            LIMIT 5
        ");
        $recent_users = $stmt->fetchAll();
        
        // Comentários recentes (últimos 5)
        $stmt = $conn->query("
            SELECT c.*, u.username, s.nome as spot_nome
            FROM comentarios c
            LEFT JOIN utilizadores u ON c.id_usuario = u.id
            LEFT JOIN spots s ON c.id_spot = s.id
            ORDER BY c.data_publicacao DESC
            LIMIT 5
        ");
        $recent_comments = $stmt->fetchAll();
        
    }
} catch (Exception $e) {
    error_log("Erro no painel admin: " . $e->getMessage());
    $stats = ['total_spots' => 0, 'total_users' => 0, 'total_comments' => 0, 'total_ratings' => 0];
    $recent_spots = [];
    $recent_users = [];
    $recent_comments = [];
}

require_once '../includes/header.php';
?>

<div class="admin-container">
    <div class="container">
        
        <!-- Header do Admin -->
        <div class="admin-header">
            <h1 class="admin-title">
                <i class="fas fa-tachometer-alt"></i>
                Painel Administrativo
            </h1>
            <p class="admin-description">
                Gerir utilizadores, spots, comentários e outras funcionalidades do SkateMap
            </p>
        </div>

        <!-- Navegação do Admin -->
        <div class="admin-nav">
            <a href="index.php" class="admin-nav-item active">
                <i class="fas fa-home"></i>
                Dashboard
            </a>
            <a href="spots.php" class="admin-nav-item">
                <i class="fas fa-map-marker-alt"></i>
                Spots (<?php echo $stats['total_spots']; ?>)
            </a>
            <a href="users.php" class="admin-nav-item">
                <i class="fas fa-users"></i>
                Utilizadores (<?php echo $stats['total_users']; ?>)
            </a>
            <a href="comments.php" class="admin-nav-item">
                <i class="fas fa-comments"></i>
                Comentários (<?php echo $stats['total_comments']; ?>)
            </a>
            <a href="settings.php" class="admin-nav-item">
                <i class="fas fa-cogs"></i>
                Configurações
            </a>
        </div>

        <!-- Estatísticas Gerais -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon spots">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($stats['total_spots']); ?></h3>
                    <p>Spots Totais</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon users">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($stats['total_users']); ?></h3>
                    <p>Utilizadores</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon comments">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($stats['total_comments']); ?></h3>
                    <p>Comentários</p>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon ratings">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($stats['total_ratings']); ?></h3>
                    <p>Avaliações</p>
                </div>
            </div>
        </div>

        <!-- Conteúdo Principal -->
        <div class="admin-content">
            
            <!-- Spots Recentes -->
            <div class="admin-section">
                <div class="section-header">
                    <h2>
                        <i class="fas fa-map-marker-alt"></i>
                        Spots Recentes
                    </h2>
                    <a href="spots.php" class="btn btn-outline btn-sm">Ver Todos</a>
                </div>
                
                <div class="data-table">
                    <?php if (empty($recent_spots)): ?>
                        <div class="empty-state">
                            <i class="fas fa-map-marker-alt"></i>
                            <p>Nenhum spot encontrado</p>
                        </div>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Autor</th>
                                    <th>Localização</th>
                                    <th>Data</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_spots as $spot): ?>
                                    <tr>
                                        <td class="spot-name">
                                            <strong><?php echo sanitize($spot['nome']); ?></strong>
                                        </td>
                                        <td><?php echo sanitize($spot['username']); ?></td>
                                        <td class="location">
                                            <?php echo sanitize(substr($spot['endereco'], 0, 50)); ?>
                                            <?php if (strlen($spot['endereco']) > 50) echo '...'; ?>
                                        </td>
                                        <td><?php echo date('d/m/Y', strtotime($spot['data_criacao'])); ?></td>
                                        <td class="actions">
                                            <a href="../spot_detalhes.php?id=<?php echo $spot['id']; ?>" 
                                               class="btn-action view" title="Ver">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <a href="spot_edit.php?id=<?php echo $spot['id']; ?>" 
                                               class="btn-action edit" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button onclick="deleteSpot(<?php echo $spot['id']; ?>)" 
                                                    class="btn-action delete" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Utilizadores Recentes -->
            <div class="admin-section">
                <div class="section-header">
                    <h2>
                        <i class="fas fa-users"></i>
                        Utilizadores Recentes
                    </h2>
                    <a href="users.php" class="btn btn-outline btn-sm">Ver Todos</a>
                </div>
                
                <div class="data-table">
                    <?php if (empty($recent_users)): ?>
                        <div class="empty-state">
                            <i class="fas fa-users"></i>
                            <p>Nenhum utilizador encontrado</p>
                        </div>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Data de Registo</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_users as $user): ?>
                                    <tr>
                                        <td class="username">
                                            <strong><?php echo sanitize($user['username']); ?></strong>
                                        </td>
                                        <td><?php echo sanitize($user['email']); ?></td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($user['data_criacao'])); ?></td>
                                        <td class="actions">
                                            <a href="user_edit.php?id=<?php echo $user['id']; ?>" 
                                               class="btn-action edit" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button onclick="deleteUser(<?php echo $user['id']; ?>)" 
                                                    class="btn-action delete" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Comentários Recentes -->
            <div class="admin-section">
                <div class="section-header">
                    <h2>
                        <i class="fas fa-comments"></i>
                        Comentários Recentes
                    </h2>
                    <a href="comments.php" class="btn btn-outline btn-sm">Ver Todos</a>
                </div>
                
                <div class="data-table">
                    <?php if (empty($recent_comments)): ?>
                        <div class="empty-state">
                            <i class="fas fa-comments"></i>
                            <p>Nenhum comentário encontrado</p>
                        </div>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Utilizador</th>
                                    <th>Spot</th>
                                    <th>Comentário</th>
                                    <th>Data</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_comments as $comment): ?>
                                    <tr>
                                        <td><?php echo sanitize($comment['username']); ?></td>
                                        <td class="spot-name">
                                            <?php echo sanitize($comment['spot_nome']); ?>
                                        </td>
                                        <td class="comment-text">
                                            <?php 
                                            $text = sanitize($comment['texto']);
                                            echo strlen($text) > 50 ? substr($text, 0, 50) . '...' : $text;
                                            ?>
                                        </td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($comment['data_publicacao'])); ?></td>
                                        <td class="actions">
                                            <a href="../spot_detalhes.php?id=<?php echo $comment['id_spot']; ?>" 
                                               class="btn-action view" title="Ver Spot">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                            <button onclick="deleteComment(<?php echo $comment['id']; ?>)" 
                                                    class="btn-action delete" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* Estilos do painel administrativo */
.admin-container {
    min-height: calc(100vh - 160px);
    padding: 2rem 0;
}

.admin-header {
    text-align: center;
    margin-bottom: 3rem;
    padding: 2rem;
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: white;
    border-radius: 15px;
}

.admin-title {
    font-size: 2.5rem;
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
}

.admin-description {
    font-size: 1.125rem;
    opacity: 0.9;
}

.admin-nav {
    display: flex;
    gap: 1rem;
    margin-bottom: 3rem;
    overflow-x: auto;
    padding-bottom: 0.5rem;
}

.admin-nav-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    background: var(--surface-color);
    color: var(--text-primary);
    text-decoration: none;
    border-radius: 25px;
    border: 1px solid var(--border-color);
    transition: all 0.3s ease;
    white-space: nowrap;
    font-weight: 500;
}

.admin-nav-item:hover {
    background: var(--primary-color);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px var(--shadow-color);
}

.admin-nav-item.active {
    background: var(--primary-color);
    color: white;
    box-shadow: 0 5px 15px var(--shadow-color);
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
}

.stat-card {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: white;
}

.stat-icon.spots { background: #2196F3; }
.stat-icon.users { background: #4CAF50; }
.stat-icon.comments { background: #FF9800; }
.stat-icon.ratings { background: #9C27B0; }

.stat-info h3 {
    font-size: 2rem;
    color: var(--text-primary);
    margin-bottom: 0.25rem;
}

.stat-info p {
    color: var(--text-secondary);
    font-size: 0.875rem;
}

.admin-content {
    display: flex;
    flex-direction: column;
    gap: 3rem;
}

.admin-section {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border-color);
}

.section-header h2 {
    color: var(--primary-color);
    display: flex;
    align-items: center;
    gap: 0.75rem;
    font-size: 1.5rem;
}

.data-table {
    overflow-x: auto;
}

.data-table table {
    width: 100%;
    border-collapse: collapse;
}

.data-table th {
    text-align: left;
    padding: 1rem;
    background: var(--background-color);
    color: var(--text-primary);
    font-weight: 600;
    border-bottom: 2px solid var(--border-color);
}

.data-table td {
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    color: var(--text-primary);
}

.data-table tbody tr:hover {
    background: var(--background-color);
}

.spot-name strong,
.username strong {
    color: var(--primary-color);
}

.location,
.comment-text {
    color: var(--text-secondary);
    font-size: 0.875rem;
}

.actions {
    display: flex;
    gap: 0.5rem;
}

.btn-action {
    width: 32px;
    height: 32px;
    border: none;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-decoration: none;
    font-size: 0.875rem;
    transition: all 0.3s ease;
}

.btn-action.view {
    background: #2196F3;
    color: white;
}

.btn-action.edit {
    background: #4CAF50;
    color: white;
}

.btn-action.delete {
    background: #F44336;
    color: white;
}

.btn-action:hover {
    transform: scale(1.1);
    box-shadow: 0 3px 10px var(--shadow-color);
}

.empty-state {
    text-align: center;
    padding: 3rem;
    color: var(--text-secondary);
}

.empty-state i {
    font-size: 3rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

/* Responsive */
@media (max-width: 768px) {
    .admin-title {
        font-size: 2rem;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .admin-nav {
        flex-direction: column;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .stat-card {
        padding: 1.5rem;
    }
    
    .section-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
    }
    
    .data-table {
        font-size: 0.875rem;
    }
    
    .data-table th,
    .data-table td {
        padding: 0.75rem 0.5rem;
    }
}

@media (max-width: 480px) {
    .admin-container {
        padding: 1rem 0;
    }
    
    .admin-section {
        padding: 1rem;
    }
    
    .actions {
        flex-direction: column;
    }
    
    .btn-action {
        width: 28px;
        height: 28px;
    }
}
</style>

<script>
// JavaScript para o painel administrativo
function deleteSpot(spotId) {
    if (confirm('Tem certeza que deseja eliminar este spot? Esta ação não pode ser desfeita.')) {
        // Implementar AJAX para eliminar spot
        fetch('actions/delete_spot.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + spotId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                SkateMap.showAlert('Spot eliminado com sucesso', 'success');
                location.reload();
            } else {
                SkateMap.showAlert('Erro ao eliminar spot: ' + data.message, 'error');
            }
        })
        .catch(error => {
            SkateMap.showAlert('Erro de conexão', 'error');
        });
    }
}

function deleteUser(userId) {
    if (confirm('Tem certeza que deseja eliminar este utilizador? Esta ação não pode ser desfeita.')) {
        // Implementar AJAX para eliminar utilizador
        SkateMap.showAlert('Funcionalidade em desenvolvimento', 'warning');
    }
}

function deleteComment(commentId) {
    if (confirm('Tem certeza que deseja eliminar este comentário?')) {
        // Implementar AJAX para eliminar comentário
        SkateMap.showAlert('Funcionalidade em desenvolvimento', 'warning');
    }
}

// Auto-refresh das estatísticas a cada 30 segundos
setInterval(() => {
    // Implementar refresh automático das estatísticas
}, 30000);
</script>

<?php require_once '../includes/footer.php'; ?>