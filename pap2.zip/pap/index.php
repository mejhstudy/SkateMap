<?php
/**
 * SkateMap - Página Principal
 * PAP - Prova de Aptidão Profissional
 * 
 * Página principal com mapa e lista de spots
 */

$page_title = 'Mapa de Skate Spots';
$load_maps_js = true;

require_once 'includes/config.php';
require_once 'includes/header.php';

// Buscar estatísticas para exibir
try {
    $conn = getConnection();
    $totalSpots = 0;
    $totalUsers = 0;
    $recentSpots = [];
    
    if ($conn) {
        // Contar spots totais
        $stmt = $conn->query("SELECT COUNT(*) as total FROM spots");
        $totalSpots = $stmt->fetch()['total'];
        
        // Contar utilizadores
        $stmt = $conn->query("SELECT COUNT(*) as total FROM utilizadores WHERE is_admin = 0");
        $totalUsers = $stmt->fetch()['total'];
        
        // Buscar spots recentes com informações do utilizador e média de avaliações
        $stmt = $conn->query("
            SELECT s.*, u.username,
                   AVG(a.nota) as rating_medio,
                   COUNT(a.id) as total_avaliacoes
            FROM spots s
            LEFT JOIN utilizadores u ON s.id_usuario = u.id
            LEFT JOIN avaliacoes a ON s.id = a.id_spot
            GROUP BY s.id
            ORDER BY s.data_criacao DESC
            LIMIT 6
        ");
        $recentSpots = $stmt->fetchAll();
    }
} catch (Exception $e) {
    error_log("Erro ao buscar dados da página inicial: " . $e->getMessage());
}
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="hero-content">
            <div class="hero-text">
                <h1 class="hero-title">
                    <i class="fas fa-map-marked-alt"></i>
                    Descobre os Melhores Skate Spots de Portugal
                </h1>
                <p class="hero-description">
                    O SkateMap é o mapa colaborativo definitivo para a comunidade de skate portuguesa. 
                    Descobre spots incríveis, adiciona os teus favoritos e conecta-te com outros skaters.
                </p>
                <div class="hero-stats">
                    <div class="stat">
                        <span class="stat-number"><?php echo $totalSpots; ?></span>
                        <span class="stat-label">Spots</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number"><?php echo $totalUsers; ?></span>
                        <span class="stat-label">Skaters</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number"><?php echo count($recentSpots); ?></span>
                        <span class="stat-label">Recentes</span>
                    </div>
                </div>
                <div class="hero-actions">
                    <?php if (isLoggedIn()): ?>
                        <a href="add_spot.php" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Adicionar Spot
                        </a>
                    <?php else: ?>
                        <a href="register.php" class="btn btn-primary">
                            <i class="fas fa-user-plus"></i> Junta-te à Comunidade
                        </a>
                        <a href="login.php" class="btn btn-outline">
                            <i class="fas fa-sign-in-alt"></i> Entrar
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="hero-visual">
                <div class="hero-image">
                    <i class="fas fa-skateboard"></i>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="map-section">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">
                <i class="fas fa-map"></i>
                Mapa de Spots
            </h2>
            <p class="section-description">
                Explora todos os spots de skate em Portugal. Clica nos marcadores para mais informações.
            </p>
            
            <!-- Controles do Mapa -->
            <div class="map-controls">
                <div class="search-location">
                    <input 
                        type="text" 
                        id="location-search" 
                        class="form-control" 
                        placeholder="Pesquisar localização..."
                    >
                </div>
                
                <div class="map-filters">
                    <button class="btn btn-secondary" onclick="loadSpots()">
                        <i class="fas fa-refresh"></i> Atualizar
                    </button>
                    
                    <?php if (isLoggedIn()): ?>
                        <button class="btn btn-secondary" onclick="findNearbySpots()">
                            <i class="fas fa-location-arrow"></i> Próximos
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Mapa -->
        <div class="map-container">
            <div id="map"></div>
        </div>
    </div>
</section>

<!-- Recent Spots Section -->
<?php if (!empty($recentSpots)): ?>
<section class="recent-spots-section">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">
                <i class="fas fa-clock"></i>
                Spots Recentes
            </h2>
            <p class="section-description">
                Os spots mais recentemente adicionados pela nossa comunidade.
            </p>
        </div>
        
        <div class="spots-grid">
            <?php foreach ($recentSpots as $spot): ?>
                <div class="spot-card">
                    <div class="spot-image-container">
                        <?php 
                        $imagePath = !empty($spot['foto_principal']) ? 
                            "uploads/spots/" . $spot['foto_principal'] : 
                            "assets/images/default-spot.jpg";
                        ?>
                        <img 
                            src="<?php echo $imagePath; ?>" 
                            alt="<?php echo sanitize($spot['nome']); ?>"
                            class="spot-image"
                            onerror="this.src='assets/images/default-spot.jpg'"
                        >
                        
                        <!-- Badge de novo spot -->
                        <div class="spot-badge">
                            <i class="fas fa-star"></i>
                            Novo
                        </div>
                    </div>
                    
                    <div class="spot-content">
                        <h3 class="spot-title">
                            <?php echo sanitize($spot['nome']); ?>
                        </h3>
                        
                        <p class="spot-description">
                            <?php 
                            $description = sanitize($spot['descricao']);
                            echo strlen($description) > 100 ? 
                                substr($description, 0, 100) . '...' : 
                                $description;
                            ?>
                        </p>
                        
                        <div class="spot-meta">
                            <div class="spot-rating">
                                <?php 
                                $rating = $spot['rating_medio'] ?: 0;
                                $totalRatings = $spot['total_avaliacoes'] ?: 0;
                                ?>
                                <div class="stars">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php if ($i <= floor($rating)): ?>
                                            <i class="fas fa-star"></i>
                                        <?php elseif ($i == floor($rating) + 1 && $rating - floor($rating) >= 0.5): ?>
                                            <i class="fas fa-star-half-alt"></i>
                                        <?php else: ?>
                                            <i class="far fa-star"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                                <span class="rating-text">
                                    (<?php echo $totalRatings; ?>)
                                </span>
                            </div>
                            
                            <div class="spot-author">
                                <i class="fas fa-user"></i>
                                <?php echo sanitize($spot['username']); ?>
                            </div>
                        </div>
                        
                        <div class="spot-location">
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo sanitize($spot['endereco']); ?>
                        </div>
                        
                        <div class="spot-actions">
                            <a 
                                href="spot_detalhes.php?id=<?php echo $spot['id']; ?>" 
                                class="btn btn-primary btn-sm"
                            >
                                <i class="fas fa-eye"></i>
                                Ver Detalhes
                            </a>
                            
                            <button 
                                class="btn btn-outline btn-sm" 
                                onclick="focusSpot(<?php echo $spot['id']; ?>)"
                                title="Ver no mapa"
                            >
                                <i class="fas fa-map-pin"></i>
                                Mapa
                            </button>
                            
                            <button 
                                class="btn btn-outline btn-sm" 
                                onclick="openDirections(<?php echo $spot['latitude']; ?>, <?php echo $spot['longitude']; ?>)"
                                title="Ver trajeto"
                            >
                                <i class="fas fa-directions"></i>
                                Trajeto
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="text-center mt-4">
            <a href="spots.php" class="btn btn-outline">
                <i class="fas fa-th"></i>
                Ver Todos os Spots
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">
                <i class="fas fa-rocket"></i>
                Funcionalidades
            </h2>
            <p class="section-description">
                Descobre tudo o que o SkateMap tem para oferecer à comunidade de skate.
            </p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-map-marked-alt"></i>
                </div>
                <h3 class="feature-title">Mapa Interativo</h3>
                <p class="feature-description">
                    Explora spots em todo o mundo com o nosso mapa interativo baseado no Google Maps.
                </p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-plus-circle"></i>
                </div>
                <h3 class="feature-title">Adicionar Spots</h3>
                <p class="feature-description">
                    Contribui para a comunidade adicionando novos spots que descobriste.
                </p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-star"></i>
                </div>
                <h3 class="feature-title">Avaliações</h3>
                <p class="feature-description">
                    Avalia spots e vê as opiniões de outros skaters sobre cada localização.
                </p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <h3 class="feature-title">Comentários</h3>
                <p class="feature-description">
                    Partilha dicas, experiências e conecta-te com outros skaters.
                </p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-camera"></i>
                </div>
                <h3 class="feature-title">Fotos & Vídeos</h3>
                <p class="feature-description">
                    Partilha fotos e vídeos dos teus truques nos diferentes spots.
                </p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h3 class="feature-title">Responsivo</h3>
                <p class="feature-description">
                    Acede ao SkateMap em qualquer dispositivo, onde quer que estejas.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<?php if (!isLoggedIn()): ?>
<section class="cta-section">
    <div class="container">
        <div class="cta-content">
            <h2 class="cta-title">
                Pronto para Começar?
            </h2>
            <p class="cta-description">
                Junta-te à nossa comunidade de skaters e começa a explorar os melhores spots!
            </p>
            <div class="cta-actions">
                <a href="register.php" class="btn btn-primary btn-lg">
                    <i class="fas fa-user-plus"></i>
                    Criar Conta Grátis
                </a>
                <a href="login.php" class="btn btn-outline btn-lg">
                    <i class="fas fa-sign-in-alt"></i>
                    Já Tenho Conta
                </a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<style>
/* Estilos específicos da página inicial */
.hero-section {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: white;
    padding: 4rem 0;
    margin-top: -80px;
    padding-top: 6rem;
}

.hero-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 3rem;
    align-items: center;
}

.hero-title {
    font-size: 3rem;
    font-weight: bold;
    margin-bottom: 1rem;
    line-height: 1.2;
}

.hero-description {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    opacity: 0.9;
    line-height: 1.6;
}

.hero-stats {
    display: flex;
    gap: 2rem;
    margin-bottom: 2rem;
}

.stat {
    text-align: center;
}

.stat-number {
    display: block;
    font-size: 2rem;
    font-weight: bold;
    color: var(--accent-color);
}

.stat-label {
    font-size: 0.875rem;
    opacity: 0.8;
}

.hero-actions {
    display: flex;
    gap: 1rem;
    flex-wrap: wrap;
}

.hero-visual {
    display: flex;
    justify-content: center;
    align-items: center;
}

.hero-image i {
    font-size: 12rem;
    color: rgba(255, 255, 255, 0.2);
    animation: float 3s ease-in-out infinite;
}

@keyframes float {
    0%, 100% { transform: translateY(0px); }
    50% { transform: translateY(-20px); }
}

.section-header {
    text-align: center;
    margin-bottom: 3rem;
}

.section-title {
    font-size: 2.5rem;
    margin-bottom: 1rem;
    color: var(--text-primary);
}

.section-description {
    font-size: 1.125rem;
    color: var(--text-secondary);
    max-width: 600px;
    margin: 0 auto 2rem;
}

.map-controls {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
    margin-bottom: 2rem;
}

.search-location {
    flex: 1;
    max-width: 400px;
}

.map-filters {
    display: flex;
    gap: 1rem;
}

.recent-spots-section {
    padding: 4rem 0;
    background: var(--surface-color);
}

.spot-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    background: var(--accent-color);
    color: white;
    padding: 0.25rem 0.75rem;
    border-radius: 15px;
    font-size: 0.75rem;
    font-weight: bold;
}

.spot-image-container {
    position: relative;
    overflow: hidden;
}

.spot-location {
    color: var(--text-secondary);
    font-size: 0.875rem;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.features-section {
    padding: 4rem 0;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.feature-card {
    background: var(--surface-color);
    padding: 2rem;
    border-radius: 15px;
    text-align: center;
    box-shadow: 0 5px 15px var(--shadow-color);
    transition: transform 0.3s ease;
}

.feature-card:hover {
    transform: translateY(-5px);
}

.feature-icon {
    font-size: 3rem;
    color: var(--primary-color);
    margin-bottom: 1rem;
}

.feature-title {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: var(--text-primary);
}

.feature-description {
    color: var(--text-secondary);
    line-height: 1.6;
}

.cta-section {
    background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
    color: white;
    padding: 4rem 0;
    text-align: center;
}

.cta-title {
    font-size: 2.5rem;
    margin-bottom: 1rem;
}

.cta-description {
    font-size: 1.25rem;
    margin-bottom: 2rem;
    opacity: 0.9;
}

.cta-actions {
    display: flex;
    justify-content: center;
    gap: 1rem;
    flex-wrap: wrap;
}

/* Responsive */
@media (max-width: 768px) {
    .hero-content {
        grid-template-columns: 1fr;
        text-align: center;
    }
    
    .hero-title {
        font-size: 2rem;
    }
    
    .hero-stats {
        justify-content: center;
    }
    
    .hero-image i {
        font-size: 6rem;
    }
    
    .map-controls {
        flex-direction: column;
        align-items: stretch;
    }
    
    .map-filters {
        justify-content: center;
    }
    
    .features-grid {
        grid-template-columns: 1fr;
    }
    
    .cta-actions {
        flex-direction: column;
        align-items: center;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>