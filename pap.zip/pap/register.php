<?php
/**
 * SkateMap - Página de Registo
 * PAP - Prova de Aptidão Profissional
 */

$page_title = 'Criar Conta';

require_once 'includes/config.php';

// Se já está logado, redirecionar
if (isLoggedIn()) {
    redirect(SITE_URL);
}

$error_message = '';
$form_data = [];

// Processar formulário de registo
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $terms_accepted = isset($_POST['terms_accepted']);
    
    // Guardar dados do formulário para reexibir em caso de erro
    $form_data = compact('username', 'email');
    
    // Validações
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error_message = 'Por favor, preencha todos os campos obrigatórios.';
    } elseif (strlen($username) < 3) {
        $error_message = 'O nome de utilizador deve ter pelo menos 3 caracteres.';
    } elseif (strlen($username) > 50) {
        $error_message = 'O nome de utilizador não pode ter mais de 50 caracteres.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error_message = 'O nome de utilizador só pode conter letras, números e underscore.';
    } elseif (!validateEmail($email)) {
        $error_message = 'Por favor, insira um email válido.';
    } elseif (strlen($password) < 6) {
        $error_message = 'A password deve ter pelo menos 6 caracteres.';
    } elseif ($password !== $confirm_password) {
        $error_message = 'As passwords não coincidem.';
    } elseif (!$terms_accepted) {
        $error_message = 'Deve aceitar os termos e condições para se registar.';
    } else {
        try {
            $conn = getConnection();
            if ($conn) {
                // Verificar se username já existe
                $stmt = $conn->prepare("SELECT id FROM utilizadores WHERE username = ?");
                $stmt->execute([$username]);
                if ($stmt->fetch()) {
                    $error_message = 'Este nome de utilizador já está em uso.';
                } else {
                    // Verificar se email já existe
                    $stmt = $conn->prepare("SELECT id FROM utilizadores WHERE email = ?");
                    $stmt->execute([$email]);
                    if ($stmt->fetch()) {
                        $error_message = 'Este email já está registado.';
                    } else {
                        // Criar novo utilizador
                        $hashed_password = hashPassword($password);
                        
                        $stmt = $conn->prepare("
                            INSERT INTO utilizadores (username, email, password, is_admin) 
                            VALUES (?, ?, ?, FALSE)
                        ");
                        
                        if ($stmt->execute([$username, $email, $hashed_password])) {
                            // Registo bem-sucedido
                            redirect(SITE_URL . '/login.php?registered=true');
                        } else {
                            $error_message = 'Erro ao criar a conta. Tente novamente.';
                        }
                    }
                }
            } else {
                $error_message = 'Erro de conexão com a base de dados.';
            }
        } catch (Exception $e) {
            error_log("Erro no registo: " . $e->getMessage());
            $error_message = 'Erro interno. Tente novamente.';
        }
    }
}

// Definir que esta é uma página especial (sem header/footer padrão)
$hide_default_layout = true;
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - SkateMap</title>
    
    <!-- Meta tags -->
    <meta name="description" content="Crie a sua conta SkateMap e junte-se à comunidade de skate portuguesa.">
    <meta name="keywords" content="registo, criar conta, skatemap, skate, spots, portugal">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo SITE_URL; ?>/assets/favicon.ico">
    
    <!-- CSS Principal -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="auth-page">

<!-- Navegação Simplificada -->
<nav class="auth-nav">
    <div class="auth-nav-content">
        <a href="<?php echo SITE_URL; ?>" class="auth-logo">
            <i class="fas fa-map-marked-alt"></i>
            <span>SkateMap</span>
        </a>
        <div class="auth-nav-links">
            <a href="<?php echo SITE_URL; ?>" class="nav-link">
                <i class="fas fa-home"></i> Início
            </a>
            <a href="login.php" class="nav-link">
                <i class="fas fa-sign-in-alt"></i> Entrar
            </a>
        </div>
    </div>
</nav>

<?php
?>

<div class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <h1 class="auth-title">
                <i class="fas fa-user-plus"></i>
                Criar Conta no SkateMap
            </h1>
            <p class="auth-description">
                Junta-te à nossa comunidade e descobre os melhores spots de skate
            </p>
        </div>

        <?php if ($error_message): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="auth-form" data-validate="true">
            <div class="form-group">
                <label for="username">
                    <i class="fas fa-user"></i>
                    Nome de Utilizador *
                </label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    class="form-control"
                    placeholder="Escolha um nome de utilizador"
                    value="<?php echo htmlspecialchars($form_data['username'] ?? ''); ?>"
                    required
                    minlength="3"
                    maxlength="50"
                    pattern="[a-zA-Z0-9_]+"
                    title="Apenas letras, números e underscore"
                    autocomplete="username"
                >
                <small class="form-help">
                    3-50 caracteres. Apenas letras, números e underscore (_).
                </small>
            </div>

            <div class="form-group">
                <label for="email">
                    <i class="fas fa-envelope"></i>
                    Email *
                </label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    class="form-control"
                    placeholder="seu@email.com"
                    value="<?php echo htmlspecialchars($form_data['email'] ?? ''); ?>"
                    required
                    autocomplete="email"
                >
            </div>

            <div class="form-group">
                <label for="password">
                    <i class="fas fa-lock"></i>
                    Password *
                </label>
                <div class="password-input-group">
                    <input
                        type="password"
                        id="password"
                        name="password"
                        class="form-control password-field"
                        placeholder="Crie uma password segura"
                        required
                        minlength="6"
                        autocomplete="new-password"
                    >
                    <button type="button" class="password-toggle" onclick="toggleAllPasswords()" title="Mostrar/Ocultar Passwords">
                        <i class="fas fa-eye" id="password-toggle-icon"></i>
                    </button>
                </div>
                <div class="password-strength" id="passwordStrength"></div>
            </div>

            <div class="form-group">
                <label for="confirm_password">
                    <i class="fas fa-lock"></i>
                    Confirmar Password *
                </label>
                <input
                    type="password"
                    id="confirm_password"
                    name="confirm_password"
                    class="form-control password-field"
                    placeholder="Repita a password"
                    required
                    autocomplete="new-password"
                >
            </div>

            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="terms_accepted" value="1" required>
                    <span class="checkbox-custom"></span>
                    Aceito os 
                    <a href="#" onclick="showTerms()" class="auth-link">termos e condições</a>
                    e a 
                    <a href="#" onclick="showPrivacyPolicy()" class="auth-link">política de privacidade</a>
                </label>
            </div>

            <div class="form-group">
                <label class="checkbox-label">
                    <input type="checkbox" name="newsletter" value="1">
                    <span class="checkbox-custom"></span>
                    Quero receber notificações sobre novos spots na minha região
                </label>
            </div>

            <button type="submit" class="btn btn-primary btn-lg w-100">
                <i class="fas fa-user-plus"></i>
                Criar Conta
            </button>
        </form>

        <!-- Seção de alternativas oculta temporariamente
        <div class="auth-divider">
            <span>ou</span>
        </div>

        <div class="auth-alternatives">
            <button class="btn btn-outline w-100" onclick="registerWithGoogle()" disabled>
                <i class="fab fa-google"></i>
                Registar com Google
                <small>(Em breve)</small>
            </button>
        </div>
        -->

        <div class="auth-footer-section">
            <p>
                Já tem conta?
                <a href="login.php" class="auth-link">
                    <i class="fas fa-sign-in-alt"></i>
                    Entrar agora
                </a>
            </p>
        </div>
    </div>

    <!-- Benefícios de se registar -->
    <div class="auth-info">
        <h3>
            <i class="fas fa-star"></i>
            Benefícios da Conta
        </h3>
        <ul class="info-list">
            <li>
                <i class="fas fa-plus-circle"></i>
                <strong>Adicionar Spots:</strong> Partilhe novos locais com a comunidade
            </li>
            <li>
                <i class="fas fa-comments"></i>
                <strong>Comentários:</strong> Partilhe experiências e dicas
            </li>
            <li>
                <i class="fas fa-star"></i>
                <strong>Avaliações:</strong> Avalie spots e veja opiniões
            </li>
            <li>
                <i class="fas fa-camera"></i>
                <strong>Media:</strong> Envie fotos e vídeos dos seus truques
            </li>
            <li>
                <i class="fas fa-heart"></i>
                <strong>Favoritos:</strong> Guarde os seus spots preferidos
            </li>
            <li>
                <i class="fas fa-users"></i>
                <strong>Comunidade:</strong> Conecte-se com outros skaters
            </li>
        </ul>

        <div class="community-stats">
            <h4>
                <i class="fas fa-chart-line"></i>
                Nossa Comunidade
            </h4>
            <?php
            try {
                $conn = getConnection();
                if ($conn) {
                    $stmt = $conn->query("SELECT COUNT(*) as total FROM spots");
                    $totalSpots = $stmt->fetch()['total'];
                    
                    $stmt = $conn->query("SELECT COUNT(*) as total FROM utilizadores WHERE is_admin = 0");
                    $totalUsers = $stmt->fetch()['total'];
                    
                    echo "<div class='stats-grid'>";
                    echo "<div class='stat-item'><strong>{$totalSpots}</strong><span>Spots</span></div>";
                    echo "<div class='stat-item'><strong>{$totalUsers}</strong><span>Membros</span></div>";
                    echo "</div>";
                }
            } catch (Exception $e) {
                echo "<p>Centenas de spots e skaters ativos!</p>";
            }
            ?>
        </div>
    </div>
</div>

<style>
/* Reset para página de autenticação */
.auth-page {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
}

.auth-page::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
        radial-gradient(circle at 25% 25%, rgba(255, 255, 255, 0.1) 0%, transparent 50%),
        radial-gradient(circle at 75% 75%, rgba(255, 255, 255, 0.05) 0%, transparent 50%);
    pointer-events: none;
    z-index: 0;
}

/* Navegação Simplificada */
.auth-nav {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    z-index: 1000;
    padding: 1rem 0;
}

.auth-nav-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.auth-logo {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    text-decoration: none;
    color: white;
    font-size: 1.5rem;
    font-weight: 800;
    letter-spacing: -0.5px;
}

.auth-logo i {
    font-size: 1.8rem;
}

.auth-nav-links {
    display: flex;
    gap: 1.5rem;
}

.nav-link {
    color: rgba(255, 255, 255, 0.9);
    text-decoration: none;
    padding: 0.5rem 1rem;
    border-radius: 25px;
    transition: all 0.3s ease;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.nav-link:hover {
    background: rgba(255, 255, 255, 0.2);
    color: white;
    transform: translateY(-2px);
}

/* Footer Simplificado */
.auth-footer {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(20px);
    border-top: 1px solid rgba(255, 255, 255, 0.1);
    padding: 1rem 0;
    z-index: 1000;
}

.auth-footer-content {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.9rem;
}

.auth-footer-links {
    display: flex;
    gap: 1.5rem;
}

.auth-footer-links a {
    color: rgba(255, 255, 255, 0.7);
    text-decoration: none;
    transition: color 0.3s ease;
}

.auth-footer-links a:hover {
    color: white;
}

/* Container principal */
.auth-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
    max-width: 1200px;
    margin: 0 auto;
    padding: 100px 2rem 80px 2rem;
    min-height: 100vh;
    align-items: center;
    position: relative;
    z-index: 1;
}

.auth-card {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(20px);
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    z-index: 1;
    transform: translateY(0);
    transition: all 0.3s ease;
    width: 100%;
    box-sizing: border-box;
    overflow: hidden;
}

.auth-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 30px 60px rgba(0, 0, 0, 0.15);
}

.auth-header {
    text-align: center;
    margin-bottom: 1.5rem;
}

.auth-title {
    font-size: 2rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.5rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    font-weight: 700;
    letter-spacing: -0.5px;
}

.auth-title i {
    color: #667eea;
    font-size: 2.2rem;
}

.auth-description {
    color: #6b7280;
    font-size: 1.1rem;
    font-weight: 400;
    line-height: 1.5;
}

.auth-form {
    margin-bottom: 1.5rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1.5rem;
    margin-bottom: 2rem;
}

@media (max-width: 640px) {
    .form-row {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}

.form-group label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 0.8rem;
    color: #374151;
    font-weight: 600;
    font-size: 0.95rem;
}

.form-control {
    width: 100%;
    padding: 1rem 1.2rem;
    border: 2px solid #e5e7eb;
    border-radius: 15px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(10px);
    box-sizing: border-box;
    max-width: 100%;
}

.form-control:focus {
    outline: none;
    border-color: #667eea;
    background: rgba(255, 255, 255, 0.95);
    box-shadow: 
        0 0 0 3px rgba(102, 126, 234, 0.1),
        0 10px 25px rgba(102, 126, 234, 0.15);
    transform: translateY(-3px);
}

.form-control::placeholder {
    color: #9ca3af;
    font-style: italic;
}

.form-group label i {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.password-input-group {
    position: relative;
}

.password-input-group .form-control {
    padding-right: 3rem;
}

.password-toggle {
    position: absolute;
    right: 1rem;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #9ca3af;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 6px;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.password-toggle:hover {
    color: #667eea;
    background: rgba(102, 126, 234, 0.1);
}

.password-toggle i {
    font-size: 1rem;
}

.form-help {
    display: block;
    font-size: 0.85rem;
    color: #6b7280;
    margin-top: 0.5rem;
    font-style: italic;
}

.password-strength {
    margin-top: 0.5rem;
    height: 4px;
    border-radius: 2px;
    background: #e5e7eb;
    transition: all 0.3s ease;
    overflow: hidden;
}

.password-strength.weak {
    background: linear-gradient(to right, #ef4444 30%, #e5e7eb 30%);
}

.password-strength.medium {
    background: linear-gradient(to right, #f59e0b 60%, #e5e7eb 60%);
}

.password-strength.strong {
    background: linear-gradient(to right, #10b981 100%);
}

.checkbox-label {
    display: flex;
    align-items: flex-start;
    gap: 0.7rem;
    cursor: pointer;
    font-size: 0.9rem;
    color: #6b7280;
    font-weight: 500;
    line-height: 1.4;
    margin: 1rem 0;
    width: 100%;
    box-sizing: border-box;
}

.checkbox-label input[type="checkbox"] {
    display: none;
}

.checkbox-custom {
    width: 20px;
    height: 20px;
    border: 2px solid #d1d5db;
    border-radius: 6px;
    position: relative;
    transition: all 0.3s ease;
    background: rgba(255, 255, 255, 0.8);
    flex-shrink: 0;
    margin-top: 2px;
}

.checkbox-label input[type="checkbox"]:checked + .checkbox-custom {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    border-color: #667eea;
    transform: scale(1.1);
}

.checkbox-label input[type="checkbox"]:checked + .checkbox-custom::after {
    content: '\f00c';
    font-family: 'Font Awesome 6 Free';
    font-weight: 900;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: white;
    font-size: 11px;
}

.checkbox-label a {
    color: #667eea;
    text-decoration: none;
    position: relative;
}

.checkbox-label a:hover {
    text-decoration: underline;
}

.btn {
    padding: 1rem 2rem;
    border-radius: 15px;
    font-size: 1rem;
    font-weight: 600;
    text-align: center;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    cursor: pointer;
    transition: all 0.3s ease;
    border: none;
    position: relative;
    overflow: hidden;
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s ease;
}

.btn:hover::before {
    left: 100%;
}

.btn-primary {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
}

.btn-primary:hover {
    transform: translateY(-3px) scale(1.02);
    box-shadow: 0 15px 30px rgba(102, 126, 234, 0.4);
}

.btn-primary:active {
    transform: translateY(-1px) scale(0.98);
    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
}

.btn-outline {
    background: rgba(255, 255, 255, 0.1);
    color: #6b7280;
    border: 2px solid #e5e7eb;
    backdrop-filter: blur(10px);
}

.btn-outline:hover {
    background: rgba(102, 126, 234, 0.1);
    border-color: #667eea;
    color: #667eea;
    transform: translateY(-2px);
}

.w-100 { width: 100%; }
.btn-lg { padding: 1.2rem 2rem; font-size: 1.1rem; }

.auth-divider {
    text-align: center;
    margin: 1.5rem 0;
    position: relative;
    color: #9ca3af;
    font-weight: 500;
}

.auth-divider::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, #e5e7eb, transparent);
    z-index: 1;
}

.auth-divider span {
    background: rgba(255, 255, 255, 0.95);
    padding: 0 1.5rem;
    position: relative;
    z-index: 2;
}

.auth-alternatives {
    margin-bottom: 1.5rem;
}

.auth-alternatives .btn small {
    display: block;
    font-size: 0.8rem;
    opacity: 0.7;
    margin-top: 0.3rem;
}

.auth-footer-section {
    text-align: center;
    color: #6b7280;
    font-size: 1rem;
    margin-top: 1.5rem;
    padding-top: 1rem;
    border-top: 1px solid rgba(229, 231, 235, 0.3);
}

.auth-footer-section p {
    margin: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    flex-wrap: wrap;
}

.auth-link {
    color: #667eea;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.3s ease;
    position: relative;
}

.auth-link::after {
    content: '';
    position: absolute;
    bottom: -2px;
    left: 0;
    width: 0;
    height: 2px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    transition: width 0.3s ease;
}

.auth-link:hover::after {
    width: 100%;
}

.auth-info {
    background: rgba(255, 255, 255, 0.9);
    backdrop-filter: blur(20px);
    border-radius: 15px;
    padding: 1.5rem;
    border: 1px solid rgba(255, 255, 255, 0.3);
    position: relative;
    z-index: 1;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
}

.auth-info h3 {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1.2rem;
    font-weight: 700;
}

.auth-info h3 i {
    color: #667eea;
    font-size: 1.3rem;
}

.info-list {
    list-style: none;
    padding: 0;
}

.info-list li {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 1rem;
    color: #6b7280;
    padding: 0.75rem;
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.5);
    transition: all 0.3s ease;
    font-weight: 500;
    font-size: 0.9rem;
}

.info-list li:hover {
    background: rgba(102, 126, 234, 0.1);
    transform: translateX(10px);
    color: #374151;
}

.info-list li i {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    width: 24px;
    font-size: 1.2rem;
    text-align: center;
}

.community-stats {
    margin-top: 1.5rem;
    padding-top: 1.5rem;
    border-top: 1px solid rgba(255, 255, 255, 0.2);
}

.community-stats h4 {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 1.1rem;
    font-weight: 700;
}

.stats-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.stat-item {
    text-align: center;
    padding: 1rem;
    background: rgba(255, 255, 255, 0.6);
    border-radius: 10px;
    border: 1px solid rgba(255, 255, 255, 0.3);
    transition: all 0.3s ease;
}

.stat-item:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.8);
}

.stat-item strong {
    display: block;
    font-size: 1.5rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.25rem;
    font-weight: 800;
}

.stat-item span {
    font-size: 0.9rem;
    color: #6b7280;
    font-weight: 500;
}

.alert {
    padding: 1rem 1.5rem;
    border-radius: 12px;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.7rem;
    font-weight: 500;
}

.alert-error {
    background: rgba(239, 68, 68, 0.1);
    color: #dc2626;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.alert-success {
    background: rgba(34, 197, 94, 0.1);
    color: #16a34a;
    border: 1px solid rgba(34, 197, 94, 0.2);
}

/* Validação visual dos campos */
.form-control.valid {
    border-color: #10b981;
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
}

.form-control.invalid {
    border-color: #ef4444;
    box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
}

.field-success {
    color: #10b981;
    font-size: 0.875rem;
    margin-top: 0.5rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 500;
}

/* Animações */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes fadeInRight {
    from {
        opacity: 0;
        transform: translateX(30px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.auth-card {
    animation: fadeInUp 0.6s ease-out;
}

.auth-info {
    animation: fadeInRight 0.6s ease-out 0.2s both;
}

/* Responsive */
@media (max-width: 968px) {
    .auth-nav-content {
        padding: 0 1rem;
    }
    
    .auth-nav-links {
        gap: 1rem;
    }
    
    .nav-link {
        font-size: 0.9rem;
        padding: 0.4rem 0.8rem;
    }
    
    .auth-container {
        grid-template-columns: 1fr;
        gap: 2rem;
        padding: 80px 1rem 60px 1rem;
    }
    
    .auth-card {
        padding: 1.5rem;
    }
    
    .auth-info {
        order: -1;
        padding: 1.25rem;
    }
    
    .auth-footer-content {
        padding: 0 1rem;
        flex-direction: column;
        gap: 0.5rem;
        text-align: center;
    }
}

@media (max-width: 640px) {
    .auth-nav-links {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .nav-link {
        font-size: 0.8rem;
    }
    
    .auth-container {
        padding: 90px 0.5rem 70px 0.5rem;
        gap: 2rem;
    }
    
    .auth-card {
        padding: 1.5rem;
        margin: 0 0.5rem;
    }
    
    .auth-title {
        font-size: 1.8rem;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .form-control {
        padding: 0.9rem 1rem;
        font-size: 0.95rem;
    }
    
    .password-input-group .form-control {
        padding-right: 2.5rem;
    }
    
    .checkbox-label {
        font-size: 0.85rem;
        gap: 0.5rem;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .btn {
        padding: 1rem;
        font-size: 0.95rem;
    }
    
    .auth-footer-section p {
        flex-direction: column;
        gap: 0.25rem;
    }
}

@media (max-width: 480px) {
    .auth-logo {
        font-size: 1.2rem;
    }
    
    .auth-nav-content {
        flex-direction: column;
        gap: 1rem;
    }
    
    .auth-container {
        padding: 120px 0.5rem 80px 0.5rem;
    }
    
    .auth-card {
        padding: 1.5rem;
    }
    
    .auth-info {
        padding: 1.5rem;
    }
    
    .info-list li {
        padding: 0.8rem;
        font-size: 0.9rem;
    }
    
    .auth-footer-content {
        font-size: 0.8rem;
    }
}
</style>

<script>
// Variável para controlar o estado das passwords
let passwordsVisible = false;

// Função para mostrar/ocultar todas as passwords
function toggleAllPasswords() {
    const passwordFields = document.querySelectorAll('.password-field');
    const icon = document.getElementById('password-toggle-icon');
    const btnText = document.querySelector('.password-toggle-btn span');
    
    passwordsVisible = !passwordsVisible;
    
    passwordFields.forEach(field => {
        field.type = passwordsVisible ? 'text' : 'password';
    });
    
    if (passwordsVisible) {
        icon.className = 'fas fa-eye-slash';
        btnText.textContent = 'Ocultar Passwords';
    } else {
        icon.className = 'fas fa-eye';
        btnText.textContent = 'Mostrar Passwords';
    }
}

// Verificação da força da password
document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('password');
    const strengthIndicator = document.getElementById('passwordStrength');
    
    if (passwordInput && strengthIndicator) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            
            strengthIndicator.className = 'password-strength ' + strength.class;
            strengthIndicator.title = strength.text;
        });
    }
    
    // Verificar se passwords coincidem
    const confirmInput = document.getElementById('confirm_password');
    if (confirmInput) {
        confirmInput.addEventListener('input', checkPasswordMatch);
        passwordInput.addEventListener('input', checkPasswordMatch);
    }
    
    // Verificar disponibilidade do username
    const usernameInput = document.getElementById('username');
    if (usernameInput) {
        let checkTimeout;
        usernameInput.addEventListener('input', function() {
            clearTimeout(checkTimeout);
            checkTimeout = setTimeout(() => checkUsernameAvailability(this.value), 500);
        });
    }
});

// Calcular força da password
function calculatePasswordStrength(password) {
    let score = 0;
    
    if (password.length >= 6) score += 1;
    if (password.length >= 8) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    if (score < 3) {
        return { class: 'weak', text: 'Fraca' };
    } else if (score < 5) {
        return { class: 'medium', text: 'Média' };
    } else {
        return { class: 'strong', text: 'Forte' };
    }
}

// Verificar se passwords coincidem
function checkPasswordMatch() {
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm_password').value;
    const confirmInput = document.getElementById('confirm_password');
    
    if (confirmPassword && password !== confirmPassword) {
        confirmInput.classList.add('invalid');
        confirmInput.classList.remove('valid');
        showFieldError(confirmInput, 'As passwords não coincidem');
    } else if (confirmPassword && password === confirmPassword) {
        confirmInput.classList.add('valid');
        confirmInput.classList.remove('invalid');
        clearFieldError(confirmInput);
    }
}

// Verificar disponibilidade do username (simulado)
function checkUsernameAvailability(username) {
    const usernameInput = document.getElementById('username');
    
    if (username.length < 3) return;
    
    // Simulação de verificação (em produção, fazer chamada AJAX)
    const unavailableUsernames = ['admin', 'test', 'user', 'skatemap'];
    
    if (unavailableUsernames.includes(username.toLowerCase())) {
        usernameInput.classList.add('invalid');
        usernameInput.classList.remove('valid');
        showFieldError(usernameInput, 'Este nome de utilizador não está disponível');
    } else {
        usernameInput.classList.add('valid');
        usernameInput.classList.remove('invalid');
        clearFieldError(usernameInput);
        showFieldSuccess(usernameInput, 'Nome de utilizador disponível');
    }
}

// Mostrar sucesso no campo
function showFieldSuccess(field, message) {
    clearFieldError(field);
    
    let successDiv = field.parentElement.querySelector('.field-success');
    if (!successDiv) {
        successDiv = document.createElement('div');
        successDiv.className = 'field-success';
        field.parentElement.appendChild(successDiv);
    }
    
    successDiv.innerHTML = `<i class="fas fa-check-circle"></i> ${message}`;
}

// Função para registo com Google (placeholder)
function registerWithGoogle() {
    SkateMap.showAlert('Funcionalidade em desenvolvimento', 'warning');
}

// Mostrar termos e condições
function showTerms() {
    alert('Termos e Condições:\n\n1. Respeite outros utilizadores\n2. Não partilhe conteúdo inadequado\n3. Seja responsável pela informação que partilha\n4. Use o site de forma construtiva\n\n(Esta é uma versão simplificada para demonstração)');
}

// Mostrar política de privacidade
function showPrivacyPolicy() {
    alert('Política de Privacidade:\n\n- Os seus dados são protegidos\n- Não partilhamos informações pessoais\n- Pode eliminar a sua conta a qualquer momento\n- Usamos cookies para melhorar a experiência\n\n(Esta é uma versão simplificada para demonstração)');
}
</script>

<!-- Footer Simplificado -->
<footer class="auth-footer">
    <div class="auth-footer-content">
        <p>&copy; <?php echo date('Y'); ?> SkateMap - Mapa Colaborativo de Skate Spots</p>
        <div class="auth-footer-links">
            <a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Ajuda</a>
            <a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Termos</a>
            <a href="#" onclick="alert('Funcionalidade em desenvolvimento')">Privacidade</a>
        </div>
    </div>
</footer>

</body>
</html>