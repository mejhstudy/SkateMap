-- SkateMap Database Structure
-- PAP - Prova de Aptidão Profissional
-- Criado para o projeto SkateMap - Mapa colaborativo de skate spots em Portugal

CREATE DATABASE IF NOT EXISTS skatemap CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skatemap;

-- Tabela de utilizadores
CREATE TABLE utilizadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email)
);

-- Tabela de spots de skate
CREATE TABLE spots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    endereco VARCHAR(255),
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    foto_principal VARCHAR(255) NOT NULL,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
    INDEX idx_coordenadas (latitude, longitude),
    INDEX idx_usuario (id_usuario)
);

-- Tabela de fotos dos spots
CREATE TABLE fotos_spots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_spot INT NOT NULL,
    caminho_foto VARCHAR(255) NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
    INDEX idx_spot (id_spot)
);

-- Tabela de vídeos dos spots
CREATE TABLE videos_spots (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_spot INT NOT NULL,
    caminho_video VARCHAR(255) NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
    INDEX idx_spot (id_spot)
);

-- Tabela de comentários
CREATE TABLE comentarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_spot INT NOT NULL,
    id_usuario INT NOT NULL,
    texto TEXT NOT NULL,
    data_publicacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
    INDEX idx_spot (id_spot),
    INDEX idx_usuario (id_usuario)
);

-- Tabela de avaliações
CREATE TABLE avaliacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_spot INT NOT NULL,
    id_usuario INT NOT NULL,
    nota INT NOT NULL CHECK (nota >= 1 AND nota <= 5),
    data_avaliacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_spot) REFERENCES spots(id) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES utilizadores(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_spot (id_spot, id_usuario),
    INDEX idx_spot (id_spot),
    INDEX idx_usuario (id_usuario)
);

-- Inserir utilizador administrador padrão
-- Password: admin123 (usar hash apropriado em produção)
INSERT INTO utilizadores (username, email, password, is_admin) VALUES 
('admin', 'admin@skatemap.pt', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', TRUE);

-- Inserir alguns spots de exemplo
INSERT INTO spots (id_usuario, nome, descricao, endereco, latitude, longitude, foto_principal) VALUES 
(1, 'Skate Park do Porto', 'Excelente skate park com várias rampas e obstáculos', 'Porto, Portugal', 41.1579, -8.6291, 'default_spot.jpg'),
(1, 'Praça do Comércio', 'Spot clássico no centro de Lisboa com escadarias', 'Praça do Comércio, Lisboa', 38.7077, -9.1365, 'default_spot.jpg');