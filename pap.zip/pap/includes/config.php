<?php
/**
 * Configuração da Base de Dados - SkateMap
 * PAP - Prova de Aptidão Profissional
 * 
 * Este arquivo contém as configurações de conexão com a base de dados MySQL
 * e funções auxiliares para o projeto SkateMap
 */

// Configurações da base de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'skatemap');
define('DB_USER', 'root'); // Alterar conforme necessário
define('DB_PASS', '');     // Alterar conforme necessário
define('DB_CHARSET', 'utf8mb4');

// Configurações do site
// Ajuste: o projeto está em c:\wamp64\www\pap\skatemap, por isso colocamos /pap/skatemap
define('SITE_URL', 'http://localhost/pap/skatemap'); // Alterar para o seu domínio
define('UPLOAD_PATH', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Chave secreta para sessões (alterar em produção)
define('SECRET_KEY', 'skatemap_secret_key_change_in_production');

// Configuração do Google Maps API
define('GOOGLE_MAPS_API_KEY', 'YOUR_GOOGLE_MAPS_API_KEY'); // Inserir a sua chave da API

/**
 * Função para conectar à base de dados usando PDO
 * @return PDO|null Retorna a conexão PDO ou null em caso de erro
 */
function getConnection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        error_log("Erro de conexão com a base de dados: " . $e->getMessage());
        return null;
    }
}

/**
 * Função para iniciar sessão se não estiver iniciada
 */
function startSession() {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

/**
 * Função para verificar se o utilizador está logado
 * @return bool True se estiver logado, false caso contrário
 */
function isLoggedIn() {
    startSession();
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Função para verificar se o utilizador é administrador
 * @return bool True se for admin, false caso contrário
 */
function isAdmin() {
    startSession();
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == true;
}

/**
 * Função para redirecionar para uma página
 * @param string $url URL para redirecionar
 */
function redirect($url) {
    header("Location: " . $url);
    exit();
}

/**
 * Função para sanitizar dados de entrada
 * @param string $data Dados a serem sanitizados
 * @return string Dados sanitizados
 */
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

/**
 * Função para validar email
 * @param string $email Email a ser validado
 * @return bool True se válido, false caso contrário
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Função para gerar hash seguro da password
 * @param string $password Password em texto
 * @return string Hash da password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Função para verificar password
 * @param string $password Password em texto
 * @param string $hash Hash armazenado
 * @return bool True se corresponder, false caso contrário
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Função para upload de ficheiros
 * @param array $file Array $_FILES
 * @param string $destination Pasta de destino
 * @return string|false Nome do ficheiro ou false em caso de erro
 */
function uploadFile($file, $destination) {
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'video/mp4', 'video/webm'];
    
    if (!in_array($file['type'], $allowedTypes)) {
        return false;
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return false;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = uniqid() . '.' . $extension;
    $filePath = $destination . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $filePath)) {
        return $fileName;
    }
    
    return false;
}

// Definir timezone
date_default_timezone_set('Europe/Lisbon');

// Definir encoding
mb_internal_encoding('UTF-8');
?>