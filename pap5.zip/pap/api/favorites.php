<?php
/**
 * SkateMap - API para Favoritos
 * PAP - Prova de Aptidão Profissional
 */

require_once '../includes/config.php';

header('Content-Type: application/json');

// Verificar se está logado
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Precisa fazer login para usar favoritos']);
    exit;
}

// Verificar método
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

// Obter dados JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['spot_id']) || !is_numeric($input['spot_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID do spot inválido']);
    exit;
}

$spot_id = (int)$input['spot_id'];
$user_id = $_SESSION['user_id'];

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão com a base de dados');
    }
    
    // Verificar se a tabela favoritos existe
    $stmt = $conn->prepare("SHOW TABLES LIKE 'favoritos'");
    $stmt->execute();
    if (!$stmt->fetch()) {
        throw new Exception('Sistema de favoritos não está disponível. Execute a atualização da base de dados.');
    }
    
    // Verificar se o spot existe
    $stmt = $conn->prepare("SELECT id FROM spots WHERE id = ?");
    $stmt->execute([$spot_id]);
    if (!$stmt->fetch()) {
        throw new Exception('Spot não encontrado');
    }
    
    // Verificar se já está nos favoritos
    $stmt = $conn->prepare("SELECT id FROM favoritos WHERE id_usuario = ? AND id_spot = ?");
    $stmt->execute([$user_id, $spot_id]);
    $is_favorite = $stmt->fetch() !== false;
    
    if ($is_favorite) {
        // Remover dos favoritos
        $stmt = $conn->prepare("DELETE FROM favoritos WHERE id_usuario = ? AND id_spot = ?");
        $stmt->execute([$user_id, $spot_id]);
        
        $action = 'removed';
        $message = 'Spot removido dos favoritos';
    } else {
        // Adicionar aos favoritos
        $stmt = $conn->prepare("INSERT INTO favoritos (id_usuario, id_spot) VALUES (?, ?)");
        $stmt->execute([$user_id, $spot_id]);
        
        $action = 'added';
        $message = 'Spot adicionado aos favoritos';
    }
    
    // Obter nova contagem de favoritos do spot
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM favoritos WHERE id_spot = ?");
    $stmt->execute([$spot_id]);
    $total_favorites = $stmt->fetch()['total'];
    
    echo json_encode([
        'success' => true,
        'action' => $action,
        'is_favorite' => !$is_favorite,
        'total_favorites' => (int)$total_favorites,
        'message' => $message
    ]);
    
} catch (Exception $e) {
    error_log("Erro na API de favoritos (linha " . $e->getLine() . "): " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Erro interno do servidor: ' . $e->getMessage()
    ]);
}
?>