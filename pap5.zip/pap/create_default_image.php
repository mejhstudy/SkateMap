<?php
/**
 * Gerador de imagem padrão para spots
 */

// Criar uma imagem padrão simples
$width = 400;
$height = 300;

// Criar imagem
$image = imagecreate($width, $height);

// Definir cores
$background = imagecolorallocate($image, 102, 126, 234); // Cor do tema
$white = imagecolorallocate($image, 255, 255, 255);
$dark = imagecolorallocate($image, 51, 51, 51);

// Preencher fundo
imagefill($image, 0, 0, $background);

// Adicionar texto
$text = "SKATEMAP";
$font_size = 5;
$text_width = imagefontwidth($font_size) * strlen($text);
$text_height = imagefontheight($font_size);
$x = ($width - $text_width) / 2;
$y = ($height - $text_height) / 2 - 20;
imagestring($image, $font_size, $x, $y, $text, $white);

// Adicionar subtítulo
$subtext = "Spot Padrão";
$subfont_size = 3;
$subtext_width = imagefontwidth($subfont_size) * strlen($subtext);
$subx = ($width - $subtext_width) / 2;
$suby = $y + 40;
imagestring($image, $subfont_size, $subx, $suby, $subtext, $white);

// Salvar imagem
$filename = 'uploads/spots/default_spot.jpg';
imagejpeg($image, $filename, 90);
imagedestroy($image);

echo "Imagem padrão criada: $filename";
?>