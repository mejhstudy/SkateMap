# 🔐 **CREDENCIAIS DE ACESSO - SKATEMAP**

## 👨‍💼 **CONTA ADMINISTRADOR**

**Para fazer login como administrador:**
- **Email:** `admin@skatemap.pt`
- **Password:** `admin123`

---

## 🎯 **INSTRUÇÕES DE LOGIN**

1. Acesse: `http://localhost/pap/login.php`
2. Digite o email: `admin@skatemap.pt`
3. Digite a password: `admin123`
4. Clique em "Entrar"

---

## 📝 **CRIAR NOVA CONTA**

1. Acesse: `http://localhost/pap/register.php`
2. Preencha todos os campos:
   - Nome de utilizador (3-50 caracteres)
   - Email válido
   - Password (mínimo 6 caracteres)
   - Confirmar password
   - Aceitar termos e condições
3. Clique em "Criar Conta"

---

## ⚠️ **NOTA IMPORTANTE**

- O sistema de login usa **EMAIL**, não username
- O placeholder no campo email agora mostra: "admin@skatemap.pt (ou seu email)"
- Depois de configurar o sistema, mude a password do admin por segurança

---

## 🚀 **LINKS RÁPIDOS**

- **Site:** http://localhost/pap/
- **Login:** http://localhost/pap/login.php
- **Registar:** http://localhost/pap/register.php
- **Instalar:** http://localhost/pap/install.php
- **Testar BD:** http://localhost/pap/test_db.php