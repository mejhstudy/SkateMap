<?php
/**
 * SkateMap - Página Sobre
 * Informações sobre o projeto e a comunidade
 */

$page_title = 'Sobre o SkateMap';

require_once 'includes/config.php';
require_once 'includes/header.php';

// Buscar estatísticas gerais
try {
    $conn = getConnection();
    $stats = [
        'total_spots' => 0,
        'total_users' => 0,
        'total_avaliacoes' => 0,
        'total_comentarios' => 0
    ];
    
    if ($conn) {
        // Total de spots
        $stmt = $conn->query("SELECT COUNT(*) as total FROM spots");
        $stats['total_spots'] = $stmt->fetch()['total'];
        
        // Total de utilizadores
        $stmt = $conn->query("SELECT COUNT(*) as total FROM utilizadores WHERE is_admin = 0");
        $stats['total_users'] = $stmt->fetch()['total'];
        
        // Total de avaliações
        $stmt = $conn->query("SELECT COUNT(*) as total FROM avaliacoes");
        $stats['total_avaliacoes'] = $stmt->fetch()['total'];
        
        // Total de comentários
        $stmt = $conn->query("SELECT COUNT(*) as total FROM comentarios");
        $stats['total_comentarios'] = $stmt->fetch()['total'];
    }
} catch (Exception $e) {
    error_log("Erro ao buscar estatísticas: " . $e->getMessage());
}
?>

<div class="container">
    <!-- Hero Section -->
    <section class="about-hero">
        <div class="hero-content">
            <h1><i class="fas fa-skateboard"></i> SkateMap</h1>
            <p class="hero-subtitle">O mapa colaborativo definitivo para a comunidade de skate portuguesa</p>
        </div>
    </section>

    <!-- Sobre o Projeto -->
    <section class="about-section">
        <div class="section-content">
            <h2><i class="fas fa-info-circle"></i> Sobre o Projeto</h2>
            <p>
                O <strong>SkateMap</strong> nasceu da paixão pela cultura do skate e da necessidade de conectar 
                a comunidade portuguesa de skateboard. Este projeto foi desenvolvido como Prova de Aptidão 
                Profissional (PAP), com o objetivo de criar uma plataforma onde skaters de todo o país 
                possam descobrir, partilhar e avaliar spots de skate.
            </p>
            
            <p>
                A nossa missão é simples: <em>democratizar o acesso à informação sobre spots de skate</em> 
                e fortalecer a comunidade através da partilha de conhecimento e experiências.
            </p>
        </div>
    </section>

    <!-- Estatísticas -->
    <section class="stats-section">
        <h2><i class="fas fa-chart-bar"></i> Estatísticas da Comunidade</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-map-marker-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_spots']; ?></h3>
                    <p>Spots Mapeados</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_users']; ?></h3>
                    <p>Skaters Registados</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_avaliacoes']; ?></h3>
                    <p>Avaliações Feitas</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_comentarios']; ?></h3>
                    <p>Comentários Partilhados</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Funcionalidades -->
    <section class="features-section">
        <h2><i class="fas fa-rocket"></i> Funcionalidades</h2>
        <div class="features-grid">
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-map"></i>
                </div>
                <div class="feature-content">
                    <h3>Mapa Interativo</h3>
                    <p>Explore spots de skate em todo Portugal através do nosso mapa interativo baseado no Google Maps.</p>
                </div>
            </div>
            
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-plus-circle"></i>
                </div>
                <div class="feature-content">
                    <h3>Adicionar Spots</h3>
                    <p>Contribua para a comunidade adicionando novos spots que descobriu nas suas sessões.</p>
                </div>
            </div>
            
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="feature-content">
                    <h3>Sistema de Avaliações</h3>
                    <p>Avalie spots e veja as opiniões de outros skaters para escolher os melhores locais.</p>
                </div>
            </div>
            
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-camera"></i>
                </div>
                <div class="feature-content">
                    <h3>Partilha de Mídia</h3>
                    <p>Partilhe fotos e vídeos dos seus truques e experiências nos diferentes spots.</p>
                </div>
            </div>
            
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="feature-content">
                    <h3>Comunidade Ativa</h3>
                    <p>Conecte-se com outros skaters através de comentários e partilha de experiências.</p>
                </div>
            </div>
            
            <div class="feature-item">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <div class="feature-content">
                    <h3>Responsivo</h3>
                    <p>Acesse o SkateMap em qualquer dispositivo, onde quer que esteja a andar de skate.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Tecnologias -->
    <section class="tech-section">
        <h2><i class="fas fa-code"></i> Tecnologias Utilizadas</h2>
        <div class="tech-grid">
            <div class="tech-item">
                <i class="fab fa-php"></i>
                <h4>PHP</h4>
                <p>Backend e lógica do servidor</p>
            </div>
            
            <div class="tech-item">
                <i class="fas fa-database"></i>
                <h4>MySQL</h4>
                <p>Base de dados relacional</p>
            </div>
            
            <div class="tech-item">
                <i class="fab fa-js-square"></i>
                <h4>JavaScript</h4>
                <p>Interatividade e funcionalidades dinâmicas</p>
            </div>
            
            <div class="tech-item">
                <i class="fab fa-css3-alt"></i>
                <h4>CSS3</h4>
                <p>Design responsivo e moderno</p>
            </div>
            
            <div class="tech-item">
                <i class="fas fa-map-marked-alt"></i>
                <h4>Google Maps API</h4>
                <p>Integração com mapas interativos</p>
            </div>
            
            <div class="tech-item">
                <i class="fab fa-font-awesome"></i>
                <h4>Font Awesome</h4>
                <p>Ícones e elementos visuais</p>
            </div>
        </div>
    </section>

    <!-- Call to Action -->
    <section class="cta-section">
        <div class="cta-content">
            <h2>Junte-se à Nossa Comunidade</h2>
            <p>Faça parte da maior comunidade de skate de Portugal. Descubra novos spots, partilhe os seus favoritos e conecte-se com outros skaters.</p>
            
            <?php if (!isLoggedIn()): ?>
                <div class="cta-buttons">
                    <a href="register.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-user-plus"></i> Registar Agora
                    </a>
                    <a href="login.php" class="btn btn-outline btn-lg">
                        <i class="fas fa-sign-in-alt"></i> Já Tenho Conta
                    </a>
                </div>
            <?php else: ?>
                <div class="cta-buttons">
                    <a href="add_spot.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus"></i> Adicionar Spot
                    </a>
                    <a href="spots.php" class="btn btn-outline btn-lg">
                        <i class="fas fa-map-marker-alt"></i> Explorar Spots
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>

<style>
.about-hero {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
    color: white;
    padding: 4rem 0;
    margin: -80px -20px 3rem -20px;
    padding-top: 6rem;
    text-align: center;
}

.hero-content h1 {
    font-size: 3.5rem;
    font-weight: bold;
    margin-bottom: 1rem;
}

.hero-subtitle {
    font-size: 1.3rem;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
}

.about-section,
.stats-section,
.features-section,
.tech-section {
    margin-bottom: 4rem;
}

.about-section h2,
.stats-section h2,
.features-section h2,
.tech-section h2 {
    font-size: 2.5rem;
    margin-bottom: 2rem;
    color: var(--text-primary);
    text-align: center;
}

.section-content {
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
}

.section-content p {
    font-size: 1.1rem;
    line-height: 1.8;
    color: var(--text-secondary);
    margin-bottom: 1.5rem;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
}

.stat-card {
    background: var(--surface-color);
    padding: 2rem;
    border-radius: 15px;
    border: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    transition: transform 0.3s ease;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-icon {
    width: 60px;
    height: 60px;
    background: var(--primary-color);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.8rem;
}

.stat-info h3 {
    font-size: 2.5rem;
    font-weight: bold;
    color: var(--text-primary);
    margin: 0;
}

.stat-info p {
    color: var(--text-secondary);
    margin: 0;
    font-size: 1rem;
}

.features-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
}

.feature-item {
    display: flex;
    gap: 1rem;
    padding: 1.5rem;
    background: var(--surface-color);
    border-radius: 15px;
    border: 1px solid var(--border-color);
    box-shadow: 0 2px 10px var(--shadow-color);
}

.feature-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-color);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
    flex-shrink: 0;
}

.feature-content h3 {
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.feature-content p {
    color: var(--text-secondary);
    line-height: 1.6;
    margin: 0;
}

.tech-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 1.5rem;
}

.tech-item {
    text-align: center;
    padding: 1.5rem;
    background: var(--surface-color);
    border-radius: 15px;
    border: 1px solid var(--border-color);
    box-shadow: 0 2px 10px var(--shadow-color);
    transition: transform 0.3s ease;
}

.tech-item:hover {
    transform: translateY(-5px);
}

.tech-item i {
    font-size: 3rem;
    color: var(--primary-color);
    margin-bottom: 1rem;
}

.tech-item h4 {
    font-size: 1.1rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.tech-item p {
    color: var(--text-secondary);
    font-size: 0.9rem;
    margin: 0;
}

.cta-section {
    background: linear-gradient(135deg, var(--secondary-color), var(--primary-color));
    color: white;
    padding: 4rem 2rem;
    border-radius: 20px;
    text-align: center;
    margin: 4rem 0;
}

.cta-content h2 {
    font-size: 2.5rem;
    margin-bottom: 1rem;
}

.cta-content p {
    font-size: 1.2rem;
    margin-bottom: 2rem;
    opacity: 0.9;
}

.cta-buttons {
    display: flex;
    justify-content: center;
    gap: 1rem;
    flex-wrap: wrap;
}

@media (max-width: 768px) {
    .hero-content h1 {
        font-size: 2.5rem;
    }
    
    .about-section h2,
    .stats-section h2,
    .features-section h2,
    .tech-section h2 {
        font-size: 2rem;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .features-grid {
        grid-template-columns: 1fr;
    }
    
    .tech-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .feature-item {
        flex-direction: column;
        text-align: center;
    }
    
    .cta-buttons {
        flex-direction: column;
        align-items: center;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>