<?php
/**
 * Header principal do SkateMap
 * Inclui navegação, sistema de temas e meta tags
 */

require_once 'config.php';
startSession();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - SkateMap' : 'SkateMap - Mapa Colaborativo de Skate Spots'; ?></title>
    
    <!-- Meta tags para SEO -->
    <meta name="description" content="SkateMap - O mapa colaborativo de skate spots em Portugal. Descobre, adiciona e avalia os melhores spots de skate do país.">
    <meta name="keywords" content="skate, skateboard, spots, portugal, mapa, colaborativo">
    <meta name="author" content="SkateMap">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo SITE_URL; ?>/assets/favicon.ico">
    
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>/assets/css/style.css">
    
    <!-- Google Maps API -->
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo GOOGLE_MAPS_API_KEY; ?>&libraries=places&callback=initMap"></script>
    
    <!-- Font Awesome para ícones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="<?php echo isset($_COOKIE['theme']) ? $_COOKIE['theme'] : 'light-theme'; ?>">
    
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <!-- Logo -->
                <div class="logo">
                    <a href="<?php echo SITE_URL; ?>">
                        <i class="fas fa-map-marked-alt"></i>
                        <span>SkateMap</span>
                    </a>
                </div>
                
                <!-- Navegação -->
                <nav class="nav">
                    <ul class="nav-links">
                        <li><a href="<?php echo SITE_URL; ?>"><i class="fas fa-home"></i> Início</a></li>
                        
                        <li class="spots-menu">
                            <a href="#" class="spots-toggle">
                                <i class="fas fa-map-marker-alt"></i> 
                                Spots
                                <i class="fas fa-chevron-down"></i>
                            </a>
                            <ul class="dropdown">
                                <li><a href="<?php echo SITE_URL; ?>/spots.php"><i class="fas fa-map-marker-alt"></i> Spots</a></li>
                                <?php if (isLoggedIn()): ?>
                                    <li><a href="<?php echo SITE_URL; ?>/add_spot.php"><i class="fas fa-plus"></i> Adicionar</a></li>
                                    <li><a href="<?php echo SITE_URL; ?>/meus-spots.php"><i class="fas fa-star"></i> Meus Spots</a></li>
                                <?php else: ?>
                                    <li><a href="<?php echo SITE_URL; ?>/login.php"><i class="fas fa-sign-in-alt"></i> Entrar para Adicionar</a></li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        
                        <?php if (isLoggedIn()): ?>
                            <!-- <li><a href="<?php echo SITE_URL; ?>/sobre.php"><i class="fas fa-info-circle"></i> Sobre</a></li> -->
                            
                            <?php if (isAdmin()): ?>
                                <li><a href="<?php echo SITE_URL; ?>/admin/"><i class="fas fa-cog"></i> Admin</a></li>
                            <?php endif; ?>
                            
                            <li class="user-menu">
                                <a href="#" class="user-toggle">
                                    <i class="fas fa-user"></i> 
                                    <?php echo sanitize($_SESSION['username']); ?>
                                    <i class="fas fa-chevron-down"></i>
                                </a>
                                <ul class="dropdown">
                                    <li><a href="<?php echo SITE_URL; ?>/perfil.php"><i class="fas fa-user-edit"></i> Perfil</a></li>
                                    <li><a href="<?php echo SITE_URL; ?>/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li><a href="<?php echo SITE_URL; ?>/login.php"><i class="fas fa-sign-in-alt"></i> Entrar</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/register.php"><i class="fas fa-user-plus"></i> Registar</a></li>
                        <?php endif; ?>
                    </ul>
                    
                    <!-- Botão de tema -->
                    <!-- <button class="theme-toggle" id="themeToggle" title="Alternar tema">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button> -->
                    
                    <!-- Menu móvel -->
                    <button class="mobile-menu-toggle" id="mobileMenuToggle">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </nav>
            </div>
        </div>
    </header>
    
    <!-- Mobile Menu Overlay -->
    <div class="mobile-menu-overlay" id="mobileMenuOverlay">
        <div class="mobile-menu">
            <ul class="mobile-nav-links">
                <li><a href="<?php echo SITE_URL; ?>"><i class="fas fa-home"></i> Início</a></li>
                <li><a href="<?php echo SITE_URL; ?>/spots.php"><i class="fas fa-map-marker-alt"></i> Spots</a></li>
                
                <?php if (isLoggedIn()): ?>
                    <li><a href="<?php echo SITE_URL; ?>/add_spot.php"><i class="fas fa-plus"></i> Adicionar</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/spots.php"><i class="fas fa-map-marker-alt"></i> Spots</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/meus-spots.php"><i class="fas fa-star"></i> Meus Spots</a></li>
                    <!-- <li><a href="<?php echo SITE_URL; ?>/sobre.php"><i class="fas fa-info-circle"></i> Sobre</a></li> -->
                    
                    <?php if (isAdmin()): ?>
                        <li><a href="<?php echo SITE_URL; ?>/admin/"><i class="fas fa-cog"></i> Admin</a></li>
                    <?php endif; ?>
                    
                    <li><a href="<?php echo SITE_URL; ?>/perfil.php"><i class="fas fa-user-edit"></i> Perfil</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
                <?php else: ?>
                    <!-- <li><a href="<?php echo SITE_URL; ?>/spots.php"><i class="fas fa-map-marker-alt"></i> Spots</a></li> -->
                    <!-- <li><a href="<?php echo SITE_URL; ?>/sobre.php"><i class="fas fa-info-circle"></i> Sobre</a></li> -->
                    <li><a href="<?php echo SITE_URL; ?>/login.php"><i class="fas fa-sign-in-alt"></i> Entrar</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/register.php"><i class="fas fa-user-plus"></i> Registar</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    
    <!-- Main Content Start -->
    <main class="main-content">
        
        <?php
        // Mostrar mensagens de sessão (sucesso/erro)
        if (isset($_SESSION['success_message'])):
        ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <?php 
                echo $_SESSION['success_message']; 
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>
        
        <?php
        if (isset($_SESSION['error_message'])):
        ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i>
                <?php 
                echo $_SESSION['error_message']; 
                unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>