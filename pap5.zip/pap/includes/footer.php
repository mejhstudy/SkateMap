    </main>
    <!-- Main Content End -->
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <div class="footer-logo">
                        <i class="fas fa-map-marked-alt"></i>
                        <span>SkateMap</span>
                    </div>
                    <p class="footer-description">
                        O mapa colaborativo de skate spots em Portugal. 
                        Descobre, adiciona e avalia os melhores spots de skate do país.
                    </p>
                </div>
                
                <div class="footer-section">
                    <h3>Links Rápidos</h3>
                    <ul class="footer-links">
                        <li><a href="<?php echo SITE_URL; ?>"><i class="fas fa-home"></i> Início</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/add_spot.php"><i class="fas fa-plus"></i> Adicionar Spot</a></li>
                        <?php if (isLoggedIn()): ?>
                            <li><a href="<?php echo SITE_URL; ?>/perfil.php"><i class="fas fa-user"></i> Perfil</a></li>
                        <?php else: ?>
                            <li><a href="<?php echo SITE_URL; ?>/login.php"><i class="fas fa-sign-in-alt"></i> Entrar</a></li>
                            <li><a href="<?php echo SITE_URL; ?>/register.php"><i class="fas fa-user-plus"></i> Registar</a></li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Informações</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fas fa-question-circle"></i> Sobre</a></li>
                        <li><a href="#"><i class="fas fa-envelope"></i> Contacto</a></li>
                        <li><a href="#"><i class="fas fa-shield-alt"></i> Privacidade</a></li>
                        <li><a href="#"><i class="fas fa-file-alt"></i> Termos</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Redes Sociais</h3>
                    <div class="social-links">
                        <a href="#" title="Facebook"><i class="fab fa-facebook"></i></a>
                        <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
                        <a href="#" title="Twitter"><i class="fab fa-twitter"></i></a>
                        <a href="#" title="YouTube"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="footer-copyright">
                    <p>&copy; <?php echo date('Y'); ?> SkateMap. Todos os direitos reservados.</p>
                    <p class="footer-credits">
                        Desenvolvido como Prova de Aptidão Profissional
                    </p>
                </div>
                
                <div class="footer-theme-toggle">
                    <button class="theme-toggle-footer" onclick="toggleTheme()" title="Alternar tema">
                        <i class="fas fa-adjust"></i>
                    </button>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript -->
    <script src="<?php echo SITE_URL; ?>/assets/js/main.js"></script>
    
    <!-- JavaScript específico para páginas com mapas -->
    <?php if (isset($include_maps_js) && $include_maps_js): ?>
        <script src="<?php echo SITE_URL; ?>/assets/js/maps.js"></script>
    <?php endif; ?>
    
    <script>
        // Inicializar tema
        document.addEventListener('DOMContentLoaded', function() {
            initializeTheme();
            initializeMobileMenu();
            initializeAlerts();
        });
        
        // Função para inicializar tema
        function initializeTheme() {
            const themeToggle = document.getElementById('themeToggle');
            const themeIcon = document.getElementById('themeIcon');
            const currentTheme = localStorage.getItem('theme') || 'light';
            
            document.body.className = currentTheme + '-theme';
            
            if (currentTheme === 'dark') {
                themeIcon.className = 'fas fa-sun';
            } else {
                themeIcon.className = 'fas fa-moon';
            }
            
            if (themeToggle) {
                themeToggle.addEventListener('click', toggleTheme);
            }
        }
        
        // Função para alternar tema
        function toggleTheme() {
            const body = document.body;
            const themeIcon = document.getElementById('themeIcon');
            let currentTheme = body.classList.contains('dark-theme') ? 'dark' : 'light';
            let newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            
            body.className = newTheme + '-theme';
            localStorage.setItem('theme', newTheme);
            
            // Atualizar ícone
            if (themeIcon) {
                themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
            }
            
            // Definir cookie para o PHP
            document.cookie = `theme=${newTheme}; path=/; max-age=31536000`; // 1 ano
        }
        
        // Função para inicializar menu móvel
        function initializeMobileMenu() {
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const mobileMenuOverlay = document.getElementById('mobileMenuOverlay');
            
            if (mobileMenuToggle && mobileMenuOverlay) {
                mobileMenuToggle.addEventListener('click', function() {
                    mobileMenuOverlay.classList.toggle('active');
                    document.body.classList.toggle('menu-open');
                });
                
                mobileMenuOverlay.addEventListener('click', function(e) {
                    if (e.target === mobileMenuOverlay) {
                        mobileMenuOverlay.classList.remove('active');
                        document.body.classList.remove('menu-open');
                    }
                });
            }
        }
        
        // Função para inicializar alertas
        function initializeAlerts() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                // Auto-fechar alertas após 5 segundos
                setTimeout(() => {
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        alert.remove();
                    }, 300);
                }, 5000);
                
                // Adicionar botão de fechar
                const closeBtn = document.createElement('button');
                closeBtn.innerHTML = '<i class="fas fa-times"></i>';
                closeBtn.className = 'alert-close';
                closeBtn.onclick = function() {
                    alert.style.opacity = '0';
                    setTimeout(() => {
                        alert.remove();
                    }, 300);
                };
                alert.appendChild(closeBtn);
            });
        }
        
        // Menu dropdown do utilizador
        document.addEventListener('DOMContentLoaded', function() {
            const userToggle = document.querySelector('.user-toggle');
            const dropdown = document.querySelector('.user-menu .dropdown');
            
            if (userToggle && dropdown) {
                userToggle.addEventListener('click', function(e) {
                    e.preventDefault();
                    dropdown.classList.toggle('active');
                });
                
                // Fechar dropdown ao clicar fora
                document.addEventListener('click', function(e) {
                    if (!userToggle.contains(e.target) && !dropdown.contains(e.target)) {
                        dropdown.classList.remove('active');
                    }
                });
            }
        });
    </script>
</body>
</html>