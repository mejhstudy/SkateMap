<?php
/**
 * Script de teste para verificar o estado da base de dados
 */

require_once 'includes/config.php';

echo "<h2>Teste da Base de Dados - SkateMap</h2>";

try {
    $conn = getConnection();
    if (!$conn) {
        throw new Exception('Erro de conexão');
    }
    
    echo "<p>✅ Conexão com a base de dados: OK</p>";
    
    // Verificar tabelas existentes
    $stmt = $conn->query("SHOW TABLES");
    $tables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo "<h3>Tabelas existentes:</h3><ul>";
    foreach ($tables as $table) {
        echo "<li>$table</li>";
    }
    echo "</ul>";
    
    // Verificar se tabela favoritos existe
    if (in_array('favoritos', $tables)) {
        echo "<p>✅ Tabela 'favoritos' existe</p>";
        
        // Contar registos
        $stmt = $conn->query("SELECT COUNT(*) as total FROM favoritos");
        $total = $stmt->fetch()['total'];
        echo "<p>Total de favoritos: $total</p>";
    } else {
        echo "<p>❌ Tabela 'favoritos' NÃO existe</p>";
        echo "<p><a href='update_database.php'>Clique aqui para atualizar a base de dados</a></p>";
    }
    
    // Testar utilizador
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("SELECT username FROM utilizadores WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();
        
        if ($user) {
            echo "<p>✅ Utilizador logado: " . $user['username'] . " (ID: $user_id)</p>";
        } else {
            echo "<p>❌ Utilizador logado não encontrado na base de dados</p>";
        }
    } else {
        echo "<p>ℹ️ Nenhum utilizador logado</p>";
    }
    
} catch (Exception $e) {
    echo "<p>❌ Erro: " . $e->getMessage() . "</p>";
}

echo "<p><a href='perfil.php'>Voltar ao Perfil</a> | <a href='index.php'>Voltar ao Início</a></p>";
?>