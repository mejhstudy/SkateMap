<?php
/**
 * SkateMap - Meus Spots
 * Página que mostra os spots adicionados pelo utilizador logado
 */

$page_title = 'Meus Spots';

require_once 'includes/config.php';

// Verificar se o utilizador está logado
if (!isLoggedIn()) {
    $_SESSION['error_message'] = 'Precisa de estar logado para ver os seus spots.';
    header('Location: login.php');
    exit();
}

require_once 'includes/header.php';

// Buscar spots do utilizador atual
try {
    $conn = getConnection();
    $mySpots = [];
    
    if ($conn) {
        $stmt = $conn->prepare("
            SELECT s.*, 
                   AVG(a.nota) as rating_medio,
                   COUNT(a.id) as total_avaliacoes,
                   COUNT(c.id) as total_comentarios
            FROM spots s
            LEFT JOIN avaliacoes a ON s.id = a.id_spot
            LEFT JOIN comentarios c ON s.id = c.id_spot
            WHERE s.id_usuario = ?
            GROUP BY s.id
            ORDER BY s.data_criacao DESC
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $mySpots = $stmt->fetchAll();
    }
} catch (Exception $e) {
    error_log("Erro ao buscar spots do utilizador: " . $e->getMessage());
    $mySpots = [];
}
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-star"></i> Meus Spots</h1>
        <p>Spots que adicionei ao SkateMap</p>
    </div>

    <div class="user-stats">
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo count($mySpots); ?></h3>
                <p>Spots Adicionados</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-info">
                <?php 
                $totalRatings = 0;
                $avgRating = 0;
                foreach ($mySpots as $spot) {
                    $totalRatings += $spot['total_avaliacoes'];
                    if ($spot['rating_medio']) {
                        $avgRating += $spot['rating_medio'] * $spot['total_avaliacoes'];
                    }
                }
                $overallRating = $totalRatings > 0 ? round($avgRating / $totalRatings, 1) : 0;
                ?>
                <h3><?php echo $overallRating; ?></h3>
                <p>Classificação Média</p>
            </div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon">
                <i class="fas fa-comments"></i>
            </div>
            <div class="stat-info">
                <?php 
                $totalComments = 0;
                foreach ($mySpots as $spot) {
                    $totalComments += $spot['total_comentarios'];
                }
                ?>
                <h3><?php echo $totalComments; ?></h3>
                <p>Comentários Recebidos</p>
            </div>
        </div>
    </div>

    <div class="actions-bar">
        <a href="add_spot.php" class="btn btn-primary">
            <i class="fas fa-plus"></i> Adicionar Novo Spot
        </a>
    </div>

    <?php if (empty($mySpots)): ?>
        <div class="empty-state">
            <i class="fas fa-map-marker-alt"></i>
            <h3>Ainda não adicionou nenhum spot</h3>
            <p>Comece a partilhar os seus spots favoritos com a comunidade!</p>
            <a href="add_spot.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Adicionar Primeiro Spot
            </a>
        </div>
    <?php else: ?>
        <div class="spots-grid">
            <?php foreach ($mySpots as $spot): ?>
                <div class="spot-card my-spot-card">
                    <div class="spot-image-container">
                        <?php 
                        $imagePath = !empty($spot['foto_principal']) ? 
                            "uploads/spots/" . $spot['foto_principal'] : 
                            "assets/images/default-spot.svg";
                        ?>
                        <img 
                            src="<?php echo $imagePath; ?>" 
                            alt="<?php echo sanitize($spot['nome']); ?>"
                            class="spot-image"
                            onerror="this.src='assets/images/default-spot.svg'"
                            loading="lazy"
                        >
                        
                        <div class="spot-owner-badge">
                            <i class="fas fa-crown"></i>
                            Meu Spot
                        </div>
                    </div>
                    
                    <div class="spot-content">
                        <h3 class="spot-title">
                            <?php echo sanitize($spot['nome']); ?>
                        </h3>
                        
                        <p class="spot-description">
                            <?php 
                            $description = sanitize($spot['descricao']);
                            echo strlen($description) > 120 ? 
                                substr($description, 0, 120) . '...' : 
                                $description;
                            ?>
                        </p>
                        
                        <div class="spot-stats">
                            <div class="spot-stat">
                                <i class="fas fa-star"></i>
                                <span><?php echo $spot['rating_medio'] ? round($spot['rating_medio'], 1) : 'N/A'; ?></span>
                                <small>(<?php echo $spot['total_avaliacoes']; ?>)</small>
                            </div>
                            <div class="spot-stat">
                                <i class="fas fa-comments"></i>
                                <span><?php echo $spot['total_comentarios']; ?></span>
                                <small>comentários</small>
                            </div>
                            <div class="spot-stat">
                                <i class="fas fa-calendar"></i>
                                <span><?php echo date('d/m/Y', strtotime($spot['data_criacao'])); ?></span>
                            </div>
                        </div>
                        
                        <div class="spot-location">
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo sanitize($spot['endereco']); ?>
                        </div>
                        
                        <div class="spot-actions">
                            <a 
                                href="spot_detalhes.php?id=<?php echo $spot['id']; ?>" 
                                class="btn btn-primary btn-sm"
                            >
                                <i class="fas fa-eye"></i>
                                Ver Detalhes
                            </a>
                            
                            <a 
                                href="edit_spot.php?id=<?php echo $spot['id']; ?>" 
                                class="btn btn-secondary btn-sm"
                                title="Editar spot"
                            >
                                <i class="fas fa-edit"></i>
                                Editar
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
.page-header {
    text-align: center;
    margin-bottom: 3rem;
    padding: 2rem 0;
}

.page-header h1 {
    font-size: 2.5rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.page-header p {
    font-size: 1.1rem;
    color: var(--text-secondary);
}

.user-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: var(--surface-color);
    padding: 1.5rem;
    border-radius: 15px;
    border: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 2px 10px var(--shadow-color);
}

.stat-icon {
    width: 50px;
    height: 50px;
    background: var(--primary-color);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
}

.stat-info h3 {
    font-size: 2rem;
    font-weight: bold;
    color: var(--text-primary);
    margin: 0;
}

.stat-info p {
    color: var(--text-secondary);
    margin: 0;
    font-size: 0.9rem;
}

.actions-bar {
    margin-bottom: 2rem;
    text-align: center;
}

.empty-state {
    text-align: center;
    padding: 4rem 2rem;
    color: var(--text-secondary);
}

.empty-state i {
    font-size: 4rem;
    margin-bottom: 1rem;
    opacity: 0.5;
}

.empty-state h3 {
    font-size: 1.5rem;
    margin-bottom: 1rem;
    color: var(--text-primary);
}

.spots-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 2rem;
    margin: 2rem 0;
}

.my-spot-card {
    position: relative;
}

.spot-owner-badge {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background: linear-gradient(135deg, #ffd700, #ffed4a);
    color: #8b4513;
    padding: 0.4rem 0.8rem;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: bold;
    box-shadow: 0 2px 8px rgba(255, 215, 0, 0.3);
    z-index: 2;
}

.spot-stats {
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
    padding: 0.75rem;
    background: rgba(0, 0, 0, 0.05);
    border-radius: 8px;
    font-size: 0.9rem;
}

.spot-stat {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.25rem;
}

.spot-stat i {
    color: var(--primary-color);
}

.spot-stat span {
    font-weight: bold;
    color: var(--text-primary);
}

.spot-stat small {
    color: var(--text-secondary);
    font-size: 0.8rem;
}

@media (max-width: 768px) {
    .page-header h1 {
        font-size: 2rem;
    }
    
    .user-stats {
        grid-template-columns: 1fr;
    }
    
    .spots-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .spot-stats {
        font-size: 0.8rem;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>