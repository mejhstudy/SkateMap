<?php
/**
 * SkateMap - Página de Spots
 * Lista todos os spots de skate disponíveis
 */

$page_title = 'Spots de Skate';
$include_maps_js = true;

require_once 'includes/config.php';
require_once 'includes/header.php';

// Buscar todos os spots
try {
    $conn = getConnection();
    $spots = [];
    
    if ($conn) {
        $stmt = $conn->query("
            SELECT s.*, u.username,
                   AVG(a.nota) as rating_medio,
                   COUNT(a.id) as total_avaliacoes
            FROM spots s
            LEFT JOIN utilizadores u ON s.id_usuario = u.id
            LEFT JOIN avaliacoes a ON s.id = a.id_spot
            GROUP BY s.id
            ORDER BY s.data_criacao DESC
        ");
        $spots = $stmt->fetchAll();
    }
} catch (Exception $e) {
    error_log("Erro ao buscar spots: " . $e->getMessage());
    $spots = [];
}
?>

<div class="container">
    <div class="page-header">
        <h1><i class="fas fa-map-marker-alt"></i> Spots de Skate</h1>
        <p>Descobre todos os spots de skate adicionados pela nossa comunidade</p>
    </div>

    <?php if (isLoggedIn()): ?>
        <div class="text-center mb-4">
            <a href="add_spot.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Adicionar Novo Spot
            </a>
        </div>
    <?php endif; ?>

    <?php if (empty($spots)): ?>
        <div class="text-center">
            <h3>Nenhum spot encontrado</h3>
            <p>Seja o primeiro a adicionar um spot!</p>
            <?php if (isLoggedIn()): ?>
                <a href="add_spot.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Adicionar Spot
                </a>
            <?php else: ?>
                <a href="register.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Registar para Adicionar
                </a>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="spots-grid">
            <?php foreach ($spots as $spot): ?>
                <div class="spot-card">
                    <div class="spot-image-container">
                        <?php 
                        $imagePath = !empty($spot['foto_principal']) ? 
                            "uploads/spots/" . $spot['foto_principal'] : 
                            "assets/images/default-spot.svg";
                        ?>
                        <img 
                            src="<?php echo $imagePath; ?>" 
                            alt="<?php echo sanitize($spot['nome']); ?>"
                            class="spot-image"
                            onerror="this.src='assets/images/default-spot.svg'"
                            loading="lazy"
                        >
                    </div>
                    
                    <div class="spot-content">
                        <h3 class="spot-title">
                            <?php echo sanitize($spot['nome']); ?>
                        </h3>
                        
                        <p class="spot-description">
                            <?php 
                            $description = sanitize($spot['descricao']);
                            echo strlen($description) > 120 ? 
                                substr($description, 0, 120) . '...' : 
                                $description;
                            ?>
                        </p>
                        
                        <div class="spot-meta">
                            <div class="spot-rating">
                                <?php 
                                $rating = $spot['rating_medio'] ?: 0;
                                $totalRatings = $spot['total_avaliacoes'] ?: 0;
                                ?>
                                <div class="stars">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php if ($i <= floor($rating)): ?>
                                            <i class="fas fa-star"></i>
                                        <?php elseif ($i == floor($rating) + 1 && $rating - floor($rating) >= 0.5): ?>
                                            <i class="fas fa-star-half-alt"></i>
                                        <?php else: ?>
                                            <i class="far fa-star"></i>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                </div>
                                <span class="rating-text">
                                    (<?php echo $totalRatings; ?>)
                                </span>
                            </div>
                            
                            <div class="spot-author">
                                <i class="fas fa-user"></i>
                                <?php echo sanitize($spot['username']); ?>
                            </div>
                        </div>
                        
                        <div class="spot-location">
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo sanitize($spot['endereco']); ?>
                        </div>
                        
                        <div class="spot-actions">
                            <a 
                                href="spot_detalhes.php?id=<?php echo $spot['id']; ?>" 
                                class="btn btn-primary btn-sm"
                            >
                                <i class="fas fa-eye"></i>
                                Ver Detalhes
                            </a>
                            
                            <button 
                                class="btn btn-outline btn-sm" 
                                onclick="focusSpot(<?php echo $spot['id']; ?>)"
                                title="Ver no mapa"
                            >
                                <i class="fas fa-map-pin"></i>
                                Mapa
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
.page-header {
    text-align: center;
    margin-bottom: 3rem;
    padding: 2rem 0;
}

.page-header h1 {
    font-size: 2.5rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.page-header p {
    font-size: 1.1rem;
    color: var(--text-secondary);
}

.spots-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 2rem;
    margin: 2rem 0;
}

@media (max-width: 768px) {
    .page-header h1 {
        font-size: 2rem;
    }
    
    .spots-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
}
</style>

<?php require_once 'includes/footer.php'; ?>