<?php
/**
 * SkateMap - Adicionar Novo Spot
 * PAP - Prova de Aptidão Profissional
 */

// Configurações da página
$page_title = 'Adicionar Spot';
$load_maps_js = true;

require_once 'includes/config.php';

// Verificar se está logado
if (!isLoggedIn()) {
    $_SESSION['error_message'] = 'Precisa de fazer login para adicionar spots.';
    redirect(SITE_URL . '/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
}

// Variáveis de controle
$error_message = '';
$success_message = '';
$form_data = [];

// Processar formulário (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capturar e sanitizar dados
    $nome = sanitize($_POST['nome'] ?? '');
    $descricao = sanitize($_POST['descricao'] ?? '');
    $endereco = sanitize($_POST['endereco'] ?? '');
    $latitude = floatval($_POST['latitude'] ?? 0);
    $longitude = floatval($_POST['longitude'] ?? 0);
    $avaliacao_inicial = intval($_POST['avaliacao_inicial'] ?? 0);
    
    // Guardar dados para repopular formulário em caso de erro
    $form_data = compact('nome', 'descricao', 'endereco', 'latitude', 'longitude', 'avaliacao_inicial');
    
    // Validações dos dados
    $error_message = validateFormData($nome, $descricao, $latitude, $longitude);
    
    // Se não há erros de validação, processar
    if (empty($error_message)) {
        $error_message = processSpotCreation($nome, $descricao, $endereco, $latitude, $longitude, $avaliacao_inicial);
    }
}

/**
 * Validar dados do formulário
 */
function validateFormData($nome, $descricao, $latitude, $longitude) {
    if (empty($nome)) {
        return 'O nome do spot é obrigatório.';
    }
    
    if (strlen($nome) > 100) {
        return 'O nome do spot não pode ter mais de 100 caracteres.';
    }
    
    if (empty($descricao)) {
        return 'A descrição do spot é obrigatória.';
    }
    
    if (strlen($descricao) > 1000) {
        return 'A descrição não pode ter mais de 1000 caracteres.';
    }
    
    if ($latitude === 0 || $longitude === 0) {
        return 'Por favor, selecione a localização no mapa.';
    }
    
    if (!isset($_FILES['foto_principal']) || $_FILES['foto_principal']['error'] !== UPLOAD_ERR_OK) {
        return 'É obrigatório enviar uma foto principal do spot.';
    }
    
    return '';
}

/**
 * Processar criação do spot
 */
function processSpotCreation($nome, $descricao, $endereco, $latitude, $longitude, $avaliacao_inicial) {
    try {
        $conn = getConnection();
        if (!$conn) {
            return 'Erro de conexão com a base de dados.';
        }
        
        // Upload da foto principal
        $foto_nome = uploadFile($_FILES['foto_principal'], 'uploads/spots/');
        if (!$foto_nome) {
            return 'Erro no upload da foto. Verifique se é uma imagem válida (JPG, PNG, GIF) e menor que 5MB.';
        }
        
        // Inserir spot na base de dados
        $spot_id = insertSpot($conn, $nome, $descricao, $endereco, $latitude, $longitude, $foto_nome);
        if (!$spot_id) {
            unlink('uploads/spots/' . $foto_nome);
            return 'Erro ao adicionar o spot. Tente novamente.';
        }
        
        // Adicionar avaliação inicial se fornecida
        if ($avaliacao_inicial > 0 && $avaliacao_inicial <= 5) {
            insertInitialRating($conn, $spot_id, $avaliacao_inicial);
        }
        
        // Upload de fotos adicionais
        processAdditionalPhotos($conn, $spot_id);
        
        // Sucesso - redirecionar
        $_SESSION['success_message'] = 'Spot adicionado com sucesso!';
        redirect(SITE_URL . "/spot_detalhes.php?id={$spot_id}");
        
    } catch (Exception $e) {
        error_log("Erro ao adicionar spot: " . $e->getMessage());
        return 'Erro interno. Tente novamente.';
    }
    
    return '';
}

/**
 * Inserir spot na base de dados
 */
function insertSpot($conn, $nome, $descricao, $endereco, $latitude, $longitude, $foto_nome) {
    $stmt = $conn->prepare("
        INSERT INTO spots (id_usuario, nome, descricao, endereco, latitude, longitude, foto_principal, data_criacao)
        VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
    ");
    
    $result = $stmt->execute([
        $_SESSION['user_id'],
        $nome,
        $descricao,
        $endereco,
        $latitude,
        $longitude,
        $foto_nome
    ]);
    
    return $result ? $conn->lastInsertId() : false;
}

/**
 * Adicionar avaliação inicial
 */
function insertInitialRating($conn, $spot_id, $rating) {
    try {
        $stmt = $conn->prepare("
            INSERT INTO avaliacoes_spots (id_spot, id_usuario, rating, comentario, data_avaliacao)
            VALUES (?, ?, ?, ?, NOW())
        ");
        
        $stmt->execute([
            $spot_id,
            $_SESSION['user_id'],
            $rating,
            'Avaliação inicial do criador do spot'
        ]);
    } catch (Exception $e) {
        error_log("Erro ao adicionar avaliação inicial: " . $e->getMessage());
    }
}

/**
 * Processar fotos adicionais
 */
function processAdditionalPhotos($conn, $spot_id) {
    if (!isset($_FILES['fotos_adicionais'])) {
        return;
    }
    
    $fotos_adicionais = $_FILES['fotos_adicionais'];
    $max_fotos = 10;
    $fotos_processadas = 0;
    
    for ($i = 0; $i < count($fotos_adicionais['name']) && $fotos_processadas < $max_fotos; $i++) {
        if ($fotos_adicionais['error'][$i] === UPLOAD_ERR_OK) {
            $foto_adicional = [
                'name' => $fotos_adicionais['name'][$i],
                'type' => $fotos_adicionais['type'][$i],
                'tmp_name' => $fotos_adicionais['tmp_name'][$i],
                'error' => $fotos_adicionais['error'][$i],
                'size' => $fotos_adicionais['size'][$i]
            ];
            
            $nome_foto_adicional = uploadFile($foto_adicional, 'uploads/spots/');
            
            if ($nome_foto_adicional) {
                $stmt = $conn->prepare("
                    INSERT INTO fotos_spots (id_spot, caminho_foto, data_upload) 
                    VALUES (?, ?, NOW())
                ");
                $stmt->execute([$spot_id, $nome_foto_adicional]);
                $fotos_processadas++;
            }
        }
    }
}

/**
 * Obter título da avaliação
 */
function getRatingTitle($rating) {
    $titles = [
        1 => 'Fraco (1 estrela)',
        2 => 'Regular (2 estrelas)',  
        3 => 'Bom (3 estrelas)',
        4 => 'Muito Bom (4 estrelas)',
        5 => 'Excelente (5 estrelas)'
    ];
    return $titles[$rating] ?? '';
}

/**
 * Obter descrição da avaliação
 */
function getRatingDescription($rating) {
    $descriptions = [
        1 => 'Muito Ruim',
        2 => 'Ruim',
        3 => 'Bom',
        4 => 'Muito Bom',
        5 => 'Excelente'
    ];
    return $descriptions[$rating] ?? '';
}

require_once 'includes/header.php';
?>

<div class="add-spot-container">
    <div class="container">
        <div class="page-header">
            <div class="page-header-content">
                <h1 class="page-title">
                    <i class="fas fa-plus-circle"></i>
                    Adicionar Novo Spot
                </h1>
                <p class="page-description">
                    Partilhe um novo spot de skate com a comunidade. Preencha todas as informações necessárias.
                </p>
            </div>
        </div>

        <div class="add-spot-content">
            <!-- Formulário -->
            <div class="spot-form-section">
                <?php if ($error_message): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo $error_message; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data" class="spot-form" id="spotForm">
                    <!-- Informações Básicas -->
                    <div class="form-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-info-circle"></i>
                            Informações Básicas
                        </h2>

                        <div class="form-group">
                            <label for="nome" class="required">
                                <i class="fas fa-tag"></i>
                                Nome do Spot
                            </label>
                            <input
                                type="text"
                                id="nome"
                                name="nome"
                                class="form-control"
                                placeholder="Ex: Skate Park do Porto, Escadarias do Rossio..."
                                value="<?php echo htmlspecialchars($form_data['nome'] ?? ''); ?>"
                                required
                                maxlength="100"
                                autocomplete="off"
                            >
                            <div class="char-count">
                                <span id="nome-count">0</span>/100 caracteres
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="descricao" class="required">
                                <i class="fas fa-align-left"></i>
                                Descrição
                            </label>
                            <textarea
                                id="descricao"
                                name="descricao"
                                class="form-control"
                                placeholder="Descreva o spot: tipo de obstáculos, nível de dificuldade, horários recomendados, acessibilidade..."
                                required
                                rows="5"
                                maxlength="1000"
                            ><?php echo htmlspecialchars($form_data['descricao'] ?? ''); ?></textarea>
                            <div class="char-count">
                                <span id="descricao-count">0</span>/1000 caracteres
                            </div>
                            <small class="form-help">
                                <i class="fas fa-lightbulb"></i>
                                Informações detalhadas ajudam outros skaters a saberem o que esperar
                            </small>
                        </div>
                    </div>

                    <!-- Localização -->
                    <div class="form-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-map-marker-alt"></i>
                            Localização
                        </h2>

                        <div class="location-controls">
                            <div class="form-group">
                                <label for="location-search">
                                    <i class="fas fa-search"></i>
                                    Pesquisar Localização
                                </label>
                                <div class="search-input-group">
                                    <input
                                        type="text"
                                        id="location-search"
                                        class="form-control"
                                        placeholder="Digite o endereço ou nome do local..."
                                        autocomplete="off"
                                    >
                                    <button type="button" id="clear-search" class="clear-btn" title="Limpar pesquisa">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                <small class="form-help">
                                    <i class="fas fa-info-circle"></i>
                                    Use a pesquisa ou clique diretamente no mapa
                                </small>
                            </div>

                            <!-- Status da Localização -->
                            <div class="location-status" id="location-status">
                                <div class="status-indicator">
                                    <i class="fas fa-map-pin text-muted"></i>
                                    <span class="status-text">Selecione um local no mapa</span>
                                </div>
                            </div>
                        </div>

                        <!-- Coordenadas (preenchidas automaticamente) -->
                        <div class="coordinates-display" id="coordinates-display" style="display: none;">
                            <div class="coordinates-header">
                                <h4><i class="fas fa-crosshairs"></i> Coordenadas Selecionadas</h4>
                                <button type="button" id="reset-location" class="btn-reset" title="Limpar localização">
                                    <i class="fas fa-redo"></i> Redefinir
                                </button>
                            </div>
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="latitude">Latitude</label>
                                    <input
                                        type="number"
                                        id="latitude"
                                        name="latitude"
                                        class="form-control"
                                        step="any"
                                        readonly
                                        value="<?php echo $form_data['latitude'] ?? ''; ?>"
                                        required
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="longitude">Longitude</label>
                                    <input
                                        type="number"
                                        id="longitude"
                                        name="longitude"
                                        class="form-control"
                                        step="any"
                                        readonly
                                        value="<?php echo $form_data['longitude'] ?? ''; ?>"
                                        required
                                    >
                                </div>
                            </div>
                            <div class="selected-address" id="selected-address">
                                <i class="fas fa-map-pin"></i>
                                <span id="address-text">Obtendo endereço...</span>
                            </div>
                        </div>

                        <!-- Campo de endereço oculto -->
                        <input
                            type="hidden"
                            id="endereco"
                            name="endereco"
                            value="<?php echo htmlspecialchars($form_data['endereco'] ?? ''); ?>"
                        >

                        <!-- Mapa Interativo -->
                        <div class="map-section">
                            <div class="map-header">
                                <h3>
                                    <i class="fas fa-mouse-pointer"></i>
                                    Mapa Interativo
                                </h3>
                                <div class="map-tools">
                                    <button type="button" id="find-me" class="btn-tool" title="Ir para minha localização">
                                        <i class="fas fa-location-arrow"></i>
                                    </button>
                                    <button type="button" id="map-fullscreen" class="btn-tool" title="Tela cheia">
                                        <i class="fas fa-expand"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="map-container">
                                <div id="map"></div>
                                <div class="map-loading" id="map-loading">
                                    <i class="fas fa-spinner fa-spin"></i>
                                    <span>Carregando mapa...</span>
                                </div>
                            </div>
                            <div class="map-instructions">
                                <div class="instruction-item">
                                    <i class="fas fa-mouse"></i>
                                    <span>Clique no mapa para marcar a localização</span>
                                </div>
                                <div class="instruction-item">
                                    <i class="fas fa-hand-rock"></i>
                                    <span>Arraste o marcador para ajustar a posição</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Avaliação Inicial -->
                    <div class="form-section optional-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-star"></i>
                            Avaliação Inicial
                            <span class="optional-badge">Opcional</span>
                        </h2>

                        <div class="rating-container">
                            <div class="rating-header">
                                <span class="rating-question">Como avalia este spot?</span>
                                <button type="button" id="clear-rating" class="clear-rating" style="display: none;">
                                    <i class="fas fa-times"></i> Limpar
                                </button>
                            </div>
                            
                            <div class="rating-input">
                                <div class="stars-input" id="rating-stars">
                                    <?php for ($i = 5; $i >= 1; $i--): ?>
                                        <input type="radio" id="star<?php echo $i; ?>" name="avaliacao_inicial" value="<?php echo $i; ?>"
                                               <?php echo ($form_data['avaliacao_inicial'] ?? 0) == $i ? 'checked' : ''; ?>>
                                        <label for="star<?php echo $i; ?>" title="<?php echo getRatingTitle($i); ?>">
                                            <i class="fas fa-star"></i>
                                        </label>
                                    <?php endfor; ?>
                                </div>
                                <div class="rating-text" id="rating-text">
                                    <?php 
                                    $rating = $form_data['avaliacao_inicial'] ?? 0;
                                    if ($rating > 0) {
                                        echo getRatingDescription($rating);
                                    } else {
                                        echo 'Clique nas estrelas para avaliar';
                                    }
                                    ?>
                                </div>
                            </div>

                            <div class="rating-criteria">
                                <h4>Critérios de Avaliação</h4>
                                <div class="criteria-grid">
                                    <div class="criteria-item">
                                        <i class="fas fa-cubes"></i>
                                        <span>Obstáculos</span>
                                    </div>
                                    <div class="criteria-item">
                                        <i class="fas fa-shield-alt"></i>
                                        <span>Segurança</span>
                                    </div>
                                    <div class="criteria-item">
                                        <i class="fas fa-accessibility"></i>
                                        <span>Acessibilidade</span>
                                    </div>
                                    <div class="criteria-item">
                                        <i class="fas fa-location-arrow"></i>
                                        <span>Localização</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Fotos -->
                    <div class="form-section">
                        <h2 class="form-section-title">
                            <i class="fas fa-camera"></i>
                            Fotos do Spot
                        </h2>

                        <!-- Foto Principal -->
                        <div class="form-group">
                            <label for="foto_principal" class="required">
                                <i class="fas fa-image"></i>
                                Foto Principal
                            </label>
                            <div class="file-upload-area" id="main-photo-area">
                                <input
                                    type="file"
                                    id="foto_principal"
                                    name="foto_principal"
                                    class="file-input"
                                    accept="image/jpeg,image/jpg,image/png,image/gif"
                                    required
                                >
                                <div class="upload-content">
                                    <div class="upload-icon">
                                        <i class="fas fa-cloud-upload-alt"></i>
                                    </div>
                                    <div class="upload-text">
                                        <strong>Clique para selecionar</strong> ou arraste a imagem
                                    </div>
                                    <div class="upload-info">
                                        JPG, PNG ou GIF • Máximo 5MB
                                    </div>
                                </div>
                                <div class="image-preview" id="main-photo-preview" style="display: none;">
                                    <img src="" alt="Preview" class="preview-image">
                                    <div class="preview-actions">
                                        <button type="button" class="btn-remove" onclick="removeMainPhoto()">
                                            <i class="fas fa-trash"></i> Remover
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Fotos Adicionais -->
                        <div class="form-group">
                            <label for="fotos_adicionais">
                                <i class="fas fa-images"></i>
                                Fotos Adicionais
                                <span class="optional-badge">Opcional</span>
                            </label>
                            <div class="file-upload-area" id="additional-photos-area">
                                <input
                                    type="file"
                                    id="fotos_adicionais"
                                    name="fotos_adicionais[]"
                                    class="file-input"
                                    accept="image/jpeg,image/jpg,image/png,image/gif"
                                    multiple
                                >
                                <div class="upload-content">
                                    <div class="upload-icon">
                                        <i class="fas fa-plus-circle"></i>
                                    </div>
                                    <div class="upload-text">
                                        <strong>Adicionar mais fotos</strong> (até 10)
                                    </div>
                                    <div class="upload-info">
                                        JPG, PNG ou GIF
                                    </div>
                                </div>
                            </div>
                            <div class="additional-previews" id="additional-previews"></div>
                        </div>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary btn-lg" id="submit-btn" disabled>
                            <div class="btn-content">
                                <i class="fas fa-plus-circle"></i>
                                <span>Adicionar Spot</span>
                            </div>
                            <div class="btn-loading" style="display: none;">
                                <i class="fas fa-spinner fa-spin"></i>
                                <span>Adicionando...</span>
                            </div>
                        </button>

                        <button type="button" class="btn btn-outline btn-lg" onclick="clearForm()">
                            <i class="fas fa-eraser"></i>
                            Limpar Formulário
                        </button>

                        <a href="<?php echo SITE_URL; ?>" class="btn btn-text btn-lg">
                            <i class="fas fa-arrow-left"></i>
                            Cancelar
                        </a>
                    </div>
                </form>
            </div>

            <!-- Dicas para Adicionar Spots -->
            <div class="tips-section">
                <div class="tips-card">
                    <h3>
                        <i class="fas fa-lightbulb"></i>
                        Dicas para um Bom Spot
                    </h3>
                    
                    <div class="tip-item">
                        <i class="fas fa-camera"></i>
                        <div>
                            <strong>Fotos de Qualidade:</strong>
                            Tire fotos nítidas e bem iluminadas que mostrem claramente os obstáculos e o ambiente.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Localização Precisa:</strong>
                            Clique diretamente no mapa ou use a pesquisa para marcar a posição exata do spot.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-info-circle"></i>
                        <div>
                            <strong>Descrição Completa:</strong>
                            Mencione tipo de obstáculos, nível de dificuldade, horários recomendados e qualquer informação útil.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-star"></i>
                        <div>
                            <strong>Avaliação Inicial:</strong>
                            A sua avaliação ajuda outros skaters a saberem o que esperar e será incluída na média geral.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-users"></i>
                        <div>
                            <strong>Respeite a Propriedade:</strong>
                            Apenas adicione spots em locais públicos ou onde o skate é permitido.
                        </div>
                    </div>

                    <div class="tip-item">
                        <i class="fas fa-shield-alt"></i>
                        <div>
                            <strong>Segurança Primeiro:</strong>
                            Mencione eventuais riscos ou cuidados especiais necessários no local.
                        </div>
                    </div>
                </div>

                <div class="community-guidelines">
                    <h4>
                        <i class="fas fa-heart"></i>
                        Diretrizes da Comunidade
                    </h4>
                    <ul>
                        <li>Seja respeitoso e construtivo</li>
                        <li>Apenas spots reais e acessíveis</li>
                        <li>Fotos próprias ou com permissão</li>
                        <li>Informações precisas e úteis</li>
                        <li>Respeite propriedade privada</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* ===== PÁGINA ADICIONAR SPOT ===== */
.add-spot-container {
    min-height: calc(100vh - 160px);
    padding: 2rem 0;
    background: linear-gradient(135deg, var(--background-color) 0%, var(--surface-color) 100%);
}

/* ===== ESTRUTURA GERAL ===== */
.page-header {
    text-align: center;
    margin-bottom: 3rem;
    padding: 2rem 0;
}

.page-title {
    font-size: 2.8rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    font-weight: 700;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.page-description {
    font-size: 1.2rem;
    color: var(--text-secondary);
    max-width: 600px;
    margin: 0 auto;
    line-height: 1.6;
}

.add-spot-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 3rem;
    align-items: start;
    max-width: 1400px;
    margin: 0 auto;
}

/* ===== FORMULÁRIO ===== */
.spot-form-section {
    background: var(--surface-color);
    border-radius: 20px;
    padding: 2.5rem;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
    position: relative;
    overflow: hidden;
}

.spot-form-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
}

/* ===== SEÇÕES DO FORMULÁRIO ===== */
.form-section {
    margin-bottom: 3rem;
    position: relative;
}

.form-section.optional-section {
    border: 2px dashed var(--border-color);
    border-radius: 15px;
    padding: 2rem;
    background: rgba(var(--primary-rgb), 0.02);
}

.form-section-title {
    font-size: 1.6rem;
    color: var(--primary-color);
    margin-bottom: 2rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding-bottom: 1rem;
    border-bottom: 2px solid var(--border-color);
    position: relative;
}

.optional-badge {
    background: var(--warning-color);
    color: white;
    padding: 0.25rem 0.75rem;
    border-radius: 12px;
    font-size: 0.75rem;
    font-weight: 600;
    margin-left: auto;
}

/* ===== CAMPOS DO FORMULÁRIO ===== */
.form-group {
    margin-bottom: 2rem;
}

.form-group label {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 0.75rem;
    color: var(--text-primary);
    font-weight: 600;
    font-size: 1rem;
}

.form-group label.required::after {
    content: '*';
    color: var(--error-color);
    margin-left: 0.25rem;
    font-size: 1.2rem;
}

.form-control {
    width: 100%;
    padding: 1rem 1.25rem;
    border: 2px solid var(--border-color);
    border-radius: 12px;
    font-size: 1rem;
    transition: all 0.3s ease;
    background: var(--surface-color);
    color: var(--text-primary);
    resize: vertical;
}

.form-control:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(var(--primary-rgb), 0.1);
    transform: translateY(-2px);
}

.form-control[readonly] {
    background: rgba(var(--primary-rgb), 0.05);
    border-color: var(--primary-color);
    color: var(--primary-color);
    font-weight: 600;
    cursor: not-allowed;
}

.form-help {
    display: block;
    margin-top: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
    line-height: 1.5;
}

.form-help i {
    color: var(--primary-color);
    margin-right: 0.5rem;
}

.char-count {
    text-align: right;
    margin-top: 0.5rem;
    font-size: 0.85rem;
    color: var(--text-secondary);
}

/* ===== LOCALIZAÇÃO ===== */
.location-controls {
    margin-bottom: 2rem;
}

.search-input-group {
    position: relative;
}

.clear-btn {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 50%;
    transition: all 0.3s ease;
}

.clear-btn:hover {
    background: var(--error-color);
    color: white;
}

.location-status {
    margin: 1rem 0;
    padding: 1rem;
    background: var(--background-color);
    border-radius: 10px;
    border: 2px dashed var(--border-color);
}

.status-indicator {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.status-text {
    color: var(--text-secondary);
    font-weight: 500;
}

.coordinates-display {
    background: linear-gradient(135deg, rgba(var(--primary-rgb), 0.1), rgba(var(--secondary-rgb), 0.05));
    border: 2px solid var(--primary-color);
    border-radius: 15px;
    padding: 2rem;
    margin: 1.5rem 0;
    animation: fadeInUp 0.3s ease;
}

.coordinates-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.coordinates-header h4 {
    color: var(--primary-color);
    margin: 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.btn-reset {
    background: var(--warning-color);
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.btn-reset:hover {
    background: var(--error-color);
    transform: translateY(-2px);
}

.selected-address {
    margin-top: 1rem;
    padding: 1rem;
    background: white;
    border-radius: 10px;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    color: var(--text-secondary);
    border: 1px solid var(--border-color);
}

/* ===== MAPA ===== */
.map-section {
    margin: 2rem 0;
}

.map-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.map-header h3 {
    color: var(--text-primary);
    font-size: 1.3rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin: 0;
}

.map-tools {
    display: flex;
    gap: 0.5rem;
}

.btn-tool {
    background: var(--surface-color);
    border: 1px solid var(--border-color);
    padding: 0.75rem;
    border-radius: 8px;
    cursor: pointer;
    color: var(--text-primary);
    transition: all 0.3s ease;
}

.btn-tool:hover {
    background: var(--primary-color);
    color: white;
    transform: translateY(-2px);
}

.map-container {
    position: relative;
    height: 400px;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.15);
    border: 2px solid var(--border-color);
}

#map {
    width: 100%;
    height: 100%;
}

.map-loading {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: var(--surface-color);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 1rem;
    z-index: 10;
}

.map-instructions {
    display: flex;
    gap: 2rem;
    margin-top: 1rem;
    justify-content: center;
}

.instruction-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.instruction-item i {
    color: var(--primary-color);
}

/* ===== SISTEMA DE AVALIAÇÃO ===== */
.rating-container {
    padding: 2rem;
}

.rating-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
}

.rating-question {
    font-size: 1.2rem;
    font-weight: 600;
    color: var(--text-primary);
}

.clear-rating {
    background: var(--error-color);
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.rating-input {
    text-align: center;
    padding: 2rem;
    background: var(--background-color);
    border-radius: 15px;
    border: 2px dashed var(--border-color);
    margin-bottom: 2rem;
    transition: all 0.3s ease;
}

.rating-input:hover {
    border-color: var(--primary-color);
    background: rgba(var(--primary-rgb), 0.05);
}

.stars-input {
    display: flex;
    flex-direction: row-reverse;
    justify-content: center;
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

.stars-input input[type="radio"] {
    display: none;
}

.stars-input label {
    cursor: pointer;
    font-size: 3rem;
    color: #e5e7eb;
    transition: all 0.3s ease;
    transform: scale(1);
}

.stars-input label:hover,
.stars-input label:hover ~ label {
    color: #fbbf24;
    transform: scale(1.2);
}

.stars-input input[type="radio"]:checked ~ label {
    color: #f59e0b;
    text-shadow: 0 0 15px rgba(245, 158, 11, 0.6);
}

.stars-input label:hover {
    animation: starPulse 0.4s ease;
}

@keyframes starPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.3); }
    100% { transform: scale(1.2); }
}

.rating-text {
    font-size: 1.2rem;
    font-weight: 600;
    min-height: 2rem;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.3s ease;
}

.rating-text.rating-1 { color: #ef4444; }
.rating-text.rating-2 { color: #f97316; }
.rating-text.rating-3 { color: #eab308; }
.rating-text.rating-4 { color: #22c55e; }
.rating-text.rating-5 { color: #16a34a; }

.rating-criteria {
    background: white;
    padding: 1.5rem;
    border-radius: 12px;
    border: 1px solid var(--border-color);
}

.rating-criteria h4 {
    margin-bottom: 1rem;
    color: var(--text-primary);
    font-size: 1rem;
}

.criteria-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
}

.criteria-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem;
    background: var(--background-color);
    border-radius: 8px;
    color: var(--text-secondary);
}

.criteria-item i {
    color: var(--primary-color);
    font-size: 1.1rem;
}

/* ===== UPLOAD DE FOTOS ===== */
.photo-upload-section {
    space-y: 2rem;
}

.file-upload-area {
    position: relative;
    border: 3px dashed var(--border-color);
    border-radius: 15px;
    padding: 2rem;
    text-align: center;
    background: var(--background-color);
    transition: all 0.3s ease;
    cursor: pointer;
}

.file-upload-area:hover {
    border-color: var(--primary-color);
    background: rgba(var(--primary-rgb), 0.05);
}

.file-upload-area.dragover {
    border-color: var(--primary-color);
    background: rgba(var(--primary-rgb), 0.1);
    transform: scale(1.02);
}

.file-input {
    position: absolute;
    opacity: 0;
    width: 100%;
    height: 100%;
    cursor: pointer;
}

.upload-content {
    pointer-events: none;
}

.upload-icon {
    font-size: 3rem;
    color: var(--primary-color);
    margin-bottom: 1rem;
}

.upload-text {
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
    color: var(--text-primary);
}

.upload-info {
    color: var(--text-secondary);
    font-size: 0.9rem;
}

.image-preview {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 1rem;
}

.preview-image {
    max-width: 100%;
    max-height: 300px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
    object-fit: cover;
}

.preview-actions {
    display: flex;
    gap: 1rem;
}

.btn-remove {
    background: var(--error-color);
    color: white;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    font-weight: 500;
}

.btn-remove:hover {
    background: #dc2626;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
}

.additional-previews {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 1rem;
    margin-top: 1rem;
}

.additional-preview {
    position: relative;
    background: white;
    border-radius: 10px;
    padding: 0.5rem;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.additional-preview img {
    width: 100%;
    height: 120px;
    object-fit: cover;
    border-radius: 8px;
}

.additional-preview .remove-btn {
    position: absolute;
    top: -8px;
    right: -8px;
    background: var(--error-color);
    color: white;
    border: none;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.8rem;
}





/* ===== AÇÕES DO FORMULÁRIO ===== */
.form-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    align-items: center;
    padding: 2rem 0;
    border-top: 2px solid var(--border-color);
    margin-top: 2rem;
}

.btn {
    padding: 1rem 2rem;
    border-radius: 12px;
    font-size: 1rem;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.75rem;
    cursor: pointer;
    transition: all 0.3s ease;
    border: 2px solid transparent;
    position: relative;
    overflow: hidden;
}

.btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none !important;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
    box-shadow: 0 5px 15px rgba(var(--primary-rgb), 0.4);
}

.btn-primary:hover:not(:disabled) {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(var(--primary-rgb), 0.5);
}

.btn-outline {
    background: transparent;
    color: var(--text-primary);
    border-color: var(--border-color);
}

.btn-outline:hover {
    background: var(--primary-color);
    color: white;
    border-color: var(--primary-color);
    transform: translateY(-2px);
}

.btn-text {
    background: transparent;
    color: var(--text-secondary);
}

.btn-text:hover {
    color: var(--primary-color);
    background: rgba(var(--primary-rgb), 0.1);
}

.btn-lg {
    padding: 1.25rem 2.5rem;
    font-size: 1.1rem;
}

.btn-content,
.btn-loading {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

/* ===== ANIMAÇÕES ===== */
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-5px); }
    75% { transform: translateX(5px); }
}

/* ===== RESPONSIVE ===== */
@media (max-width: 1024px) {
    .add-spot-content {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .tips-section {
        position: static;
    }
}

@media (max-width: 768px) {
    .add-spot-container {
        padding: 1rem 0;
    }
    
    .page-title {
        font-size: 2.2rem;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .spot-form-section {
        padding: 1.5rem;
    }
    
    .coordinates-display {
        padding: 1.5rem;
    }
    
    .form-row {
        flex-direction: column;
    }
    
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    
    .map-container {
        height: 300px;
    }
    
    .map-instructions {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
    
    .criteria-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .spot-form-section {
        padding: 1rem;
    }
    
    .form-section {
        margin-bottom: 2rem;
    }
    
    .stars-input label {
        font-size: 2.5rem;
    }
    
    .coordinates-header {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }
}

.page-header {
    text-align: center;
    margin-bottom: 3rem;
}

.page-title {
    font-size: 2.5rem;
    color: var(--text-primary);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 1rem;
}

.page-description {
    font-size: 1.125rem;
    color: var(--text-secondary);
    max-width: 600px;
    margin: 0 auto;
}

.add-spot-content {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 3rem;
    align-items: start;
}

.spot-form-section {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
}

.form-section {
    margin-bottom: 3rem;
}

.form-section:last-child {
    margin-bottom: 2rem;
}

.form-section-title {
    font-size: 1.5rem;
    color: var(--primary-color);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding-bottom: 0.75rem;
    border-bottom: 2px solid var(--border-color);
}

.map-section h3 {
    color: var(--text-primary);
    margin-bottom: 1rem;
    font-size: 1.125rem;
}

.form-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    padding-top: 2rem;
    border-top: 1px solid var(--border-color);
}

.tips-section {
    position: sticky;
    top: 100px;
}

.tips-card {
    background: var(--surface-color);
    border-radius: 15px;
    padding: 2rem;
    box-shadow: 0 5px 15px var(--shadow-color);
    border: 1px solid var(--border-color);
    margin-bottom: 2rem;
}

.tips-card h3 {
    color: var(--primary-color);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.tip-item {
    display: flex;
    gap: 1rem;
    margin-bottom: 1.5rem;
    padding: 1rem;
    background: var(--background-color);
    border-radius: 10px;
    border-left: 4px solid var(--primary-color);
}

.tip-item i {
    color: var(--primary-color);
    font-size: 1.25rem;
    margin-top: 0.25rem;
    min-width: 20px;
}

.tip-item strong {
    color: var(--text-primary);
    display: block;
    margin-bottom: 0.25rem;
}

.tip-item div {
    color: var(--text-secondary);
    line-height: 1.5;
}

.community-guidelines {
    background: var(--background-color);
    border-radius: 15px;
    padding: 2rem;
    border: 1px solid var(--border-color);
}

.community-guidelines h4 {
    color: var(--primary-color);
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.community-guidelines ul {
    list-style: none;
    padding: 0;
}

.community-guidelines li {
    padding: 0.5rem 0;
    color: var(--text-secondary);
    position: relative;
    padding-left: 1.5rem;
}

.community-guidelines li::before {
    content: '✓';
    position: absolute;
    left: 0;
    color: var(--success-color);
    font-weight: bold;
}

/* Responsive */
@media (max-width: 1024px) {
    .add-spot-content {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .tips-section {
        position: static;
    }
}

@media (max-width: 768px) {
    .page-title {
        font-size: 2rem;
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .spot-form-section {
        padding: 1.5rem;
    }
    
    .tips-card {
        padding: 1.5rem;
    }
    
    .form-actions {
        flex-direction: column;
        align-items: stretch;
    }
    
    .tip-item {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .tip-item i {
        align-self: flex-start;
    }
}

@media (max-width: 480px) {
    .add-spot-container {
        padding: 1rem 0;
    }
    
    .spot-form-section {
        padding: 1rem;
    }
    
    .tips-card {
        padding: 1rem;
    }
}
</style>

<script>
// ===== JAVASCRIPT PARA ADICIONAR SPOT =====

/**
 * Estado da aplicação
 */
const SpotForm = {
    form: null,
    isSubmitting: false,
    validation: {
        name: false,
        description: false,
        location: false,
        photo: false
    },
    
    // Textos das avaliações
    ratingTexts: {
        1: 'Muito Ruim',
        2: 'Ruim',
        3: 'Bom',
        4: 'Muito Bom',
        5: 'Excelente'
    }
};

/**
 * Inicialização quando DOM carrega
 */
document.addEventListener('DOMContentLoaded', function() {
    SpotForm.form = document.getElementById('spotForm');
    
    if (SpotForm.form) {
        initializeFormComponents();
        initializeValidation();
        initializeFileUploads();
        initializeRatingSystem();
        initializeLocationSystem();
        
        // Event listeners do formulário
        SpotForm.form.addEventListener('submit', handleFormSubmit);
    }
});

/**
 * Inicializar componentes do formulário
 */
function initializeFormComponents() {
    // Contador de caracteres
    setupCharacterCounters();
    
    // Botões de ação
    setupActionButtons();
    
    // Validação em tempo real
    setupRealTimeValidation();
}

/**
 * Configurar contadores de caracteres
 */
function setupCharacterCounters() {
    const nomeInput = document.getElementById('nome');
    const descricaoInput = document.getElementById('descricao');
    
    if (nomeInput) {
        const counter = document.getElementById('nome-count');
        nomeInput.addEventListener('input', () => updateCharCounter(nomeInput, counter, 100));
        updateCharCounter(nomeInput, counter, 100); // Inicializar
    }
    
    if (descricaoInput) {
        const counter = document.getElementById('descricao-count');
        descricaoInput.addEventListener('input', () => updateCharCounter(descricaoInput, counter, 1000));
        updateCharCounter(descricaoInput, counter, 1000); // Inicializar
    }
}

/**
 * Atualizar contador de caracteres
 */
function updateCharCounter(input, counter, maxLength) {
    if (!counter) return;
    
    const currentLength = input.value.length;
    counter.textContent = currentLength;
    
    // Mudar cor baseado na proximidade do limite
    const percentage = (currentLength / maxLength) * 100;
    if (percentage >= 90) {
        counter.style.color = 'var(--error-color)';
    } else if (percentage >= 75) {
        counter.style.color = 'var(--warning-color)';
    } else {
        counter.style.color = 'var(--text-secondary)';
    }
}

/**
 * Configurar botões de ação
 */
function setupActionButtons() {
    const clearBtn = document.getElementById('clear-search');
    const resetLocationBtn = document.getElementById('reset-location');
    const clearRatingBtn = document.getElementById('clear-rating');
    const findMeBtn = document.getElementById('find-me');
    
    if (clearBtn) {
        clearBtn.addEventListener('click', clearLocationSearch);
    }
    
    if (resetLocationBtn) {
        resetLocationBtn.addEventListener('click', resetLocation);
    }
    
    if (clearRatingBtn) {
        clearRatingBtn.addEventListener('click', clearRating);
    }
    
    if (findMeBtn) {
        findMeBtn.addEventListener('click', findUserLocation);
    }
}

/**
 * Configurar validação em tempo real
 */
function setupRealTimeValidation() {
    const nomeInput = document.getElementById('nome');
    const descricaoInput = document.getElementById('descricao');
    
    if (nomeInput) {
        nomeInput.addEventListener('input', () => validateField('name', nomeInput.value.trim()));
        nomeInput.addEventListener('blur', () => validateField('name', nomeInput.value.trim()));
    }
    
    if (descricaoInput) {
        descricaoInput.addEventListener('input', () => validateField('description', descricaoInput.value.trim()));
        descricaoInput.addEventListener('blur', () => validateField('description', descricaoInput.value.trim()));
    }
}

/**
 * Inicializar sistema de validação
 */
function initializeValidation() {
    // Validação inicial baseada em valores existentes
    const nome = document.getElementById('nome')?.value.trim() || '';
    const descricao = document.getElementById('descricao')?.value.trim() || '';
    const latitude = document.getElementById('latitude')?.value || '';
    const longitude = document.getElementById('longitude')?.value || '';
    
    validateField('name', nome);
    validateField('description', descricao);
    validateField('location', latitude && longitude);
    
    updateValidationStatus();
}

/**
 * Validar campo específico
 */
function validateField(field, value) {
    let isValid = false;
    
    switch (field) {
        case 'name':
            isValid = value.length > 0 && value.length <= 100;
            break;
        case 'description':
            isValid = value.length > 0 && value.length <= 1000;
            break;
        case 'location':
            isValid = Boolean(value);
            break;
        case 'photo':
            isValid = Boolean(value);
            break;
    }
    
    SpotForm.validation[field] = isValid;
    updateValidationUI(field, isValid);
    updateValidationStatus();
    
    return isValid;
}

/**
 * Atualizar UI de validação
 */
function updateValidationUI(field, isValid) {
    // Atualização visual removida - sem resumo
}

/**
 * Atualizar status geral de validação
 */
function updateValidationStatus() {
    const submitBtn = document.getElementById('submit-btn');
    const allValid = Object.values(SpotForm.validation).every(v => v);
    
    if (submitBtn) {
        submitBtn.disabled = !allValid;
    }
}

/**
 * Inicializar uploads de ficheiro
 */
function initializeFileUploads() {
    const mainPhotoInput = document.getElementById('foto_principal');
    const additionalPhotosInput = document.getElementById('fotos_adicionais');
    
    if (mainPhotoInput) {
        mainPhotoInput.addEventListener('change', handleMainPhotoChange);
        setupDragAndDrop('main-photo-area', mainPhotoInput);
    }
    
    if (additionalPhotosInput) {
        additionalPhotosInput.addEventListener('change', handleAdditionalPhotosChange);
        setupDragAndDrop('additional-photos-area', additionalPhotosInput);
    }
}

/**
 * Configurar drag and drop
 */
function setupDragAndDrop(areaId, input) {
    const area = document.getElementById(areaId);
    if (!area) return;
    
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        area.addEventListener(eventName, preventDefaults);
    });
    
    ['dragenter', 'dragover'].forEach(eventName => {
        area.addEventListener(eventName, () => area.classList.add('dragover'));
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        area.addEventListener(eventName, () => area.classList.remove('dragover'));
    });
    
    area.addEventListener('drop', (e) => handleFileDrop(e, input));
}

/**
 * Prevenir comportamentos padrão
 */
function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

/**
 * Lidar com drop de ficheiro
 */
function handleFileDrop(e, input) {
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        input.files = files;
        input.dispatchEvent(new Event('change'));
    }
}

/**
 * Lidar com mudança da foto principal
 */
function handleMainPhotoChange(e) {
    const file = e.target.files[0];
    if (file) {
        if (validateImageFile(file)) {
            displayMainPhotoPreview(file);
            validateField('photo', true);
        } else {
            e.target.value = '';
            validateField('photo', false);
        }
    }
}

/**
 * Lidar com mudança das fotos adicionais
 */
function handleAdditionalPhotosChange(e) {
    const files = Array.from(e.target.files);
    
    if (files.length > 10) {
        SkateMap.showAlert('Máximo 10 fotos adicionais permitidas', 'warning');
        e.target.value = '';
        return;
    }
    
    const validFiles = files.filter(validateImageFile);
    if (validFiles.length !== files.length) {
        SkateMap.showAlert('Alguns ficheiros foram removidos por serem inválidos', 'warning');
    }
    
    displayAdditionalPhotosPreview(validFiles);
}

/**
 * Validar ficheiro de imagem
 */
function validateImageFile(file) {
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    const maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!validTypes.includes(file.type)) {
        SkateMap.showAlert('Apenas ficheiros JPG, PNG e GIF são permitidos', 'error');
        return false;
    }
    
    if (file.size > maxSize) {
        SkateMap.showAlert('Ficheiro muito grande. Máximo 5MB permitido', 'error');
        return false;
    }
    
    return true;
}

/**
 * Mostrar preview da foto principal
 */
function displayMainPhotoPreview(file) {
    const preview = document.getElementById('main-photo-preview');
    const uploadContent = document.querySelector('#main-photo-area .upload-content');
    
    if (preview && uploadContent) {
        const reader = new FileReader();
        reader.onload = (e) => {
            preview.querySelector('img').src = e.target.result;
            uploadContent.style.display = 'none';
            preview.style.display = 'flex';
        };
        reader.readAsDataURL(file);
    }
}

/**
 * Remover foto principal
 */
function removeMainPhoto() {
    const input = document.getElementById('foto_principal');
    const preview = document.getElementById('main-photo-preview');
    const uploadContent = document.querySelector('#main-photo-area .upload-content');
    
    if (input) input.value = '';
    if (preview) preview.style.display = 'none';
    if (uploadContent) uploadContent.style.display = 'block';
    
    validateField('photo', false);
}

/**
 * Mostrar preview das fotos adicionais
 */
function displayAdditionalPhotosPreview(files) {
    const container = document.getElementById('additional-previews');
    if (!container) return;
    
    container.innerHTML = '';
    
    files.forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const previewElement = createAdditionalPreviewElement(e.target.result, index);
            container.appendChild(previewElement);
        };
        reader.readAsDataURL(file);
    });
}

/**
 * Criar elemento de preview adicional
 */
function createAdditionalPreviewElement(src, index) {
    const div = document.createElement('div');
    div.className = 'additional-preview';
    div.innerHTML = `
        <img src="${src}" alt="Preview ${index + 1}">
        <button type="button" class="remove-btn" onclick="removeAdditionalPhoto(${index})">
            <i class="fas fa-times"></i>
        </button>
    `;
    return div;
}

/**
 * Remover foto adicional
 */
function removeAdditionalPhoto(index) {
    const input = document.getElementById('fotos_adicionais');
    if (!input || !input.files) return;
    
    const dt = new DataTransfer();
    const files = Array.from(input.files);
    
    files.forEach((file, i) => {
        if (i !== index) dt.items.add(file);
    });
    
    input.files = dt.files;
    input.dispatchEvent(new Event('change'));
}

/**
 * Inicializar sistema de avaliação
 */
function initializeRatingSystem() {
    const ratingInputs = document.querySelectorAll('input[name="avaliacao_inicial"]');
    const ratingText = document.getElementById('rating-text');
    const clearRatingBtn = document.getElementById('clear-rating');
    
    // Event listeners para mudança de rating
    ratingInputs.forEach(input => {
        input.addEventListener('change', updateRatingDisplay);
    });
    
    // Hover effects
    const starLabels = document.querySelectorAll('.stars-input label');
    starLabels.forEach((label, index) => {
        label.addEventListener('mouseenter', () => {
            const rating = 5 - index;
            updateRatingText(rating);
        });
    });
    
    // Reset text on mouse leave
    const starsContainer = document.querySelector('.stars-input');
    if (starsContainer) {
        starsContainer.addEventListener('mouseleave', () => {
            const checkedInput = document.querySelector('input[name="avaliacao_inicial"]:checked');
            if (checkedInput) {
                // Se há uma estrela selecionada, mostrar seu texto
                const ratingText = document.getElementById('rating-text');
                if (ratingText) {
                    ratingText.textContent = SpotForm.ratingTexts[checkedInput.value];
                    ratingText.className = `rating-text rating-${checkedInput.value}`;
                }
            } else {
                // Se não há estrela selecionada, mostrar instrução
                updateRatingText(0);
            }
        });
    }
    
    // Mostrar/ocultar botão de limpar
    ratingInputs.forEach(input => {
        input.addEventListener('change', () => {
            if (clearRatingBtn) {
                clearRatingBtn.style.display = input.checked ? 'flex' : 'none';
            }
        });
    });
}

/**
 * Atualizar display da avaliação
 */
function updateRatingDisplay() {
    const checkedInput = document.querySelector('input[name="avaliacao_inicial"]:checked');
    const ratingText = document.getElementById('rating-text');
    
    if (checkedInput && ratingText) {
        const rating = checkedInput.value;
        ratingText.textContent = SpotForm.ratingTexts[rating];
        ratingText.className = `rating-text rating-${rating}`;
    } else if (ratingText) {
        ratingText.textContent = 'Clique nas estrelas para avaliar';
        ratingText.className = 'rating-text';
    }
}

/**
 * Atualizar texto da avaliação
 */
function updateRatingText(rating) {
    const ratingText = document.getElementById('rating-text');
    if (!ratingText) return;
    
    if (rating > 0) {
        ratingText.textContent = SpotForm.ratingTexts[rating];
        ratingText.className = `rating-text rating-${rating}`;
    } else {
        ratingText.textContent = 'Clique nas estrelas para avaliar';
        ratingText.className = 'rating-text';
    }
}

/**
 * Limpar avaliação
 */
function clearRating() {
    const ratingInputs = document.querySelectorAll('input[name="avaliacao_inicial"]');
    ratingInputs.forEach(input => input.checked = false);
    
    const ratingText = document.getElementById('rating-text');
    if (ratingText) {
        ratingText.textContent = 'Clique nas estrelas para avaliar';
        ratingText.className = 'rating-text';
    }
    
    const clearBtn = document.getElementById('clear-rating');
    if (clearBtn) clearBtn.style.display = 'none';
}

/**
 * Inicializar sistema de localização
 */
function initializeLocationSystem() {
    // Verificar se há coordenadas pré-preenchidas
    const lat = document.getElementById('latitude')?.value;
    const lng = document.getElementById('longitude')?.value;
    
    if (lat && lng && lat != '0' && lng != '0') {
        showCoordinatesDisplay();
        validateField('location', true);
    }
}

/**
 * Mostrar display das coordenadas
 */
function showCoordinatesDisplay() {
    const display = document.getElementById('coordinates-display');
    const status = document.getElementById('location-status');
    
    if (display) display.style.display = 'block';
    if (status) {
        status.querySelector('.status-text').textContent = 'Localização selecionada';
        status.querySelector('i').className = 'fas fa-map-pin text-success';
    }
}

/**
 * Ocultar display das coordenadas
 */
function hideCoordinatesDisplay() {
    const display = document.getElementById('coordinates-display');
    const status = document.getElementById('location-status');
    
    if (display) display.style.display = 'none';
    if (status) {
        status.querySelector('.status-text').textContent = 'Selecione um local no mapa';
        status.querySelector('i').className = 'fas fa-map-pin text-muted';
    }
}

/**
 * Limpar pesquisa de localização
 */
function clearLocationSearch() {
    const searchInput = document.getElementById('location-search');
    if (searchInput) {
        searchInput.value = '';
    }
}

/**
 * Resetar localização
 */
function resetLocation() {
    // Limpar campos
    const latInput = document.getElementById('latitude');
    const lngInput = document.getElementById('longitude');
    const addressInput = document.getElementById('endereco');
    
    if (latInput) latInput.value = '';
    if (lngInput) lngInput.value = '';
    if (addressInput) addressInput.value = '';
    
    // Limpar marcador do mapa
    if (window.tempMarker) {
        window.tempMarker.setMap(null);
        window.tempMarker = null;
    }
    
    // Atualizar UI
    hideCoordinatesDisplay();
    validateField('location', false);
    
    SkateMap.showAlert('Localização limpa', 'info');
}

/**
 * Encontrar localização do utilizador
 */
function findUserLocation() {
    if (!navigator.geolocation) {
        SkateMap.showAlert('Geolocalização não suportada', 'error');
        return;
    }
    
    SkateMap.showLoading('Obtendo localização...');
    
    navigator.geolocation.getCurrentPosition(
        position => {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            
            // Atualizar mapa e campos
            if (window.map) {
                window.map.setCenter({ lat, lng });
                window.map.setZoom(16);
                
                // Simular clique no mapa
                const clickEvent = { latLng: { lat: () => lat, lng: () => lng } };
                if (window.handleMapClick) {
                    window.handleMapClick(clickEvent);
                }
            }
            
            SkateMap.hideLoading();
            SkateMap.showAlert('Localização encontrada!', 'success');
        },
        error => {
            SkateMap.hideLoading();
            let message = 'Erro ao obter localização';
            
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    message = 'Permissão de localização negada';
                    break;
                case error.POSITION_UNAVAILABLE:
                    message = 'Localização indisponível';
                    break;
                case error.TIMEOUT:
                    message = 'Timeout na localização';
                    break;
            }
            
            SkateMap.showAlert(message, 'error');
        }
    );
}

/**
 * Lidar com submissão do formulário
 */
function handleFormSubmit(e) {
    if (SpotForm.isSubmitting) {
        e.preventDefault();
        return false;
    }
    
    // Validação final
    const nome = document.getElementById('nome')?.value.trim();
    const descricao = document.getElementById('descricao')?.value.trim();
    const latitude = document.getElementById('latitude')?.value;
    const longitude = document.getElementById('longitude')?.value;
    const foto = document.getElementById('foto_principal')?.files[0];
    
    // Validar todos os campos obrigatórios
    if (!validateField('name', nome) || 
        !validateField('description', descricao) || 
        !validateField('location', latitude && longitude) || 
        !validateField('photo', foto)) {
        
        e.preventDefault();
        SkateMap.showAlert('Por favor, preencha todos os campos obrigatórios', 'error');
        
        // Shake animation no formulário
        SpotForm.form.style.animation = 'shake 0.5s ease-in-out';
        setTimeout(() => SpotForm.form.style.animation = '', 500);
        
        return false;
    }
    
    // Mostrar loading
    SpotForm.isSubmitting = true;
    const submitBtn = document.getElementById('submit-btn');
    
    if (submitBtn) {
        const btnContent = submitBtn.querySelector('.btn-content');
        const btnLoading = submitBtn.querySelector('.btn-loading');
        
        if (btnContent) btnContent.style.display = 'none';
        if (btnLoading) btnLoading.style.display = 'flex';
        
        submitBtn.disabled = true;
    }
    
    SkateMap.showLoading('Adicionando spot...');
}

/**
 * Limpar formulário completo
 */
function clearForm() {
    if (SpotForm.isSubmitting) {
        SkateMap.showAlert('Aguarde o processamento atual', 'warning');
        return;
    }
    
    if (!confirm('Tem certeza que deseja limpar todos os campos do formulário?')) {
        return;
    }
    
    // Reset do formulário
    SpotForm.form.reset();
    
    // Limpar previews
    removeMainPhoto();
    const additionalPreviews = document.getElementById('additional-previews');
    if (additionalPreviews) additionalPreviews.innerHTML = '';
    
    // Limpar localização
    resetLocation();
    
    // Limpar avaliação
    clearRating();
    
    // Reset validação
    Object.keys(SpotForm.validation).forEach(key => {
        SpotForm.validation[key] = false;
    });
    
    updateValidationStatus();
    
    // Focar no primeiro campo
    const nomeInput = document.getElementById('nome');
    if (nomeInput) nomeInput.focus();
    
    SkateMap.showAlert('Formulário limpo com sucesso', 'success');
}

// Função global para usar no mapa
window.updateLocationFromMap = function(lat, lng, address) {
    const latInput = document.getElementById('latitude');
    const lngInput = document.getElementById('longitude');
    const addressInput = document.getElementById('endereco');
    const addressText = document.getElementById('address-text');
    
    if (latInput) latInput.value = lat;
    if (lngInput) lngInput.value = lng;
    if (addressInput) addressInput.value = address || '';
    if (addressText) addressText.textContent = address || 'Endereço não disponível';
    
    showCoordinatesDisplay();
    validateField('location', true);
};
</script>

<?php require_once 'includes/footer.php'; ?>